#!/bin/bash

for a in "2020-02-24 04:00" "2020-02-25 04:00" "2020-02-26 04:00" "2020-02-27 04:00" "2020-02-28 04:00"; do
    echo "${a}"
    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_banco
    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_securitizadora
    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_hipotecaria
    sleep 100m
done