#!/bin/bash

aws_region="us-east-1"

sandbox_id="724358820973"
dev_id="652230569742"
stage_id="401750758664"
prod_id="2555688133533"

base_name="bancobari-prognum"

account_ids=($dev_id $stage_id $prod_id)

# TODO verificar se os buckets estão em modo privado!
for id in "${account_ids[@]}"; do
  for t in raw processed business; do
    aws s3api create-bucket \
      --bucket "${base_name}-${t}-${id}" \
      --acl "private" \
      --region "$aws_region"
  done
done