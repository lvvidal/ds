from calendar import monthrange
from datetime import datetime, timedelta


MON, TUE, WED, THU, FRI, SAT, SUN = range(7)

def last_day_of_month(dt: datetime):
    return monthrange(dt.year, dt.month)[1]

def decide_which_path(context):
    ds = context['ds']
    ds_date_obj = datetime.strptime(ds, "%Y-%m-%d")

    if ds_date_obj.day == last_day_of_month(ds_date_obj) and ds_date_obj.weekday() not in (SUN, MON):
        print("final do mês e não é final de semana")
        return "execute_sqls_monthly"
    elif ds_date_obj.day == last_day_of_month(ds_date_obj) - 1 and ds_date_obj.weekday() == SAT:
        print("penultimo dia do mes é sábado")
        return "execute_sqls_monthly"
    elif ds_date_obj.day == last_day_of_month(ds_date_obj) - 2 and ds_date_obj.weekday() == SAT:
        print("ante penultimo dia do mes é sábado")
        return "execute_sqls_monthly"
    else:
        print("não faz nada")
        return "do_nothing"



if __name__ == '__main__':

    context = {}

    context['ds'] = '2020-05-29'
    decide_which_path(context)


    # for di in range(31):
    #     d = datetime(2020, 1, 1) + timedelta(days=di)
    #     print(f"{d} {d.weekday()}")