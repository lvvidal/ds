#!/bin/bash

for a in "2020-01-13 04:00" "2020-01-14 04:00" "2020-01-15 04:00" "2020-01-16 04:00" "2020-01-17 04:00"; do
    echo "${a}"
#    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_banco
#    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_securitizadora
    airflow trigger_dag -e "${a}" Prognum_CSV_Extraction_Upload_S3_hipotecaria
    sleep 100m
done