#!/bin/bash

for a in "2020-02-10 04:00" "2020-02-11 04:00" "2020-02-12 04:00"; do
    echo "processing \"${a}\" start at $(date)"
    airflow trigger_dag -e "${a}" Prognum_Athena_Processing
    sleep 65m
    airflow trigger_dag -e "${a}" Prognum_Redshift_Processing
    sleep 10m
done