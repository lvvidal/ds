#!/bin/bash

for a in "2020-03-30 04:00" "2020-02-11 04:00" "2020-02-12 04:00" "2020-02-13 04:00" "2020-02-14 04:00"; do
    echo "\"${a}\""
    airflow trigger_dag -e "\"${a}\"" Prognum_CSV_Extraction_Upload_S3_banco
    airflow trigger_dag -e "\"${a}\"" Prognum_CSV_Extraction_Upload_S3_securitizadora
    airflow trigger_dag -e "\"${a}\"" Prognum_CSV_Extraction_Upload_S3_hipotecaria
    sleep 100m
done