CREATE TABLE IF NOT EXISTS scci_processed.usuario
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/USUARIO/')
AS
SELECT   cast (u.cpf as varchar(14)) AS "cpf" 
       , cast(try(date_parse(u.dt_validade_usuario,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_validade_usuario"
       , cast(try(date_parse(u.alt_data,'%Y-%m-%d %H:%i:%s')) as timestamp) as "alt_data"
       , cast(try(date_parse(u.dt_ultima_troca_senha,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_ultima_troca_senha"
       , cast(try(date_parse(u.dt_hora_inicio_acesso,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_hora_inicio_acesso"
       , cast(try(date_parse(u.dt_hora_fim_acesso,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_hora_fim_acesso"
       , try(cast(u.perf_primario as smallint)) AS "perf_primario"   
       , try(cast(u.perf_secundario as smallint)) AS "perf_secundario"   
       , cast(u.nome as varchar(50)) AS "nome" 
       , try(cast(u.codimp as smallint)) AS "codimp"  
       , try(cast(u.ent_primaria as smallint)) AS "ent_primaria"  
       , try(cast(u.ent_secundaria as smallint)) AS "ent_secundaria"  
       , try(cast(u.nu_max_dias_troca_senha as smallint)) AS "nu_max_dias_troca_senha"  
       , try(cast(u.nu_min_dias_troca_senha as smallint)) AS "nu_min_dias_troca_senha"  
       , try(cast(u.nu_timeout as smallint)) AS "nu_timeout"  
       , try(cast(u.nu_caixa as smallint)) AS "nu_caixa" 
       , try(cast(u.uidusuario as smallint)) AS "uidusuario" 
       , try(cast(u.nu_tentativas_erro_senha as smallint)) AS "nu_tentativas_erro_senha" 
       , cast(u.no_doc_autorizacao as varchar(50)) AS "no_doc_autorizacao" 
       , lower(cast(u.usuario as varchar(20))) AS "usuario" 
       , cast(u.rg as varchar(20)) AS "rg" 
       , cast(u.senha as varchar(40)) AS "senha" 
       , lower(cast(u.alt_usuario as varchar(20))) AS "alt_usuario" 
       , cast(u.no_e_mail_emissao as varchar(160)) AS "no_e_mail_emissao" 
       , cast(u.no_senha_e_mail_emissao as varchar(160)) AS "no_senha_e_mail_emissao" 
       , cast(u.no_senha1 as varchar(40)) AS "no_senha1" 
       , cast(u.no_senha2 as varchar(40)) AS "no_senha2" 
       , cast(u.no_senha3 as varchar(40)) AS "no_senha3" 
       , cast(u.no_senha4 as varchar(40)) AS "no_senha4" 
       , cast(u.no_senha5 as varchar(40)) AS "no_senha5" 
       , cast(u.no_chave_sessao as varchar(40)) AS "no_chave_sessao" 
       , cast(u.no_smtp_emissao_e_mail as varchar(160)) AS "no_smtp_emissao_e_mail" 
       , cast(u.co_setor as varchar(5)) AS "co_setor" 
       , cast( case
          when upper(u.in_troca_senha_proximo_login) = 'F' then 'false'
          when upper(u.in_troca_senha_proximo_login) = 'T' then 'true'
          when upper(u.in_troca_senha_proximo_login) = 'V' then 'true'
          else 'false'
        end as boolean) "in_troca_senha_proximo_login"
       , cast( case
          when upper(u.in_desativa_logs) = 'F' then 'false'
          when upper(u.in_desativa_logs) = 'T' then 'true'
          else 'false'
        end as boolean) "in_desativa_logs"
       , cast( case
          when upper(u.in_acesso_dias_nao_uteis) = 'F' then 'false'
          when upper(u.in_acesso_dias_nao_uteis) = 'T' then 'true'
          else 'false'
        end as boolean) "in_acesso_dias_nao_uteis"
FROM scci_raw.usuario as u;