CREATE TABLE IF NOT EXISTS scci_processed.pessoa_pretendente
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/PESSOA_PRETENDENTE/')
AS
SELECT  cast (pp.nu_pretendente as varchar(9)) AS "nu_pretendente"
       , coalesce(try(cast(pp.nu_pessoa as smallint)),0) AS "nu_pessoa"
       , upper(cast(pp.no_pessoa as varchar(40))) AS "no_pessoa"   
       , upper(cast(pp.nu_identidade as varchar(15))) AS "nu_identidade"   
       , upper(cast(pp.co_ufidentidade as char(2))) AS "co_ufidentidade"         
       , upper(cast(pp.nu_cprof as varchar(7))) AS "nu_cprof"   
       , upper(cast(pp.no_sercprof as varchar(5))) AS "no_sercprof"         
       , upper(cast(pp.nu_cpfcnpj as varchar(14))) AS "nu_cpfcnpj"        
       , cast(try(date_parse(pp.dt_nascimento,'%Y-%m-%d %H:%i:%s')) as date) as "dt_nascimento"       
       , upper(cast(pp.no_localnasc as varchar(21))) AS "no_localnasc"  
       , upper(cast(pp.co_ufnasc as char(2))) AS "co_ufnasc"
       , coalesce(try(cast(pp.nu_sexo as smallint)),0) AS "nu_sexo"       
       , coalesce(try(cast(pp.nu_escolaridade as smallint)),0) AS "nu_escolaridade" 
       , coalesce(try(cast(pp.nu_sitescolar as smallint)),0) AS "nu_sitescolar" 
       , coalesce(try(cast(pp.co_estciv as smallint)),0) AS "co_estciv" 
       , coalesce(try(cast(pp.co_regime_casamento as smallint)),0) AS "co_regime_casamento" 
       , upper(cast(pp.co_ufcprof as char(2))) AS "co_ufcprof"
       , try(cast(pp.co_profissao as smallint)) AS "co_profissao"
       , coalesce(try(cast(pp.co_sit_renda as smallint)),0) AS "co_sit_renda"
       , coalesce(try(cast(pp.co_categoria as integer)),0) AS "co_categoria"
       , coalesce(try(cast(pp.co_sit_est_civ as smallint)),0) AS "co_sit_est_civ"
       , cast(try(date_parse(pp.dt_casamento,'%Y-%m-%d %H:%i:%s')) as date) as "dt_casamento"    
       , coalesce(try(cast(pp.co_nacionalidade as smallint)),0) AS "co_nacionalidade"
       , upper(cast(pp.nu_orgaov as varchar(9))) AS "nu_orgaov"
       , cast( case
          when upper(pp.in_eadquirente) = 'F' then 'false'
          when upper(pp.in_eadquirente) = 'T' then 'true'
          else 'false'
        end as boolean) "in_eadquirente"
       , cast(pp.no_tp_exp_agro_1 as varchar(21)) AS "no_tp_exp_agro_1" 
       , cast(pp.no_tp_exp_agro_2 as varchar(21)) AS "no_tp_exp_agro_2"
       , cast(pp.no_tp_exp_agro_3 as varchar(21)) AS "no_tp_exp_agro_3"
       , coalesce(try(cast(pp.co_situacao_agro as smallint)),0) AS "co_situacao_agro"
       , cast(try(date_parse(pp.dt_identidade,'%Y-%m-%d %H:%i:%s')) as date) as "dt_identidade" 
       , cast(pp.nu_pis as varchar(15)) AS "nu_pis"
       , cast(pp.no_orge as varchar(6)) AS "no_orge"
       , coalesce(try(cast(pp.nu_oper as smallint)),0) AS "nu_oper"
       , upper(cast(pp.no_pai as varchar(40))) AS "no_pai"   
       , upper(cast(pp.no_mae as varchar(40))) AS "no_mae"   
       , coalesce(try(cast(pp.nu_conjuge as smallint)),0) AS "nu_conjuge"
       , try(cast(pp.nu_celular as varchar(11))) AS "nu_celular"
       , coalesce(try(cast (pp.va_saldo_disp_fgts as double)),0) AS "va_saldo_disp_fgts"
       , cast(try(date_parse(pp.dt_saldo_fgts,'%Y-%m-%d %H:%i:%s')) as date) as "dt_saldo_fgts"
       , coalesce(try(cast (pp.va_poupanca as double)),0) AS "va_poupanca"
       , coalesce(try(cast (pp.va_saldo_poupanca as double)),0) AS "va_saldo_poupanca"
       , coalesce(try(cast (pp.va_out_aplicacao as double)),0) AS "va_out_aplicacao"
       , coalesce(try(cast (pp.va_saldo_out_aplicacao as double)),0) AS "va_saldo_out_aplicacao"
       , cast( case
          when upper(pp.in_fisica_juridica) = 'F' then 'F'
          when upper(pp.in_fisica_juridica) = 'J' then 'J'
          when (pp.in_fisica_juridica = '' and regexp_like(upper(pp.no_pessoa), 'LTDA')) then 'J'
          else 'F'
        end as char(1)) "in_fisica_juridica"
       , coalesce(try(cast (pp.va_credit_score as double)),0) AS "va_credit_score"
       , cast(try(date_parse(pp.dt_consulta_serasa,'%Y-%m-%d %H:%i:%s')) as date) as "dt_consulta_serasa"
       , coalesce(try(cast(pp.nu_banco as integer)),0) AS "nu_banco"
       , upper(cast(pp.nu_agencia as varchar(20))) AS "nu_agencia"
       , upper(cast(pp.nu_conta_corrente as varchar(20))) AS "nu_conta_corrente"
       , upper(cast(pp.no_endereco as varchar(41))) AS "no_endereco"
       , coalesce(try(cast(pp.nu_numero as smallint)),0) AS "nu_numero"
       , upper(cast(pp.no_complemento as varchar(15))) AS "no_complemento"
       , try(cast(pp.nu_ddd_res as varchar(5))) AS "nu_ddd_res"
       , try(cast(pp.nu_telefone_res as varchar(11))) AS "nu_telefone_res"
       , try(cast(pp.no_bairro as varchar(21))) AS "no_bairro"
       , upper(cast(pp.co_uf as char(2))) AS "co_uf"
       , try(cast(pp.nu_cep as varchar(9))) AS "nu_cep"
       , coalesce(try(cast(pp.pe_renda as integer)),0) AS "pe_renda"
       , coalesce(try(cast (pp.va_renda as double)),0) AS "va_renda"
       , coalesce(try(cast(pp.co_munic_categ as integer)),0) AS "co_munic_categ"
       , coalesce(try(cast(pp.nu_mdis as smallint)),0) AS "nu_mdis"
       , cast(try(date_parse(pp.dt_lei_div,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_lei_div"
       , coalesce(try(cast(pp.co_distrito as smallint)),0) AS "co_distrito"
       , coalesce(try(cast(pp.co_municipio as smallint)),0) AS "co_municipio"
       , upper(cast(pp.no_pontoref as varchar(31))) AS "no_pontoref"
       , cast(pp.no_endereco_abrev as char(1)) AS "no_endereco_abrev"
       , coalesce(try(cast(pp.nu_depend_sem_renda as smallint)),0) AS "nu_depend_sem_renda"
       , coalesce(try(cast(pp.nu_depend_renda_n_parte as smallint)),0) AS "nu_depend_renda_n_parte"
       , coalesce(try(cast (pp.va_renda_liq_depend as double)),0) AS "va_renda_liq_depend"
       , coalesce(try(cast(pp.nu_tempo_res_mun as smallint)),0) AS "nu_tempo_res_mun"
       , coalesce(try(cast(pp.nu_tempo_res_mun_ant as smallint)),0) AS "nu_tempo_res_mun_ant"
       , lower(try(cast(pp.no_email as varchar(80)))) AS "no_email"
       , try(cast(pp.nu_tit_ele_num as varchar(14))) AS "nu_tit_ele_num"
       , try(cast(pp.nu_tit_ele_zona as varchar(3))) AS "nu_tit_ele_zona"
       , try(cast(pp.nu_tit_ele_secao as varchar(4))) AS "nu_tit_ele_secao"
       , coalesce(try(cast(pp.co_tipo_rg as smallint)),0) AS "co_tipo_rg"
       , try(cast(pp.nu_ddd_cel as varchar(5))) AS "nu_ddd_cel"
       , cast( case
          when upper(pp.in_e_fiador) = 'F' then 'false'
          when upper(pp.in_e_fiador) = 'T' then 'true'
          else 'false'
        end as boolean) "in_e_fiador"
       , coalesce(try(cast(pp.in_fgts as smallint)),0) AS "in_fgts"
       , coalesce(try(cast(pp.co_nat_juridica as integer)),0) AS "co_nat_juridica"
       , coalesce(try(cast(pp.nu_inscricao_estadual as integer)),0) AS "nu_inscricao_estadual"
       , coalesce(try(cast(pp.co_natureza_empresa as integer)),0) AS "co_natureza_empresa"
       , cast( case
          when upper(pp.in_empresa_tributavel) = 'F' then 'false'
          when upper(pp.in_empresa_tributavel) = 'T' then 'true'
          else 'false'
        end as boolean) "in_empresa_tributavel"
       , cast( case
          when upper(pp.in_empresa_com_fins_lucrativos) = 'F' then 'false'
          when upper(pp.in_empresa_com_fins_lucrativos) = 'T' then 'true'
          else 'false'
        end as boolean) "in_empresa_com_fins_lucrativos"
       , try(cast(pp.no_tipo_logradouro as varchar(15))) AS "no_tipo_logradouro"
       , try(cast(pp.no_cidade as varchar(25))) AS "no_cidade"
       , try(cast(pp.nu_ramal as varchar(5))) AS "nu_ramal"
       , try(cast(pp.nu_ddd_fax as varchar(5))) AS "nu_ddd_fax"
       , try(cast(pp.nu_telefone_fax as varchar(11))) AS "nu_telefone_fax"
       , cast( case
          when upper(pp.in_deficiente) = 'F' then 'false'
          when upper(pp.in_deficiente) = 'T' then 'true'
          else 'false'
        end as boolean) "in_deficiente"
       , coalesce(try(cast(pp.co_tipo_raca as smallint)),0) AS "co_tipo_raca"
       , coalesce(try(cast(pp.co_tipo_negro as smallint)),0) AS "co_tipo_negro"
       , cast( case
          when upper(pp.in_res_outra_ocupacao) = 'F' then 'false'
          when upper(pp.in_res_outra_ocupacao) = 'T' then 'true'
          else 'false'
        end as boolean) "in_res_outra_ocupacao"
       , coalesce(try(cast(pp.co_tipo_deficiencia as smallint)),0) AS "co_tipo_deficiencia"
       , try(cast(pp.no_deficiente as varchar(40))) AS "no_deficiente"
       , coalesce(try(cast(pp.nu_dependentes as smallint)),0) AS "nu_dependentes"
       , coalesce(try(cast(pp.nu_setor as smallint)),0) AS "nu_setor"
       , try(cast(pp.no_quadra as varchar(6))) AS "no_quadra"
       , try(cast(pp.no_lote as varchar(4))) AS "no_lote"
       , try(cast(pp.no_edificacao as varchar(6))) AS "no_edificacao"
       , coalesce(try(cast(pp.nu_inscr_anterior as smallint)),0) AS "nu_inscr_anterior"
       , coalesce(try(cast (pp.va_total_beneficio as double)),0) AS "va_total_beneficio"
       , coalesce(try(cast(pp.co_sit_trabalho as smallint)),0) AS "co_sit_trabalho"
       , cast( case
          when upper(pp.in_recebe_beneficio_gov) = 'F' then 'false'
          when upper(pp.in_recebe_beneficio_gov) = 'T' then 'true'
          else 'false'
        end as boolean) "in_recebe_beneficio_gov"
       , try(cast(pp.no_beneficio as varchar(30))) AS "no_beneficio"
       , cast( case
          when upper(pp.in_cadunico_govfed) = 'F' then 'false'
          when upper(pp.in_cadunico_govfed) = 'T' then 'true'
          else 'false'
        end as boolean) "in_cadunico_govfed"
       , try(cast(pp.nu_cadunico_govfed as varchar(20))) AS "nu_cadunico_govfed"
       , try(cast(pp.in_endereco_correspondencia as char(1))) AS "in_endereco_correspondencia"
       , try(cast(pp.in_tipo_pessoa as char(1))) AS "in_tipo_pessoa"
       , try(cast(pp.in_cartao_visa as char(1))) AS "in_cartao_visa"
       , try(cast(pp.in_cartao_mastercard as char(1))) AS "in_cartao_mastercard"
       , try(cast(pp.in_cartao_amex as char(1))) AS "in_cartao_amex"
       , try(cast(pp.in_outro_cartao as char(1))) AS "in_outro_cartao"
       , try(cast(pp.no_outro_cartao as varchar(40))) AS "no_outro_cartao"
       , coalesce(try(cast(pp.co_atividade_profissional as integer)),0) AS "co_atividade_profissional"
       , coalesce(try(cast(pp.qt_filhos as integer)),0) AS "qt_filhos"
       , try(cast(pp.no_titular_conta_corrente as varchar(20))) AS "no_titular_conta_corrente"
       , try(cast(pp.co_tit_ele_uf as char(2))) AS "co_tit_ele_uf"
       , cast(try(date_parse(pp.dt_opcao_fgts,'%Y-%m-%d %H:%i:%s')) as date) as "dt_opcao_fgts"
       , cast( case
          when upper(pp.in_marital) = 'F' then 'false'
          when upper(pp.in_marital) = 'T' then 'true'
          else 'false'
        end as boolean) "in_marital"
       , cast(try(date_parse(pp.dt_marital,'%Y-%m-%d %H:%i:%s')) as date) as "dt_marital"
       , try(cast(pp.nu_telefone_com as varchar(15))) AS "nu_telefone_com"
       , try(cast(pp.nu_ddd_com as varchar(5))) AS "nu_ddd_com"
       , try(cast(pp.no_fantasia as varchar(15))) AS "no_fantasia"
       , try(cast(pp.no_grupo as varchar(15))) AS "no_grupo"
       , cast(try(date_parse(pp.dt_constituicao,'%Y-%m-%d %H:%i:%s')) as date) as "dt_constituicao"
       , coalesce(try(cast (pp.va_capital_social as double)),0) AS "va_capital_social"
       , cast( case
          when upper(pp.in_capital_aberto) = 'F' then 'false'
          when upper(pp.in_capital_aberto) = 'T' then 'true'
          else 'false'
        end as boolean) "in_capital_aberto"
       , try(cast(pp.co_controle_acionario as char(1))) AS "co_controle_acionario"
       , try(cast(pp.no_titular_conta as varchar(42))) AS "no_titular_conta"
       , coalesce(try(cast(pp.nu_pessoa_principal as integer)),0) AS "nu_pessoa_principal"
       , cast(try(date_parse(pp.dt_pacto_antenupcial,'%Y-%m-%d %H:%i:%s')) as date) as "dt_pacto_antenupcial"
       , try(cast(pp.no_livro_pacto as varchar(30))) AS "no_livro_pacto"
       , try(cast(pp.no_folhas_pacto as varchar(30))) AS "no_folhas_pacto"
       , try(cast(pp.no_registro_averbacao_pacto as varchar(30))) AS "no_registro_averbacao_pacto"
       , try(cast(pp.no_matricula_pacto as varchar(30))) AS "no_matricula_pacto"
       , try(cast(pp.no_pais_emissor_identidade as varchar(30))) AS "no_pais_emissor_identidade"
       , cast( case
          when upper(pp.in_exerceu_funcao_publica) = 'F' then 'false'
          when upper(pp.in_exerceu_funcao_publica) = 'T' then 'true'
          else 'false'
        end as boolean) "in_exerceu_funcao_publica"
       , try(cast(pp.no_orgao_publico as varchar(30))) AS "no_orgao_publico"
       , cast(try(date_parse(pp.dt_pacto_antenupcial,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_inicio_orgao_publico"
       , cast(try(date_parse(pp.dt_pacto_antenupcial,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_fim_orgao_publico"
       , cast( case
          when upper(pp.in_vinculo_funcao_publica) = 'F' then 'false'
          when upper(pp.in_vinculo_funcao_publica) = 'T' then 'true'
          else 'false'
        end as boolean) "in_vinculo_funcao_publica"
       , cast( case
          when upper(pp.in_estrangeiro) = 'F' then 'false'
          when upper(pp.in_estrangeiro) = 'T' then 'true'
          else 'false'
        end as boolean) "in_estrangeiro"
       , try(cast(pp.no_pais_estrangeiro as varchar(50))) AS "no_pais_estrangeiro"
       , try(cast(pp.no_orgao_estrangeiro as varchar(50))) AS "no_orgao_estrangeiro"
       , try(cast(pp.no_cargo_estrangeiro as varchar(50))) AS "no_cargo_estrangeiro"
       , cast(try(date_parse(pp.dt_inicio_exer_estrangeiro,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_inicio_exer_estrangeiro"
       , cast(try(date_parse(pp.dt_fim_exer_estrangeiro,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_fim_exer_estrangeiro"
       , try(cast(pp.no_relacao_estrangeiro as varchar(20))) AS "no_relacao_estrangeiro"
       , try(cast(pp.no_vinculo_1 as varchar(50))) AS "no_vinculo_1"
       , try(cast(pp.no_vinculo_2 as varchar(50))) AS "no_vinculo_2"
       , try(cast(pp.no_vinculo_3 as varchar(50))) AS "no_vinculo_3"
       , try(cast(pp.nu_vinculo_nome_cpfcnpj_1 as varchar(14))) AS "nu_vinculo_nome_cpfcnpj_1"
       , try(cast(pp.nu_vinculo_nome_cpfcnpj_2 as varchar(14))) AS "nu_vinculo_nome_cpfcnpj_2"
       , try(cast(pp.nu_vinculo_nome_cpfcnpj_3 as varchar(14))) AS "nu_vinculo_nome_cpfcnpj_3"
       , try(cast(pp.no_vinculo_orgao_publico_1 as varchar(50))) AS "no_vinculo_orgao_publico_1"
       , try(cast(pp.no_vinculo_orgao_publico_2 as varchar(50))) AS "no_vinculo_orgao_publico_2"
       , try(cast(pp.no_vinculo_orgao_publico_3 as varchar(50))) AS "no_vinculo_orgao_publico_3"
       , try(cast(pp.nu_ddd_rec as varchar(5))) AS "nu_ddd_rec"
       , try(cast(pp.nu_telefone_rec as varchar(11))) AS "nu_telefone_rec"
       , try(cast(pp.nu_informacao_social as varchar(20))) AS "nu_informacao_social"
       , try(cast(pp.in_uniao_estavel as char(1))) AS "in_uniao_estavel"
       , try(cast(pp.no_empresa_anterior as varchar(80))) AS "no_empresa_anterior"
       , try(cast(pp.nu_ddd_empresa_ant as varchar(3))) AS "nu_ddd_empresa_ant"
       , try(cast(pp.nu_tel_empresa_ant as varchar(10))) AS "nu_tel_empresa_ant"
       , try(cast(pp.nu_ramal_empresa_ant as varchar(5))) AS "nu_ramal_empresa_ant"
       , try(cast(pp.no_facebook as varchar(50))) AS "no_facebook"
       , try(cast(pp.no_twiter as varchar(50))) AS "no_twiter"
       , cast( case
          when upper(pp.in_estudando) = 'F' then 'false'
          when upper(pp.in_estudando) = 'T' then 'true'
          else 'false'
        end as boolean) "in_estudando"
       , try(cast(pp.no_serie_estudando as varchar(20))) AS "no_serie_estudando"
       , try(cast(pp.nu_nis_govfed as varchar(15))) AS "nu_nis_govfed"
       , coalesce(try(cast(pp.co_status_sit_renda as smallint)),0) AS "co_status_sit_renda"
       , upper(cast(pp.co_tp_conta as char(1))) AS "co_tp_conta"
       , upper(cast(pp.co_qualificacao_conta as char(1))) AS "co_qualificacao_conta"
       , cast( case
          when upper(pp.in_e_procurador) = 'F' then 'false'
          when upper(pp.in_e_procurador) = 'T' then 'true'
          else 'false'
        end as boolean) "in_e_procurador"
       , coalesce(try(cast(pp.nu_inscricao_municipal as integer)),0) AS "nu_inscricao_municipal"
       , try(cast(pp.co_forma_constituicao_pj as varchar(3))) AS "co_forma_constituicao_pj"
       , lower(try(cast(pp.no_web_site_empresa as varchar(40)))) AS "no_web_site_empresa"
       , try(cast(pp.no_cargo as varchar(40))) AS "no_cargo"
       , try(cast(pp.no_orgao as varchar(20))) AS "no_orgao"
       , cast(try(date_parse(pp.dt_registro_junta_comercial,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_registro_junta_comercial"
       , cast(try(date_parse(pp.dt_ult_alt_contratual,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_ult_alt_contratual"
       , try(cast(pp.no_empresa_sucessora as varchar(40))) AS "no_empresa_sucessora"
       , cast(try(date_parse(pp.dt_sucessao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_sucessao"
       , try(cast(pp.no_pessoa_contato_pj as varchar(40))) AS "no_pessoa_contato_pj"
       , try(cast(pp.no_cargo_pessoa_contato_pj as varchar(15))) AS "no_cargo_pessoa_contato_pj"
       , try(cast(pp.nu_ddd_tel_contato_pj as varchar(5))) AS "nu_ddd_tel_contato_pj"
       , try(cast(pp.nu_tel_contato_pj as varchar(11))) AS "nu_tel_contato_pj"
       , try(cast(pp.co_tipo_controle as char(1))) AS "co_tipo_controle"
       , cast(try(date_parse(pp.dt_atualizacao_cadastro,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_atualizacao_cadastro"
       , try(cast(pp.co_risco_cliente as varchar(3))) AS "co_risco_cliente"
       , cast( case
          when upper(pp.in_restricoes_cadastrais) = 'F' then 'false'
          when upper(pp.in_restricoes_cadastrais) = 'T' then 'true'
          else 'false'
        end as boolean) "in_restricoes_cadastrais"
       , try(cast(pp.no_reciprocidade as varchar(100))) AS "no_reciprocidade"
       , cast( case
          when upper(pp.in_conta_salario) = 'F' then 'false'
          when upper(pp.in_conta_salario) = 'T' then 'true'
          else 'false'
        end as boolean) "in_conta_salario"
       , cast( case
          when upper(pp.in_cesta_servico) = 'F' then 'false'
          when upper(pp.in_cesta_servico) = 'T' then 'true'
          else 'false'
        end as boolean) "in_cesta_servico"
       , try(cast(pp.no_comprovacao_renda as varchar(30))) AS "no_comprovacao_renda"
       , try(cast(pp.nu_livro_procuracao as varchar(15))) AS "nu_livro_procuracao"
       , try(cast(pp.nu_folha_procuracao as varchar(15))) AS "nu_folha_procuracao"
       , try(cast(pp.no_cartorio_procuracao as varchar(50))) AS "no_cartorio_procuracao"
       , cast(try(date_parse(pp.dt_procuracao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_procuracao"
       , cast( case
          when upper(pp.in_tem_responsabilidade) = 'F' then 'false'
          when upper(pp.in_tem_responsabilidade) = 'T' then 'true'
          else 'false'
        end as boolean) "in_tem_responsabilidade"
       , coalesce(try(cast (pp.va_beneficio_continuado as double)),0) AS "va_beneficio_continuado"
       , coalesce(try(cast (pp.va_faturamento_anual as double)),0) AS "va_faturamento_anual"
       , try(cast(pp.nu_registro_junta_comercial as varchar(30))) AS "nu_registro_junta_comercial"
       , cast(try(date_parse(pp.dt_faturamento_mensal,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_faturamento_mensal"
       , cast(try(date_parse(pp.dt_patrimonio_liquido,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_patrimonio_liquido"
       , coalesce(try(cast (pp.va_patrimonio_liquido as double)),0) AS "va_patrimonio_liquido"
       , coalesce(try(cast (pp.va_capital_realizavel as double)),0) AS "va_capital_realizavel"
       , coalesce(try(cast(pp.qt_empregados as integer)),0) AS "qt_empregados"
       , coalesce(try(cast (pp.va_faturamento_presumido as double)),0) AS "va_faturamento_presumido"
       , try(cast(pp.in_natureza_capital as char(1))) AS "in_natureza_capital"
       , cast( case
          when upper(pp.in_representante_legal) = 'F' then 'false'
          when upper(pp.in_representante_legal) = 'T' then 'true'
          else 'false'
        end as boolean) "in_representante_legal"
       , try(cast(pp.no_comarca_procuracao as varchar(30))) AS "no_comarca_procuracao"
       , upper(try(cast(pp.co_uf_procuracao as char(2)))) AS "co_uf_procuracao"
       , coalesce(try(cast(pp.co_municipio_naturalidade as integer)),0) AS "co_municipio_naturalidade"
       , try(cast(pp.co_pessoa_sistema_externo as varchar(17))) AS "co_pessoa_sistema_externo"
       , cast( case
          when upper(pp.in_isento_ir) = 'F' then 'false'
          when upper(pp.in_isento_ir) = 'T' then 'true'
          else 'false'
        end as boolean) "in_isento_ir"
       , coalesce(try(cast (pp.va_media_ir as double)),0) AS "va_media_ir"
       , upper(try(cast(pp.no_cc_ou_poup as char(1)))) AS "no_cc_ou_poup"
       , cast( case
          when upper(pp.in_menor_emancipado) = 'F' then 'false'
          when upper(pp.in_menor_emancipado) = 'T' then 'true'
          else 'false'
        end as boolean) "in_menor_emancipado"
       , cast( case
          when upper(pp.in_restricao_securitaria) = 'F' then 'false'
          when upper(pp.in_restricao_securitaria) = 'T' then 'true'
          else 'false'
        end as boolean) "in_restricao_securitaria"
       , cast( case
          when upper(pp.in_familiar_pessoa_exposta) = 'F' then 'false'
          when upper(pp.in_familiar_pessoa_exposta) = 'T' then 'true'
          else 'false'
        end as boolean) "in_familiar_pessoa_exposta"
       , cast( case
          when upper(pp.in_relaciona_pessoa_exposta) = 'F' then 'false'
          when upper(pp.in_relaciona_pessoa_exposta) = 'T' then 'true'
          else 'false'
        end as boolean) "in_relaciona_pessoa_exposta"
       , cast( case
          when upper(pp.in_situacao_atipica) = 'F' then 'false'
          when upper(pp.in_situacao_atipica) = 'T' then 'true'
          else 'false'
        end as boolean) "in_situacao_atipica"
       , coalesce(try(cast (pp.va_endividamento_bco as double)),0) AS "va_endividamento_bco"
       , coalesce(try(cast (pp.va_dipj as double)),0) AS "va_dipj"
       , coalesce(try(cast (pp.va_endividamento_tot as double)),0) AS "va_endividamento_tot"
       , coalesce(try(cast (pp.va_curto_prz as double)),0) AS "va_curto_prz"
       , coalesce(try(cast (pp.va_longo_prz as double)),0) AS "va_longo_prz"
       , coalesce(try(cast (pp.va_vencido as double)),0) AS "va_vencido"
       , coalesce(try(cast (pp.va_prejuizo as double)),0) AS "va_prejuizo"
       , coalesce(try(cast (pp.va_financ_imob as double)),0) AS "va_financ_imob"
       , coalesce(try(cast (pp.va_restricao_cadastral as double)),0) AS "va_restricao_cadastral"
       , coalesce(try(cast(pp.tp_restricao_cadastral as smallint)),0) AS "tp_restricao_cadastral"
       , try(cast(pp.no_certificacao_1 as varchar(30))) AS "no_certificacao_1"  
       , try(cast(pp.no_certificacao_2 as varchar(30))) AS "no_certificacao_2"
       , coalesce(try(cast(pp.nu_anos_experiencia_prof as integer)),0) AS "nu_anos_experiencia_prof"
       , try(cast(pp.no_atividade_principal_pj as varchar(40))) AS "no_atividade_principal_pj"  
       , try(cast(pp.no_atividade_segundaria_pj as varchar(40))) AS "no_atividade_segundaria_pj"
       , try(cast(pp.no_funcao_empresa as varchar(40))) AS "no_funcao_empresa"
       , try(cast(pp.co_organizacao_militar as varchar(20))) AS "co_organizacao_militar"
       , try(cast(pp.co_selo_digital as varchar(23))) AS "co_selo_digital"
       , cast( case
          when upper(pp.in_militar_temporario) = 'F' then 'false'
          when upper(pp.in_militar_temporario) = 'T' then 'true'
          else 'false'
        end as boolean) "in_militar_temporario"
       , cast(try(date_parse(pp.dt_engajamento,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_engajamento"
       , coalesce(try(cast(pp.nu_imovel_garantia as integer)),0) AS "nu_imovel_garantia"
       , coalesce(try(cast(pp.nu_banco_fase_retorno as integer)),0) AS "nu_banco_fase_retorno"
       , try(cast(pp.nu_agencia_fase_retorno as varchar(20))) AS "nu_agencia_fase_retorno"  
       , try(cast(pp.nu_contacorr_fase_retorno as varchar(20))) AS "nu_contacorr_fase_retorno"
       , coalesce(try(cast(pp.in_tipo_pgto_liberacao as smallint)),0) AS "in_tipo_pgto_liberacao"
       , coalesce(try(cast(pp.nu_pessoa_credito_vendedor as smallint)),0) AS "nu_pessoa_credito_vendedor"
       , cast(try(date_parse(pp.dt_consulta_crivo,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_consulta_crivo"
       , try(cast(pp.co_bandeira_crivo as char(1))) AS "co_bandeira_crivo"
       , try(cast(pp.no_email2 as varchar(80))) AS "no_email2"
       , try(cast(pp.nu_agencdv as char(1))) AS "nu_agencdv"
       , try(cast(pp.nu_ctadv as char(2))) AS "nu_ctadv"
       , try(cast(pp.nu_dv_agencia_fase_retorno as char(1))) AS "nu_dv_agencia_fase_retorno"
       , try(cast(pp.nu_dv_contacorr_fase_retorno as char(2))) AS "nu_dv_contacorr_fase_retorno"
       , coalesce(try(cast(pp.co_parentesco_titular as smallint)),0) AS "co_parentesco_titular"
       , coalesce(try(cast (pp.va_renda_bruta as double)),0) AS "va_renda_bruta"
       , coalesce(try(cast (pp.pe_para_credito as double)),0) AS "pe_para_credito"
       , try(cast(pp.no_complemento_rg as varchar(40))) AS "no_complemento_rg"
       , try(cast(pp.in_conjuge_anuente as char(1))) AS "in_conjuge_anuente"
       , try(cast(pp.co_documento_forma_pgto as varchar(50))) AS "co_documento_forma_pgto"
       , coalesce(try(cast (pp.pe_propriedade_imovel as double)),0) AS "pe_propriedade_imovel"
       , cast( case
          when upper(pp.in_vendedor_principal) = 'F' then 'false'
          when upper(pp.in_vendedor_principal) = 'T' then 'true'
          else 'false'
        end as boolean) "in_vendedor_principal"
       , try(cast(pp.no_instrumento_procuracao as varchar(30))) AS "no_instrumento_procuracao"
       , try(cast(pp.nu_procuracao as varchar(30))) AS "nu_procuracao"
       , cast( case
          when upper(pp.in_autorzc) = 'F' then 'false'
          when upper(pp.in_autorzc) = 'T' then 'true'
          else 'false'
        end as boolean) "in_autorzc"
       , cast( case
          when upper(pp.in_financ_ativo_sfh) = 'F' then 'false'
          when upper(pp.in_financ_ativo_sfh) = 'T' then 'true'
          else 'false'
        end as boolean) "in_financ_ativo_sfh"
       , cast( case
          when upper(pp.in_imovel_munic_residencia) = 'F' then 'false'
          when upper(pp.in_imovel_munic_residencia) = 'T' then 'true'
          else 'false'
        end as boolean) "in_imovel_munic_residencia"
       , cast( case
          when upper(pp.in_imovel_munic_financ) = 'F' then 'false'
          when upper(pp.in_imovel_munic_financ) = 'T' then 'true'
          else 'false'
        end as boolean) "in_imovel_munic_financ"
       , try(cast(pp.nu_matricula_reg_civil as varchar(40))) AS "nu_matricula_reg_civil"
       , coalesce(try(cast (pp.pe_renda_excecao as integer)),0) AS "pe_renda_excecao"
       , coalesce(try(cast (pp.pe_mip_excecao as double)),0) AS "pe_mip_excecao"
       , cast( case
          when upper(pp.in_confdados) = 'F' then 'false'
          when upper(pp.in_confdados) = 'T' then 'true'
          else 'false'
        end as boolean) "in_confdados"
       , cast( case
          when upper(pp.in_cienciadados) = 'F' then 'false'
          when upper(pp.in_cienciadados) = 'T' then 'true'
          else 'false'
        end as boolean) "in_cienciadados"
FROM scci_raw.pessoa_pretendente as pp;

