CREATE TABLE IF NOT EXISTS scci_processed.setor
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/SETOR/')
AS
SELECT  try(cast(s.cod_ent as integer)) AS "cod_ent"   
       , cast(s.nu_cep as varchar(8)) AS "nu_cep" 
       , try(cast(s.co_filial_cobranca as smallint)) AS "co_filial_cobranca"
       , cast(s.no_endereco as varchar(50)) AS "no_endereco"   
       , upper(cast(s.no_setor as varchar(40))) AS "no_setor"   
       , lower(cast(s.co_responsavel_setor as varchar(20))) AS "co_responsavel_setor"   
       , cast(s.no_bairro as varchar(40)) AS "no_bairro"  
       , cast(s.no_cidade as varchar(40)) AS "no_cidade"  
       , cast(s.co_uf as char(2)) AS "co_uf"   
       , lower(cast(s.no_email as varchar(80))) AS "no_email"  
       , upper(cast(s.co_setor as varchar(5))) AS "co_setor" 
       , upper(cast(s.co_setor_superior as varchar(5))) AS "co_setor_superior" 
       , cast(s.no_complemento as varchar(15)) AS "no_complemento" 
       , cast(s.in_so_email_setor as char(1)) AS "in_so_email_setor" 
       , cast(s.in_calcula_indicador as char(1)) AS "in_calcula_indicador" 
FROM scci_raw.setor as s;