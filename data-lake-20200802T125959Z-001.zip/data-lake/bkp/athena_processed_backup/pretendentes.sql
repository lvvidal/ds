CREATE TABLE IF NOT EXISTS scci_processed.pretendente
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/PRETENDENTE/')
AS
SELECT  cast (p.nu_pretendente as varchar(9)) AS "nu_pretendente"
      , cast (p.nu_escrreg as smallint) AS "nu_escrreg"
      , cast (p.no_entrevistador as varchar(15)) AS "no_entrevistador"
      , cast(try(date_parse(p.dt_cadastro,'%Y-%m-%d %H:%i:%s')) as date) as "dt_cadastro"
      , cast(try(date_parse(p.dt_ult_atualizacao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_ult_atualizacao"
      , cast (p.co_empreendimento as integer) AS "co_empreendimento"
      , cast (p.co_situacao as integer) AS "co_situacao"
      , cast(try(date_parse(p.dt_situacao,'%Y-%m-%d %H:%i:%s')) as date) as "dt_situacao"
      , cast (p.nu_qtdclass as smallint) AS "nu_qtdclass"
      , cast (p.co_ocorrencia as smallint) AS "co_ocorrencia"
      , cast (try(p.in_cartaemitida) as char(1)) AS "in_cartaemitida"
      , cast (p.in_imv_prop as smallint) AS "in_imv_prop"
      , cast (p.in_imv_pelo_fgts as smallint) AS "in_imv_pelo_fgts"
      , cast (p.co_munic_imv_prop as smallint) AS "co_munic_imv_prop"
      , cast (p.va_financ_pleiteado as double) AS "va_financ_pleiteado"
      , cast (p.co_opcao_amort as smallint) AS "co_opcao_amort"
      , cast (p.nu_prazo as smallint) AS "nu_prazo"
      , cast (p.va_encargo as double) AS "va_encargo"
      , coalesce(try(cast(p.co_interesse as smallint)),0) AS "co_interesse"
      , cast (p.in_procurou_imv as char(1)) AS "in_procurou_imv"
      , cast (p.co_tipo_imv_pretend_1 as smallint) AS "co_tipo_imv_pretend_1"
      , cast (p.co_tipo_imv_pretend_2 as smallint) AS "co_tipo_imv_pretend_2"
      , cast (p.co_munic_pretend_1 as smallint) AS "co_munic_pretend_1"
      , cast (p.co_munic_pretend_2 as smallint) AS "co_munic_pretend_2"
      , cast (p.co_munic_pretend_3 as smallint) AS "co_munic_pretend_3"
      , cast (try(p.no_bairro_pretend_1) as varchar(21)) AS "no_bairro_pretend_1"
      , cast (p.co_tipo_sitben as smallint) AS "co_tipo_sitben"
      , cast (p.no_usu_alt as varchar(20)) AS "no_usu_alt"
      , cast (p.no_senha as varchar(50)) AS "no_senha"
      , cast (p.no_lembrete_senha as varchar(50)) AS "no_lembrete_senha"
      , cast (p.co_cliente as varchar(17)) AS "co_cliente"
      , cast( case
          when upper(p.in_receber_inf_por_email) = 'F' then 'false'
          when upper(p.in_receber_inf_por_email) = 'T' then 'true'
          else 'false'
        end as boolean) "in_receber_inf_por_email"
      , cast( case
          when upper(p.in_tem_imovel) = 'F' then 'false'
          when upper(p.in_tem_imovel) = 'T' then 'true'
          else 'false'
        end as boolean) "in_tem_imovel"
      , cast( case
          when upper(p.in_mutuario_outro_agente) = 'F' then 'false'
          when upper(p.in_mutuario_outro_agente) = 'T' then 'true'
          else 'false'
        end as boolean) "in_mutuario_outro_agente"
      , cast( case
          when upper(p.in_conjuge_compoe_renda) = 'F' then 'false'
          when upper(p.in_conjuge_compoe_renda) = 'T' then 'true'
          else 'false'
        end as boolean) "in_conjuge_compoe_renda"
      , cast(try(date_parse(p.dt_entrevista,'%Y-%m-%d %H:%i:%s')) as date) as "dt_entrevista"
      , coalesce(try(cast(p.co_responsavel_crianca0a6 as smallint)),0) AS "co_responsavel_crianca0a6"
      , cast (p.no_outro_resp_crianca0a6 as varchar(40)) AS "no_outro_resp_crianca0a6"
      , cast (p.no_entrevistado as varchar(40)) AS "no_entrevistado"
      , cast (p.no_situacao_trabalho_outro as varchar(30)) AS "no_situacao_trabalho_outro"
      , coalesce(try(cast(p.co_tipo_moeda as smallint)),0) AS "co_tipo_moeda"
      , coalesce(try(cast(p.co_bairro_pretendido as smallint)),0) AS "co_bairro_pretendido"
      , coalesce(try(cast(p.co_idpaidocumentos as integer)),0) AS "co_idpaidocumentos"
      , coalesce(try(cast(p.co_motivo_operacao as smallint)),0) AS "co_motivo_operacao"
      , coalesce(try(cast(p.co_lcobr as smallint)),0) AS "co_lcobr"
      , cast( case
          when upper(p.in_deficiente_grupo_familiar) = 'F' then 'false'
          when upper(p.in_deficiente_grupo_familiar) = 'T' then 'true'
          else 'false'
        end as boolean) "in_deficiente_grupo_familiar"
FROM scci_raw.pretendente as p;