CREATE TABLE IF NOT EXISTS scci_processed.imovel_operacao
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/IMOVEL_OPERACAO/')
AS
SELECT   cast (io.nu_operacao as integer) AS "nu_operacao"
       , upper(cast(io.no_endereco as varchar(35))) AS "no_endereco"   
       , upper(cast(io.no_complemento as varchar(15))) AS "no_complemento"   
       , upper(cast(io.no_bairro as varchar(21))) AS "no_bairro"   
       , upper(cast(io.no_comarca as varchar(40))) AS "no_comarca"   
       , upper(cast(io.no_circunscricao_imobiliaria as varchar(40))) AS "no_circunscricao_imobiliaria"   
       , upper(cast(io.nu_inscricao_municipal as varchar(30))) AS "nu_inscricao_municipal"   
       , cast(try(date_parse(io.dt_titulo_aquisitivo,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_titulo_aquisitivo"
       , upper(cast(io.nu_matricula_imovel as varchar(20))) AS "nu_matricula_imovel"
       , upper(cast(io.nu_registro_imovel as varchar(20))) AS "nu_registro_imovel"
       , upper(cast(io.nu_rgi as varchar(20))) AS "nu_rgi"
       , coalesce(try(cast (io.va_avaliacao_provisoria as double)),0) AS "va_avaliacao_provisoria"
       , cast(try(date_parse(io.dt_primeira_avaliacao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_primeira_avaliacao"
       , coalesce(try(cast (io.va_primeira_avaliacao as double)),0) AS "va_primeira_avaliacao"
       , cast(try(date_parse(io.dt_segunda_avaliacao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_segunda_avaliacao"
       , coalesce(try(cast (io.va_segunda_avaliacao as double)),0) AS "va_segunda_avaliacao"
       , try(cast(io.co_uf as char(2))) AS "co_uf"  
       , try(cast(io.nu_municipio as varchar(5))) AS "nu_municipio" 
       , cast(io.no_primeira_avaliacao as varchar(60)) AS "no_primeira_avaliacao"         
       , try(cast(io.in_titulo_aquisitivo as char(1))) AS "in_titulo_aquisitivo"  
       , cast(io.no_segunda_avaliacao as varchar(60)) AS "no_segunda_avaliacao" 
       , try(cast(io.nu_ddd_avaliacao as char(3))) AS "nu_ddd_avaliacao" 
       , try(cast(io.nu_telefone_avaliacao as varchar(11))) AS "nu_telefone_avaliacao" 
       , try(cast(io.nu_ddd_celular_avaliacao as char(3))) AS "nu_ddd_celular_avaliacao" 
       , try(cast(io.nu_celular_avaliacao as varchar(11))) AS "nu_celular_avaliacao" 
       , try(cast(io.in_contato_avaliacao as char(1))) AS "in_contato_avaliacao" 
       , try(cast(io.no_tipo_contato_avaliacao as varchar(40))) AS "no_tipo_contato_avaliacao"   
       , try(cast(io.no_pessoa_contato as varchar(20))) AS "no_pessoa_contato" 
       , try(cast(io.nu_ddd_pessoa_contato as char(3))) AS "nu_ddd_pessoa_contato"   
       , try(cast(io.nu_telefone_pessoa_contato as varchar(11))) AS "nu_telefone_pessoa_contato" 
       , try(cast(io.no_horario_avaliacao as varchar(20))) AS "no_horario_avaliacao" 
       , try(cast(io.no_tabelionato as varchar(60))) AS "no_tabelionato" 
       , try(cast(io.nu_livro_registro as varchar(30))) AS "nu_livro_registro" 
       , try(cast(io.nu_folhas_registro as varchar(30))) AS "nu_folhas_registro" 
       , try(cast(io.no_complemento_endereco as varchar(30))) AS "no_complemento_endereco" 
       , coalesce(try(cast (io.va_publicacao_leilao as double)),0) AS "va_publicacao_leilao"
       , try(cast(io.nu_cep as varchar(9))) AS "nu_cep"
       , cast(try(date_parse(io.dt_instrumento_comp_anterior,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_instrumento_comp_anterior"
       , try(cast(io.co_forma_comp_anterior as char(1))) AS "co_forma_comp_anterior"
       , try(cast(io.no_livro_comp_anterior as varchar(30))) AS "no_livro_comp_anterior" 
       , try(cast(io.no_folhas_comp_anterior as varchar(30))) AS "no_folhas_comp_anterior"
       , try(cast(io.no_matricula_comp_anterior as varchar(30))) AS "no_matricula_comp_anterior" 
       , try(cast(io.no_reg_averb_comp_anterior as varchar(30))) AS "no_reg_averb_comp_anterior" 
       , cast(try(date_parse(io.dt_posse_comp_anterior,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_posse_comp_anterior"
       , try(cast (io.co_empreendimento as smallint)) AS "co_empreendimento"
       , try(cast (io.co_imovel as bigint)) AS "co_imovel"
       , try(cast(io.no_imovel_novo as char(1))) AS "no_imovel_novo"  
       , coalesce(try(cast (io.va_terreno as double)),0) AS "va_terreno"
       , try(cast(io.nu_laudo_avaliacao as varchar(15))) AS "nu_laudo_avaliacao" 
       , try(cast(io.co_uf_cartorio_registro as char(2))) AS "co_uf_cartorio_registro" 
       , try(cast (io.co_municipio_cartorio_registro as integer)) AS "co_municipio_cartorio_registro"
       , try(cast (io.co_nivel_liquidez_garantia as smallint)) AS "co_nivel_liquidez_garantia"
       , try(cast (io.nu_idade_imovel as smallint)) AS "nu_idade_imovel"
       , cast( case
          when upper(io.in_foto) = 'F' then 'false'
          when upper(io.in_foto) = 'T' then 'true'
          else 'false'
        end as boolean) "in_foto"
       , coalesce(try(cast (io.va_area_averbada as double)),0) AS "va_area_averbada"
       , coalesce(try(cast (io.va_area_nao_averbada as double)),0) AS "va_area_nao_averbada"
       , coalesce(try(cast (io.va_area_imovel as double)),0) AS "va_area_imovel"
       , try(cast(io.in_vicio_construtivo as char(1))) AS "in_vicio_construtivo"  
       , try(cast(io.in_vicio_afeta_im as char(1))) AS "in_vicio_afeta_im" 
       , try(cast(io.in_local_risco as char(1))) AS "in_local_risco" 
       , cast( case
          when upper(io.in_enquadrado) = 'F' then 'false'
          when upper(io.in_enquadrado) = 'T' then 'true'
          else 'false'
        end as boolean) "in_enquadrado"
       , cast( case
          when upper(io.in_restricao_enquadramento) = 'F' then 'false'
          when upper(io.in_restricao_enquadramento) = 'T' then 'true'
          else 'false'
        end as boolean) "in_restricao_enquadramento"
       , try(cast(io.co_usuario_avaliacao as varchar(20))) AS "co_usuario_avaliacao"
       , cast(try(date_parse(io.dt_registro_avaliacao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_registro_avaliacao"
       , coalesce(try(cast (io.va_area_construida as double)),0) AS "va_area_construida"
       , try(cast (io.co_enquadramento_avaliacao as integer)) AS "co_enquadramento_avaliacao"
       , try(cast(io.in_tipo_imovel as char(1))) AS "in_tipo_imovel" 
       , try(cast (io.in_uso_do_imovel as smallint)) AS "in_uso_do_imovel"
       , try(cast (io.co_tipo_imovel as integer)) AS "co_tipo_imovel"
       , coalesce(try(cast (io.nu_testada as double)),0) AS "nu_testada"
       , coalesce(try(cast (io.co_implantacao as integer)),0) AS "co_implantacao"
       , coalesce(try(cast (io.co_est_conserv as integer)),0) AS "co_est_conserv"
       , coalesce(try(cast (io.co_padrao_acab as integer)),0) AS "co_padrao_acab"
       , coalesce(try(cast (io.co_estr_serv_condom as integer)),0) AS "co_estr_serv_condom"
       , try(cast(io.co_grau_hipoteca as char(1))) AS "co_grau_hipoteca"
       , coalesce(try(cast (io.qt_quartos as integer)),0) AS "qt_quartos"
       , coalesce(try(cast (io.qt_vaga_garagem as integer)),0) AS "qt_vaga_garagem"
       , try(cast(io.co_cartorio_registro as char(3))) AS "co_cartorio_registro" 
       , cast(try(date_parse(io.dt_registro_averbacao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_registro_averbacao"
       , cast( case
          when upper(io.in_matricula_box_garagem) = 'F' then 'false'
          when upper(io.in_matricula_box_garagem) = 'T' then 'true'
          else 'false'
        end as boolean) "in_matricula_box_garagem"
       , coalesce(try(cast (io.va_area_privativa as double)),0) AS "va_area_privativa"
       , coalesce(try(cast (io.va_area_terreno as double)),0) AS "va_area_terreno"
       , cast(try(date_parse(io.dt_compra_venda,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_compra_venda"
       , coalesce(try(cast (io.nu_box as integer)),0) AS "nu_box"
       , try(cast(io.nu_vaga_garagem as varchar(7))) AS "nu_vaga_garagem"
       , cast( case
          when upper(io.in_registrado) = 'F' then 'false'
          when upper(io.in_registrado) = 'T' then 'true'
          else 'false'
        end as boolean) "in_registrado"
       , coalesce(try(cast (io.co_imv_cliente as integer)),0) AS "co_imv_cliente"
       , try(cast(io.no_nome_corretor as varchar(40))) AS "no_nome_corretor"
       , try(cast(io.nu_num_creci as varchar(10))) AS "nu_num_creci"
       , try(cast(io.nu_registro_comp_anterior as varchar(20))) AS "nu_registro_comp_anterior"
       , try(cast(io.co_cartorio_comp_anterior as varchar(3))) AS "co_cartorio_comp_anterior"
       , coalesce(try(cast (io.tp_garantia_comp_anterior as smallint)),0) AS "tp_garantia_comp_anterior"
       , try(cast(io.nu_averbacao_comp_anterior as varchar(20))) AS "nu_averbacao_comp_anterior"
       , try(cast(io.in_liquidacao_comp_anterior as char(1))) AS "in_liquidacao_comp_anterior" 
       , cast( case
          when upper(io.in_alienado_proprio) = 'F' then 'false'
          when upper(io.in_alienado_proprio) = 'T' then 'true'
          else 'false'
        end as boolean) "in_alienado_proprio"
       , coalesce(try(cast (io.va_area_comum as double)),0) AS "va_area_comum"
       , coalesce(try(cast (io.va_area_util as double)),0) AS "va_area_util"
       , coalesce(try(cast (io.va_area_privdescoberta as double)),0) AS "va_area_privdescoberta"
       , coalesce(try(cast (io.va_area_privterreo as double)),0) AS "va_area_privterreo"
       , coalesce(try(cast (io.va_area_pavsuperior as double)),0) AS "va_area_pavsuperior"
       , coalesce(try(cast (io.va_area_nedificavel as double)),0) AS "va_area_nedificavel"
       , coalesce(try(cast (io.va_area_condominio as double)),0) AS "va_area_condominio"
       , coalesce(try(cast (io.va_fracao_ideal as double)),0) AS "va_fracao_ideal"
       , coalesce(try(cast (io.va_fracao_ideal_garagem as double)),0) AS "va_fracao_ideal_garagem"
       , try(cast(io.nu_andar as varchar(5))) AS "nu_andar"
       , coalesce(try(cast (io.co_tipogaragem as integer)),0) AS "co_tipogaragem"
FROM scci_raw.imovel_operacao as io