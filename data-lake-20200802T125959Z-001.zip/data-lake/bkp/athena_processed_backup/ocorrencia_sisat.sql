CREATE TABLE IF NOT EXISTS scci_processed.ocorrencia_sisat
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/OCORRENCIA_SISAT/')
AS
SELECT   cast (os.nu_ocorrencia as bigint) AS "nu_ocorrencia"	 
       , cast (os.cod_ent as integer) AS "cod_ent"
       , lower(cast(os.co_gestor as varchar(15))) AS "co_gestor"   
       , cast (os.co_status as varchar(3)) AS "co_status"  
       , cast (os.nu_contrato as varchar(10)) AS "nu_contrato" 
       , cast (os.co_tarefa_padrao as char(3)) AS "co_tarefa_padrao" 
       , cast(try(date_parse(os.dt_cadastramento,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_cadastramento"
       , cast(try(date_parse(os.dt_inicio_execucao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_inicio_execucao"
       , cast(try(date_parse(os.dt_fim_execucao,'%Y-%m-%d %H:%i:%s')) as timestamp) as "dt_fim_execucao"
       , cast(try(date_parse(os.dt_previsao_inicio,'%Y-%m-%d %H:%i:%s')) as date) as "dt_previsao_inicio"
       , cast(try(date_parse(os.dt_previsao_fim,'%Y-%m-%d %H:%i:%s')) as date) as "dt_previsao_fim"
       , lower(cast(os.co_usuario_cadastramento as varchar(15))) AS "co_usuario_cadastramento" 
       , try(cast(os.nu_ocorrencia_anterior as bigint)) AS "nu_ocorrencia_anterior"
       , try(cast(os.nu_protocolo_sisat as bigint)) AS "nu_protocolo_sisat"
       , cast (os.co_setor_execucao as varchar(5)) AS "co_setor_execucao" 
       , cast (os.nu_pretendente as varchar(9)) AS "nu_pretendente"
       , try(cast(os.nu_ocorrencia_inicial as bigint)) AS "nu_ocorrencia_inicial"
       , try(cast(os.co_entidade_execucao as smallint)) AS "co_entidade_execucao"       
       , try(cast(os.in_tipo_tarefa as char(1))) AS "in_tipo_tarefa"       
       , try(cast(os.nu_id_documento_gerado as integer)) AS "nu_id_documento_gerado"       
       , try(cast(os.co_conjunto_aquisicao as char(1))) AS "co_conjunto_aquisicao"  
       , cast( case
          when upper(os.in_tarefa_automatica) = 'F' then 'false'
          when upper(os.in_tarefa_automatica) = 'T' then 'true'
          else 'false'
        end as boolean) "in_tarefa_automatica"
FROM scci_raw.ocorrencia_sisat as os