CREATE TABLE IF NOT EXISTS scci_processed.status
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/STATUS/')
AS
SELECT cast (s.no_status as varchar(40)) AS "no_status"
      ,cast (s.co_status as varchar(3)) AS "co_status"
      ,cast (s.in_tipo_status as char(1)) AS "in_tipo_status"
FROM scci_raw.status as s;