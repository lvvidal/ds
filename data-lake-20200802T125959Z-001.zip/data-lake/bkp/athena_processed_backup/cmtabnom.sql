
CREATE TABLE IF NOT EXISTS scci_processed.cmtabnom
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/CMTABNOM/')
AS
SELECT
	try(cast (cm.codigo as smallint)) AS "codigo",
	cast (cm.nometab as varchar(30)) as "nometab",
	try(cast(cm.tipo as char(1))) as "tipo",
	try(cast (cm.dialimitecad as smallint)) as "dialimitecad",
	try(cast (cm.defasagem as smallint)) as "defasagem",
	cast (cm.co_indice_cliente as varchar(4)) as "co_indice_cliente",
	cast (cm.co_ind_base_cliente as varchar(4)) as "co_ind_base_cliente",
	try(cast (cm.co_indice_bacen as smallint)) as "co_indice_bacen",
	try(cast (cm.indxcentralderisco as smallint)) as "indxcentralderisco",
	try(cast(cm.edicao as char(1))) as "edicao",
	try(cast(cm.codreajanexo16 as char(1))) as "codreajanexo16",
	try(cast(cm.proratadiasuteis as char(1))) as "proratadiasuteis",
	cast (cm.co_fonte_indice as varchar(4)) as "co_fonte_indice"
FROM scci_raw.cmtabnom as cm