CREATE TABLE IF NOT EXISTS scci_processed.profissao_pretendente
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/PROFISSAO_PRETENDENTE/')
AS
SELECT    try(cast(prp.co_profissao as integer)) AS "co_profissao"
        , upper(try(cast (prp.no_profissao as varchar(200)))) AS "no_profissao"
        , lower(try(cast (prp.no_usuario as varchar(21)))) AS "no_usuario"
        , cast(try(date_parse(prp.dt_ultima_atualizacao,'%Y-%m-%d %H:%i:%s')) as date) as "dt_ultima_atualizacao"      
FROM scci_raw.profissao_pretendente as prp;