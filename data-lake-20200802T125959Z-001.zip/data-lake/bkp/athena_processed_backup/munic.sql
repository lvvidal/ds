CREATE TABLE IF NOT EXISTS scci_processed.munic
WITH (
     format = 'TEXTFILE', 
     external_location = 's3://{bucket_name}/scci/MUNIC/')
AS
SELECT  cast (m.municibge as varchar(7)) AS "municibge"
      , cast (m.chavemun as varchar(5)) AS "chavemun"
      , cast (m.nomemun as varchar(50)) AS "nomemun"
      , cast (m.ufmun as char(3)) AS "ufmun"
      , cast (m.municdimob as integer) AS "municdimob"
      , cast (m.municserpro as integer) AS "municserpro"
FROM scci_raw.munic as m;