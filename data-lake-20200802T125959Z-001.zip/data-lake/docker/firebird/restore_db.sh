#!/bin/bash

set -e

# Database in securitizadora, hipotecaria, banco
DATABASE=$1

# date_time format YYYY-MM-DD
date_time=$2

year=$(echo $date_time | cut -d'-' -f1)
month=$(echo $date_time | cut -d'-' -f2)
day=$(echo $date_time | cut -d'-' -f3)

DBDIR="/firebird/data/${DATABASE}/${date_time}"
BACKUP_FILE="${DATABASE}.gbk"
TARGET_FILE="${DATABASE}.gdb"
BACKUP_FILE_BZ2="${DATABASE}.gbk.bz2"

pushd ${DBDIR}

echo "Extract file $BACKUP_FILE_BZ2"
rm -f ${BACKUP_FILE}
bunzip2 -k $BACKUP_FILE_BZ2

echo "Restoring ${BACKUP_FILE} database"
/usr/local/firebird/bin/gbak -v -c -REP -user "sysdba" -password "masterkey" \
    "${DBDIR}/${BACKUP_FILE}" \
    "${DBDIR}/${TARGET_FILE}"

popd