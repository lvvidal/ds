#!/bin/bash

set -e

backup_bucket=$1
backup_key=$2
base=$3
date_time=$4

env

year=$(echo $date_time | cut -d'-' -f1)
month=$(echo $date_time | cut -d'-' -f2)
day=$(echo $date_time | cut -d'-' -f3)

data_dir="/firebird/data/${base}"

# check if data_dir exists
if [ ! -d $data_dir ]; then
    mkdir -p $data_dir
fi

echo "remove old data dirs"
cd $data_dir || exit 1
echo "dirs to remove $(ls ????-??-??)"
rm -rf ????-??-??

base_dir="${data_dir}/${year}-${month}-${day}"
csv_dir="$base_dir/csv"
ddl_dir="$base_dir/ddl"

if [ ! -d $csv_dir ]; then
    echo "criating dir $csv_dir"
    mkdir -p $csv_dir
fi
if [ ! -d $ddl_dir ]; then
    echo "criating dir $ddl_dir"
    mkdir -p $ddl_dir
fi

echo "change dir $base_dir"
pushd $base_dir

s3_path="s3://${backup_bucket}/$backup_key"

echo "donwload file $s3_path to $(pwd)"
aws s3 cp "$s3_path" .

popd


# ./download_backup_from_s3.sh bancobari-prognum-backup-724358820973 scci/2020/02/02/securitizadora.gbk.bz2 securitizadora 2020-02-02