#!/bin/bash

alias ll="ls -lha --color"

/etc/init.d/ssh restart

/usr/local/firebird/bin/fbguard
