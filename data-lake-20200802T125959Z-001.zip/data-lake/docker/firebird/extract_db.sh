#!/usr/bin/env bash

set -e

# database in securitizadora, banco, hipotecaria
DATABASE_NAME=$1

# datetime format YYYY-MM-DD
DATE_TIME=$2

year=$(echo $DATE_TIME | cut -d'-' -f1)
month=$(echo $DATE_TIME | cut -d'-' -f2)
day=$(echo $DATE_TIME | cut -d'-' -f3)

DATABASE=/firebird/data/${DATABASE_NAME}/${year}-${month}-${day}/${DATABASE_NAME}.gdb

TABLES=$(python3 /list_tables.py ${DATABASE})

BASE_DIR=/firebird/data/${DATABASE_NAME}/${year}-${month}-${day}/csv

if [ ! -d ${BASE_DIR} ]; then
    mkdir -p ${BASE_DIR}
fi

for table in $TABLES; do

    table_dir="${BASE_DIR}/${table}"

    if [ ! -d $table_dir ]; then
        mkdir -p "${table_dir}"
    fi

    csv_file="${table_dir}/$table.csv"

    echo "extract_table $table to $csv_file"
    python3 /extract_table.py "$DATABASE" "$table" "$csv_file"

    # TODO: Gzipar sem remover csv
    # echo "gzip $csv_file"
    # gzip "$csv_file"

done