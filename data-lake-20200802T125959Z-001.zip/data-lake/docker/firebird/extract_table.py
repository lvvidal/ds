import sys
import fdb
import codecs
from datetime import date, datetime
import os

_, *args = sys.argv

if len(args) != 3:
    raise Exception("Usage: python extract_table.py database table outfile")

database, table, outfile, *rest = args
separator = '\u0001'

outfile_dir = os.path.dirname(outfile)
if not os.path.exists(outfile_dir):
    os.makedirs(outfile_dir)

print("connecting to database={} table={}".format(database, table))

# Get all tables from database
con = fdb.connect(database=database, user='sysdba', password='masterkey', charset='iso8859_1')

# Get columns names and types
ftypes = {
    7: int,
    8: int,
    10: float,
    12: date,
    13: datetime,
    14: str,
    16: int,
    27: float,
    35: datetime,
    37: str,
    261: fdb.fbcore.BlobReader
}

defaults = {
    int: "",
    float: "",
    str: '""',
    date: "",
    datetime: "",
    fdb.fbcore.BlobReader: ""
}

meta_query  = """SELECT A.rdb$field_name, B.rdb$field_type FROM rdb$relation_fields A 
    INNER JOIN rdb$fields B ON B.rdb$field_name = A.rdb$field_source 
    WHERE rdb$relation_name='{}';""".format(table)

print(meta_query)

def dtype_filter(dtype):
    dtypes_blacklist = [fdb.fbcore.BlobReader]
    return dtype != fdb.fbcore.BlobReader


cur = con.cursor()
cur.execute(meta_query)
columns = [(fname.strip(), ftypes.get(ftype)) for fname, ftype in cur.fetchall()]
columns = [col for col in columns if dtype_filter(col[1])]
cur.close()


def double_enquote(value):
    return '"{}"'.format(value)


def stringify(field, dtype):
    try:
        if field is None:
            return defaults.get(dtype)
        if dtype == date:
            return field.strftime("%Y-%m-%d")
        if dtype == datetime:
            return field.strftime("%Y-%m-%d %H:%M:%S")
        if dtype == bytes:
            striped = field.strip()
            if len(striped) > 0:
                return double_enquote(str(field.replace(b'"', b'\\"')))
            return double_enquote("")
        if dtype == str:
            striped = field.strip()
            if len(striped) > 0:
                return double_enquote(striped.replace('"', '\\"'))
            return double_enquote("")
        if dtype == int or dtype == float:
            if isinstance(field, (int, float)):
                return str(field)
            return ""
        raise Exception("Unknown dtype {}".format(dtype.__name__))
    except Exception as ex:
        return ""


# Output to csv
cur = con.cursor()
colnames = [c[0] for c in columns]
coltypes = [c[1] for c in columns]
cur.execute("select {} from {}".format(','.join(colnames), table))
with codecs.open(outfile, mode='w', encoding='utf8') as fp:
    fp.write(separator.join(colnames) + '\n')
    for row in cur:
        values = [stringify(column, dtype) for column, dtype in zip(row, coltypes)]
        fp.write(separator.join(values) + '\n')
cur.close()
