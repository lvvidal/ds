#!/bin/bash

set -e

database=$1
destination_bucket=$2
date_time=$3

year=$(echo $date_time | cut -d'-' -f1)
month=$(echo $date_time | cut -d'-' -f2)
day=$(echo $date_time | cut -d'-' -f3)

csv_dir="/firebird/data/${database}/${date_time}/csv"
ddl_dir_raw="/firebird/data/${database}/${date_time}/ddl/raw"

destination_path="s3://${destination_bucket}/scci/${database}/${year}/${month}/${day}"

echo "upload files to s3 $csv_dir $ddl_dir_raw on date ${year}-${month}-${day}"

echo "uploading csv"
cd ${csv_dir} || exit 1
aws s3 sync . "${destination_path}/csv/" --delete

echo "uploading ddl raw"
cd ${ddl_dir_raw} || exit 1
aws s3 sync . "${destination_path}/ddl/" --delete

# /upload_files_to_s3.sh securitizadora bancobari-prognum-raw-724358820973 2020-02-02

