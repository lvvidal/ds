#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import fdb
import codecs
import json
import re
import os
from datetime import date, datetime
import glob
import shutil

separator = '\u0001'

SMALLINT = [7]
INTEGER = [8]
DOUBLE = [10, 27]
DATE = [12]
TIME = [13]
CHAR = [14]
VARCHAR = [37]
BIGINT = [16]
TIMESTAMP = [35]
BLOB = [261]


ftypes = {
    7: int,  # SHORT 16BIT
    8: int,  # LONG
    10: float,  # FLOAT
    12: date,  # DATE
    13: datetime,  # TIME
    14: str,  # TEXT
    16: int,  # INT64
    27: float,  # DOUBLE
    35: datetime,  # TIMESTAMP
    37: str,  # VARYING
    261: fdb.fbcore.BlobReader  # BLOB
}

# https://firebirdsql.org/manual/migration-mssql-data-types.html
# https://firebirdsql.org/file/documentation/reference_manuals/fblangref25-en/html/fblangref25-appx04-systables.html
# https://firebirdsql.org/file/documentation/reference_manuals/fblangref25-en/html/fblangref-appx04-fields.html

ftypes_str = {
    7: "SMALLINT",  # SHORT 16 bit
    8: "INTEGER",  # LONG
    10: "DOUBLE",  # FLOAT
    12: "DATE",  # DATE
    13: "TIME",  # TIME
    14: "CHAR",  # TEXT / CHAR
    16: "BIGINT",  # INT64
    27: "DOUBLE",  # DOUBLE
    35: "TIMESTAMP",  # TIMESTAMP
    37: "VARCHAR",  # VARYING
    261: "BLOB"  # BLOB
}

table_column = {
    'ocorrencia_sisat': {
        'co_gestor': {
            'functions': ['lower']
        },
        'co_usuario_cadastramento': {
            'functions': ['lower']
        }
    },
    'munic': {
        'chavemun': {
            'column_type_id': 8
        }
    }
}

def manual_data_type(table, column):
    try:
        c_type_id = table_column[table][column]["column_type_id"]
        return c_type_id
    except KeyError:
        return None


def apply_functions(table, column, sql):
    # if table in table_column and column in table_column[table] and "functions" in table_column[table][column]:
    try:
        for func in table_column[table][column]:
            if func.lower() == "lower":
                return "lower({})".format(sql)
            elif func.upper() == "upper":
                return "upper({})".format(sql)
    except KeyError:
        return sql

def is_boolean(conn, table, column, metadata):
    sql = """SELECT DISTINCT UPPER(t.{column}) AS c 
            FROM {table} t """.format(**{'column': column, 'table': table})
    cur = conn.cursor()
    cur.execute(sql)
    for (b, ) in cur.fetchall():
        if b is not None and b not in ["V", "F", "T"]:
            return False
    return True

def col_char(conn, table, column, metadata):
    # if column == 'cad6_in_acordoautos':
    #     print("to_char(table={}, column={}, metadata={})".format(table, column, metadata))

    # test if  char(1) is a boolean
    if metadata is not None and metadata['length'] == 1:
        if is_boolean(conn, table, column, metadata):
            return col_boolean(table, column, metadata)

    if metadata is not None and metadata['length'] is not None:
        type_str = "char({})".format(metadata['length'])
    else:
        type_str = "char"

    sql_part = "try(cast({table}.{column} as {type_str}))".format(**{'table': table, 'column': column,
                                                                     'type_str': type_str})

    sql_part = apply_functions(table, column, sql_part)

    sql = """{sql_part} AS "{column}" """.format(**{'sql_part': sql_part, 'column': column})

    return sql


def col_varchar(table, column, metadata):

    if metadata is not None and metadata['length'] is not None:
        type_str = "varchar({length})".format(length=metadata['length'])
    else:
        type_str = "varchar"

    sql = """try(cast({table}.{column} as {type_str})) AS "{column}" """.format(
        **{'table': table, 'column': column, 'type_str': type_str})
    return sql


def col_boolean(table, column, metadata):
    sql = """try(cast(case
        when upper({table}.{column}) = 'F' then 'false'
        when upper({table}.{column}) = 'T' then 'true'
        else 'false'
      end as boolean)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_double(table, column, metadata):
    sql = """try(cast({table}.{column} as double)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_float(table, column, metadata):
    sql = """try(cast({table}.{column} as float)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_bigint(table, column, metadata):
    sql = """try(cast({table}.{column} as bigint)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_integer(table, column, metadata):
    sql = """try(cast({table}.{column} as integer)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_smallint(table, column, metadata):
    sql = """try(cast({table}.{column} as smallint)) as "{column}" """.format(**{'table': table, 'column': column})
    return sql


def col_date(table, column, metadata):
    sql = """try(cast(date_parse({table}.{column}, '%Y-%m-%d %H:%i:%s') as date)) as "{column}" """.format(
        **{'table': table, 'column': column})
    return sql


def col_timestamp(table, column, metadata):
    sql = """try(cast(date_parse({table}.{column}, '%Y-%m-%d %H:%i:%s') as timestamp)) as "{column}" """.format(
        **{'table': table, 'column': column})
    return sql


def col_date_timestamp(conn, table, column, metadata):
    sql = """
    SELECT DISTINCT CAST({column} AS time)
    FROM {table} p
    WHERE {column} IS NOT NULL
    """.format(table=table, column=column)
    cur = conn.cursor()
    cur.execute(sql)
    if len(cur.fetchall()) == 1:
        return col_date(table, column, metadata=None)
    else:
        return col_timestamp(table, column, metadata=None)


def generate_metadata(conn, table):

    sql = """
            |SELECT  rf.rdb$field_name "field_name", f.rdb$field_type "field_type", f.rdb$field_length "field_length", 
            |        f.RDB$FIELD_PRECISION AS "precision", f.RDB$FIELD_SCALE AS "scale", 
            |        CASE 
            |            WHEN  f.RDB$DEFAULT_VALUE IS NOT NULL THEN f.RDB$DEFAULT_VALUE 
            |            WHEN rf.RDB$DEFAULT_VALUE IS NOT NULL THEN rf.RDB$DEFAULT_VALUE
            |            ELSE NULL
            |        END AS "default"
            |FROM rdb$relation_fields rf 
            |INNER JOIN rdb$fields f ON f.rdb$field_name = rf.rdb$field_source
            |WHERE f.rdb$field_type <> 261
            |AND rf.rdb$relation_name = '{table}'
            |""".format(table=table.upper())

    sql = re.sub(" *\\|", "", sql)

    cur = conn.cursor()
    cur.execute(sql)
    metadata = {}
    for fname, ftype, flength, precision, scale, default in cur.fetchall():

        fname = fname.strip()
        # print("fname='{fname}' ftype='{ftype}'".format(...))
        # if default is not None:
            # default = default.decode('utf-8').strip().upper()
        metadata[fname] = {
            "type_id": ftype,
            "type": ftypes[ftype],
            "type_str": ftypes_str[ftype],
            "length": flength,
            "precision": precision,
            "scale": scale,
            "default": default,
            "default_type": type(default)
        }
        # print(f'column={fname} => {metadata[fname]}')
    print("table={} #metadata_keys={}".format(table, len(metadata.keys())))
    return metadata


def get_column_ddl(conn, table, column, metadata):

    manual_column_type = manual_data_type(table, column)

    if manual_column_type is not None:
        column_type = manual_column_type
    else:
        column_type = metadata['type_id']

    if column_type in SMALLINT:
        return col_smallint(table, column, metadata)
    elif column_type in INTEGER:
        return col_integer(table, column, metadata)
    elif column_type in BIGINT:
        return col_bigint(table, column, metadata)
    elif column_type in DOUBLE:
        return col_double(table, column, metadata)
    elif column_type in VARCHAR:
        return col_varchar(table, column, metadata)
    elif column_type in CHAR:
        return col_char(conn, table, column, metadata)
    elif column_type in TIMESTAMP:
        return col_timestamp(table, column, metadata)
    elif column_type in DATE:
        return col_date(table, column, metadata)
    else:
        print("error generating column line table={table} column={column} metadata={metadata}".format(
            **{'table': table, 'column': column, 'metadata': metadata}))
        return ""


hipotecaria = 0
securitizadora = 1
banco = 2

# /firebird/data/securitizadora/2020-02-09/ddl

def get_conn(database_name, database_base_dir, ds_str):
    database_gdb = "{database_base_dir}/{database_name}/{ds_str}/{database_name}.gdb".format(
        **{'database_base_dir': database_base_dir, 'database_name': database_name, 'ds_str': ds_str})

    if os.path.exists(database_gdb):
        conn = fdb.connect(database=database_gdb, user='sysdba', password='masterkey', charset='iso8859_1')
        return conn
    else:
        return None


def count_records_table(conn, table_name):
    sql = "select count(*) as c from {t}".format(t=table_name)
    cur = conn.cursor()
    cur.execute(sql)
    count = cur.fetchall()[0][0]
    return count


def clean_directory(processed_dir, ds_str):
    for f in glob.glob("{dir}/????-??-??".format(dir=processed_dir)):
        if ds_str in f:
            continue
        else:
            print("removing directory {}".format(f))
            shutil.rmtree(f)
    pass


def process(_database_name_list, database_base_dir, ds_str):

    processed_dir = "{}/processed".format(database_base_dir)

    clean_directory(processed_dir, ds_str)

    conn_dict = {}

    # verify if exist database file for all database, and skip that ones not ready
    database_name_list = []
    for db in _database_name_list:
        conn = get_conn(db, database_base_dir, ds_str)
        if conn is not None:
            conn_dict[db] = conn
            database_name_list.append(db)

    table_list = [
          'ARQAG31'
        , 'CADMUT'
        , 'CMTABNOM'
        , 'EMPREENDIMENTOS'
        , 'IMOVEL_OPERACAO'
        , 'ENTIDADE_SCCI'
        , 'MUNIC'
        , 'OCORRENCIA_SISAT'
        , 'OPERACAO_CREDITO'
        , 'PAGAMENTOS'
        , 'PARCELAS'
        , 'PESSOA_PRETENDENTE'
        , 'POSICAO_ATRASO'
        , 'PRETENDENTE'
        , 'PROFISSAO_PRETENDENTE'
        , 'RPA'
        , 'SERIES'
        , 'SETOR'
        , 'STATUS'
        , 'TABCTA'
        , 'FASE_OPERACAO'
        , 'HISTORICO_OPERACAO'
        , 'TAREFA_PADRAO'
        , 'TIPO_OPERACAO'
        , 'USUARIO'
        , 'TPSERIE'
        , 'TIPOIMV'
        , 'CADIMV'
        , 'CARTEIRA'
        , 'CADRENDA'
        , 'TAB_CARTORIO'
        , 'ENTIDADES'
    ]

    athena_processed_schema = "scci_processed"

    for table_name in table_list:

        table_name = table_name.lower()

        sql = """
            |-- bancobari-prognum-raw-724358820973
            |-- bancobari-prognum-processed-724358820973
            |-- bancobari-prognum-business-724358820973
            |
            |CREATE TABLE IF NOT EXISTS {athena_processed_schema}.{table_name}
            |WITH (
            |    format = 'TEXTFILE', 
            |    external_location = 's3://{{bucket_name}}/scci/processed/{table_name_upper}/')
            |AS""".format(table_name=table_name, table_name_upper=table_name.upper(),
                          athena_processed_schema=athena_processed_schema)


        ignore_db = []
        columns_intersect = []
        for database_name in database_name_list:
            conn = conn_dict[database_name]
            metadata = generate_metadata(conn, table_name)
            if len(metadata.keys()) != 0 and count_records_table(conn, table_name) > 0:
                columns_intersect.append([m.lower() for m in metadata.keys()])
            else:
                ignore_db.append(database_name)
        tmp = None
        for ci in columns_intersect:
            if tmp is None:
                tmp = set(ci)
            else:
                tmp = tmp.intersection(ci)
        columns_to_use = tmp
        print("columns to use in table_name {table_name} => {c}".format(table_name=table_name, c=tmp))

        print("for table={table} ignore databases=[{dbs}]".format(table=table_name, dbs=", ".join(ignore_db)))

        tables = []
        columns = []
        for database_name in database_name_list:

            if database_name in ignore_db:
                continue

            conn = conn_dict[database_name]

            metadata = generate_metadata(conn, table_name)

            # all columns need to be the same to perform an UNION of the databases, so columns is generated once.
            if len(columns) == 0:
                for fname, metadata_val in metadata.items():
                    if fname.lower() in columns_to_use:
                        ddl = get_column_ddl(conn, table_name.lower(), fname.lower(), metadata_val)
                        if ddl != "":
                            columns.append(ddl)

            athena_raw_schema = "scci_{database_name}_raw".format(**{'database_name': database_name})

            columns_t = "\n|    , ".join(columns)

            if "arqag31" in table_name.lower() and "datatermino" not in columns_t:
                if database_name in ("hipotecaria", "banco"):
                    columns_t = columns_t + '\n|    , try(cast(date_parse(arqag31.datatermino, \'%Y-%m-%d %H:%i:%s\') as timestamp)) as "datatermino"'
                else:
                    columns_t = columns_t + '\n|    , null as "datatermino"'

            sql_t = """SELECT 
                      |      {columns}
                      |    , CASE '{database_name}'
                      |        WHEN 'hipotecaria' THEN  {hipotecaria}
                      |        WHEN 'securitizadora' THEN {securitizadora}
                      |        WHEN 'banco' THEN {banco}
                      |    END as "origem"
                      |    , try(cast(date_parse('{ds_str}', '%Y-%m-%d') as date)) as "data_observacao"
                      |FROM {athena_raw_schema}.{table_name} as {table_name};
                      |
                      |""".format(columns=columns_t, database_name=database_name,
                                  hipotecaria=hipotecaria, securitizadora=securitizadora,
                                  banco=banco, table_name=table_name,
                                  athena_raw_schema=athena_raw_schema, ds_str=ds_str)
            tables.append(sql_t)

        ddl_processed_dir = "{database_base_dir}/processed/{ds_str}/ddl".format(
            database_base_dir=database_base_dir, ds_str=ds_str)

        if not os.path.exists(ddl_processed_dir):
            os.makedirs(ddl_processed_dir)

        final_sql = None
        for idx, t in enumerate(tables):
            if final_sql is None:
                final_sql = sql + "\n" + t
            else:
                final_sql = "insert into {schema}.{table}\n{select}".format(
                    schema=athena_processed_schema, table=table_name, select=t)

            # Scala like multi line string
            sql = re.sub(" *\\|", "", final_sql)

            file = "{ddl_processed_dir}/auto_{table_name}_{idx:03d}.sql".format(
                ddl_processed_dir=ddl_processed_dir, table_name=table_name, idx=idx)

            print(file)
            print(sql)

            with open(file, 'w') as f:
                f.write(sql)

    [c.close() for c in conn_dict.values()]


if __name__ == "__main__":

    _, *args = sys.argv

    if len(args) != 3:
        raise Exception("Usage: python create_ddl_processed_athena_tables.py database_name_list date database_dir")

    database_name_list, ds_str, database_dir, *rest = args
    database_name_list = database_name_list.split(",")

    print('database_name_list={}'.format(database_name_list))

    print(os.getcwd())

    process(database_name_list, database_dir, ds_str)


# python3 create_ddl_processed_athena_tables.py banco,hipotecaria,securitizadora 2020-02-10 /tmp/ddl