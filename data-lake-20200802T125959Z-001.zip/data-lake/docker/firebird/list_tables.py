import sys

_, *args = sys.argv

if len(args) == 0:
    raise Exception("Usage: python list_tables.py database_file")

database, *rest = args

import fdb

# Get all tables from database
con = fdb.connect(database=database, user='sysdba', password='masterkey', charset='iso8859_1')
cur = con.cursor()
cur.execute("select rdb$relation_name from rdb$relations \
             where rdb$view_blr is null and (rdb$system_flag is null or rdb$system_flag = 0)")


def is_table_empty(connection, table):
    """Predicate that checks if table is empty"""
    cursor = connection.cursor()
    cursor.execute("select first 1 * from {}".format(table))
    results = cursor.fetchall()
    cursor.close()
    return len(results) == 0


# Reject tables that doest not contain any data
print(' '.join([table.strip() for table, in cur if not is_table_empty(connection=con, table=table.strip())]))

cur.close()
con.close()
