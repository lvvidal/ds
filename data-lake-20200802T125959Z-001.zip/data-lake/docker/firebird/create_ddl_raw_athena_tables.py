import sys
import fdb
import os
import codecs
from datetime import date, datetime

# python3 create_ddl_raw_athena_tables.py /firebird/data/scci.gdb USUARIO /tmp/usuario.sql
# python3 create_ddl_raw_athena_tables.py /firebird/data/scci.gdb STATUS /tmp/status.sql

_, *args = sys.argv

if len(args) != 4:
    raise Exception("Usage: python create_ddl_raw_athena_tables.py database table outfile date_time")

database, table, outfile, date_time, *rest = args
separator = '\u0001'
database_name = os.path.basename(database).split(".")[0]
athena_schema = "scci_{}_raw".format(database_name)


# Get all tables from database
con = fdb.connect(database=database, user='sysdba', password='masterkey', charset='iso8859_1')

# Get columns names and types
ftypes = {
    7: int,
    8: int,
    10: float,
    12: date,
    13: datetime,
    14: str,
    16: int,
    27: float,
    35: datetime,
    37: str,
    261: fdb.fbcore.BlobReader
}

defaults = {
    int: "INT",
    float: "FLOAT",
    str: "STR",
    date: "DATE",
    datetime: "DATETIME",
    fdb.fbcore.BlobReader: "BLOB"
}

meta_query = "SELECT A.rdb$field_name, B.rdb$field_type FROM rdb$relation_fields A "
meta_query += "INNER JOIN rdb$fields B ON B.rdb$field_name = A.rdb$field_source "
meta_query += "WHERE rdb$relation_name='{}';".format(table)


def dtype_filter(dtype):
    dtypes_blacklist = [fdb.fbcore.BlobReader]
    return dtype != "BLOB"


cur = con.cursor()
cur.execute(meta_query)
columns = [(fname.strip(), defaults.get(ftypes.get(ftype))) for fname, ftype in cur.fetchall()]
columns = [col for col in columns if dtype_filter(col[1])]
cur.close()


def double_enquote(value):
    return '"{}"'.format(value)


athena_columns = []
for c_name, c_type in columns:
    athena_column = "`{column}` string COMMENT 'firebird_original_type {firebird_type}'".format(
        column=c_name.lower(), firebird_type=c_type)
    print(athena_column)
    athena_columns.append(athena_column)

ddl = """CREATE EXTERNAL TABLE IF NOT EXISTS {athena_schema}.{table} (
\t{columns}
)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.OpenCSVSerde' 
WITH SERDEPROPERTIES ( 
  'escapeChar'='\\\\', 
  'quoteChar'='\\"', 
  'separatorChar'='\u0001')
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://{{bucket_name}}/scci/{database}/current/csv/{TABLE}'
TBLPROPERTIES (
  'skip.header.line.count'='1', 
  'delimiter'='\u0001', 
  'CrawlerSchemaDeserializerVersion'='1.0', 
  'CrawlerSchemaSerializerVersion'='1.0',  
  'classification'='csv', 
  'columnsOrdered'='true',  
  'areColumnsQuoted'='false', 
  'typeOfData'='file'
)
""".format(
    athena_schema=athena_schema,
    database=database_name,
    table=table.lower(),
    TABLE=table.upper(),
    columns=',\n\t'.join(athena_columns)
)

with codecs.open(outfile, mode='w', encoding='utf8') as fp:
    fp.write(ddl)
