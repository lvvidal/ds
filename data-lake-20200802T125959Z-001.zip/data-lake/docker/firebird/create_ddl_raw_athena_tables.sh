#!/usr/bin/env bash

set -e

# database in securitizadora, hipotecaria, banco
database=$1

# date in the format YYYY-MM-DD
date_time=$2

ddl_base_dir="/firebird/data/${database}/${date_time}/ddl/raw"

database_file="/firebird/data/${database}/${date_time}/${database}.gdb"

if [ ! -d "$ddl_base_dir" ]; then
    mkdir -p "$ddl_base_dir"
fi

tables=$(python3 /list_tables.py "${database_file}")

for t in $tables; do
    echo "processing ddl for table $t"
    sql_file="$ddl_base_dir/$(echo "$t" | tr '[:upper:]' '[:lower:]').sql"
    python3 /create_ddl_raw_athena_tables.py "$database_file" "$t" "$sql_file" "$date_time"
done

# python3 create_ddl_raw_athena_tables.py /firebird/data/scci.gdb STATUS /tmp/status.sql
