#!/bin/bash

set -e

destination_bucket=$1
date_time=$2

year=$(echo $date_time | cut -d'-' -f1)
month=$(echo $date_time | cut -d'-' -f2)
day=$(echo $date_time | cut -d'-' -f3)

# /firebird/data/processed/2020-02-11/ddl
ddl_dir_processed="/firebird/data/processed/${date_time}/ddl"

#destination_path="s3://${destination_bucket}/scci/ddl"
#
#echo "uploading ddl processed"
#cd ${ddl_dir_processed} || exit 1
#aws s3 sync . "${destination_path}" --delete

# keep history of the ddl's
destination_path="s3://${destination_bucket}/scci/ddl/${year}/${month}/${day}"

echo "uploading ddl processed"
cd ${ddl_dir_processed} || exit 1
aws s3 sync . "${destination_path}" --delete



