#!/bin/bash
# Restart firebird container, forcing it to rebuild

docker-compose stop firebird
docker-compose rm -f -v firebird
docker-compose up --no-start --force-recreate --build firebird
docker-compose start firebird
