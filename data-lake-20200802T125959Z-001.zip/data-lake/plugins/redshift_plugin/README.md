# S3 To Redshift Operator


# License
Apache 2.0
