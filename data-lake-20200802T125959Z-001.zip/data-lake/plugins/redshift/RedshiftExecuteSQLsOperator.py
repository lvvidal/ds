import logging

from airflow.hooks.postgres_hook import PostgresHook
from airflow.plugins_manager import AirflowPlugin
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

from datetime import datetime
import os
import pytz

logger = logging.getLogger(__name__)

class RedshiftExecuteSQLsOperator(BaseOperator):

    template_fields = ['replacement_params']

    @apply_defaults
    def __init__(self, redshift_conn_id, sql_directory, replacement_params, *args, **kwargs):
        super(RedshiftExecuteSQLsOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.sql_directory = sql_directory
        self.replacement_params = replacement_params


    def execute(self, context):

        hook = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        if 'ds_str' in self.replacement_params:
            _date = datetime.strptime(self.replacement_params['ds_str']['value'], "%Y-%m-%d")
            self.replacement_params['ds_str']['ds_str_formatted'] = _date.strftime(
                self.replacement_params['ds_str']['format'])

        logging.info(f"execute redshift_conn_id={self.redshift_conn_id} "
                     f"sql_directory={self.sql_directory} "
                     f"replacement_params={self.replacement_params} ")

        create_table_sqls = []
        for root, dirs, files in os.walk(self.sql_directory):
            for f in files:
                create_table_sqls.append(os.path.join(root, f))

        number_of_tables = len(create_table_sqls)

        # sort é muito importante para garantir a sequencia correta dos sqls
        create_table_sqls.sort()

        logging.debug(f"list of sqls => {create_table_sqls}")

        logging.info("Create table: #{} scripts.".format(number_of_tables))

        now = pytz.utc.localize(datetime.utcnow())
        now_str = now.strftime("%Y-%m-%d-%H-%M")

        logger.info("Connected with " + self.redshift_conn_id)

        for i, sql_file in enumerate(create_table_sqls, 1):
            with open(sql_file, 'r') as f:
                logging.info(f"processing sql {sql_file}")
                f_sql = f.read()

                replace_dict = {}

                for k, v in self.replacement_params.items():
                    if k == 'ds_str' and 'ds_str' in f_sql:
                        replace_dict['ds_str'] = self.replacement_params['ds_str']['ds_str_formatted']
                    elif k in f_sql:
                        replace_dict[k] = v

                logging.info(f"replace_dict={replace_dict}\n{f_sql}")

                if len(replace_dict) > 0:
                    f_sql = f_sql.format(**replace_dict)

                logging.info(f"executing sql #{i}/{number_of_tables} => {f_sql}...")

                hook.run(f_sql, autocommit=True)

        logger.info("Load command completed")

        return True


class RedshiftExecuteSQLsOperatorPlugin(AirflowPlugin):
    name = "redshift_execute_sqls_plugin"
    operators = [RedshiftExecuteSQLsOperator]