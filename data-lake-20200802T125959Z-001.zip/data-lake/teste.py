






sql = """
select  cimv.codimv as "i_codimovel"
		, cimv.empreend as "i_codempreend"
		, upper(emp.nome) as "i_empreendimento"
	    , cimv.tipoimv as "i_codtipoimv"
	    , case 
	   		when cimv.tipoimv in(0,2) then 'Não Informado'
	   		else timv.descr 
	   	end as "i_desctipoimovel"
	    , cimv.tipo as "i_tipoimovel"
	    , upper(cimv.ende) as "i_endereco"
	    , case
	    	when regexp_like(upper(cimv.ende),'^(AL |AL\.|ALAMEDA)') then 'ALAMEDA'
	    	when regexp_like(upper(cimv.ende),'(AV\.|AV |AVENIDA)') then 'AVENIDA'
	    	when regexp_like(upper(cimv.ende),'(CJ )') then 'CONJUNTO'
	    	when regexp_like(upper(cimv.ende),'(EST |ESTRADA)') then 'ESTRADA'
	    	when regexp_like(upper(cimv.ende),'(LD )') then 'LADEIRA'
	    	when regexp_like(upper(cimv.ende),'(LOTEAMENTO)') then 'LOTEAMENTO'
	    	when regexp_like(upper(cimv.ende),'(PÇ\.|PÇA |PRAÇA)') then 'PRAÇA'
	    	when regexp_like(upper(cimv.ende),'(QNL | QD |QD\. |QUADRA)') then 'QUADRA'
	    	when regexp_like(upper(cimv.ende),'(RD |ROD\.|ROD |RODOVIA )') then 'RODOVIA'
	    	when regexp_like(upper(cimv.ende),'(R |R\.|RUA|RU )') then 'RUA'
	    	when regexp_like(upper(cimv.ende),'(ST )') then 'SETOR'
	    	when regexp_like(upper(cimv.ende),'(VIA)') then 'VIA'
	    	when regexp_like(upper(cimv.ende),'(VIADUTO)') then 'VIADUTO'
	    	when regexp_like(upper(cimv.ende),'(TV\. |TV |TVA |TRAVESSA)') then 'TRAVESSA'
			else ''
	    end as "i_tipologradouro"


	    , trim(regexp_replace(
	    	regexp_replace(
	    		regexp_replace(
	    			regexp_replace(upper(cimv.ende), '(N°\.|N\.|Nº|N°|N\.°||Nº\.|S\/N\.º|S\/NO|SN°|S\/N°|S\/Nº|S\/N|SN|S\/ NR|S\/ N|N°:|Nº:)','')
	    		,'((?:N\d{{4}})|(?<=\, )(\d+ [A-Z])|(?<=\, )(\d+-[A-Z])|(?<=\, )(\d+)|(?<= )(\d+\.\d+)|(?<=\, )(\d+)|(?<=\,)(\d+)|(?<= )(\d+)|(?<=N°)(\d+))','')
	    		,'(^(AL |AL\.|ALAMEDA))|(AV\.|AV |AVENIDA)|(CJ )|(EST |ESTRADA)|(LD )|(LOTEAMENTO)|(PÇ\.|PÇA |PRAÇA)|(QNL | QD |QD\. |QUADRA)|(RD |ROD\.|ROD |RODOVIA )|(^(R |R\.|RUA|RU ))|(^(ST ))|(VIA)|(VIADUTO)|(TV\. |TV |TVA |TRAVESSA)','')
	    		,'(\,|\-)','')) as "i_logradouro"
	    , case
	    	when regexp_like(upper(cimv.ende), '((?<=\, )|(?<= ))(S\/N|SN|S\/ NR|S\/ N)') then 'S/N'
			when regexp_like(upper(cimv.ende), '(?s)((?<=\, )(\d+ [A-Z])|(?<=\, )(\d+-[A-Z])|(?<=\, )(\d+)|(?<= )(\d+\.\d+)|(?<=\, )(\d+)|(?<=\,)(\d+)|(?<= )(\d+)|(?<=N°)(\d+))')
				then regexp_replace(regexp_extract(upper(cimv.ende), '(?s)((?<=\, )(\d+ [A-Z])|(?<=\, )(\d+-[A-Z])|(?<=\, )(\d+)|(?<= )(\d+\.\d+)|(?<=\, )(\d+)|(?<=\,)(\d+)|(?<= )(\d+)|(?<=N°)(\d+))'),'\D+','')
			else ''
		end as "i_num"


	    , upper(cimv.bairro) as "i_bairro"
	    , cimv.cep || cimv.cep2 as "i_cep"
		, cimv.codmun as "i_codmun"
	    , m.nomemun as "i_cidade"
	    , m.ufmun as "i_uf"
        , case
            when cast(m.ufmun as char(2)) IN ('RS','SC','PR') THEN 'SUL'
            when cast(m.ufmun as char(2)) IN ('SP','RJ','ES','MG') THEN 'SUDESTE'
            when cast(m.ufmun as char(2)) IN ('MS','MT','GO','DF') THEN 'CENTRO-OESTE'
            when cast(m.ufmun as char(2)) IN ('AC','AP','AM','RO','RR','PA','TO') THEN 'NORTE'
            when cast(m.ufmun as char(2)) IN ('AL','BA','CE','MA','PE','PI','PB','SE','RN') THEN 'NORDESTE'
            else 'OUTROS'
        end AS "i_regiao"
       , 'BRASIL' AS "i_pais"	  
       , case
            when cimv.origem = 0 then 'Hipotecaria'
       		when cimv.origem = 1 then 'Securitizadora'
       		when cimv.origem = 2 then 'Banco'
		end as "i_origem"  
       , cast(date_format(date_add('day', -1 , current_date),'%Y-%m-%d') as date) as "i_dtobservacao" 
from scci_processed.cadimv cimv
INNER JOIN scci_processed.empreendimentos emp
		ON (emp.empreend = cimv.empreend and emp.origem = cimv.origem)
LEFT JOIN scci_processed.tipoimv timv
		ON (timv.tipoimv = cimv.tipoimv and cimv.origem = timv.origem)
LEFT JOIN scci_processed.munic m
		ON (cast(m.chavemun as smallint) = cimv.codmun and m.origem = cimv.origem)
WHERE cimv.origem = 0
"""


print(sql.format(ds_str='2020-10-03'))
