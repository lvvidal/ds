"""
Salesforce to Redshift

This files contains an ongoing hourly workflow.

Each DAG makes use of three custom operators:
    - SalesforceToS3Operator
    https://github.com/airflow-plugins/salesforce_plugin/blob/master/operators/salesforce_to_s3_operator.py#L60
    - S3ToRedshiftOperator
    https://github.com/airflow-plugins/redshift_plugin/blob/master/operators/s3_to_redshift_operator.py#L13

This ongoing DAG pulls the following Salesforce objects:
    - Account
    - Campaign
    - CampaignMember
    - Contact
    - Lead
    - Opportunity
    - OpportunityContactRole
    - OpportunityHistory
    - Task
    - User

The output from Salesforce will be formatted as newline delimited JSON (ndjson)
and will include """
from datetime import datetime, timedelta

from airflow import DAG
from airflow.hooks.S3_hook import S3Hook
from airflow.operators.dummy_operator import DummyOperator

import dependencies.bancobari_airflow_defaults as defaults

# from airflow.operators.salesforce_plugin import SalesforceToS3Operator
# from airflow.operators import S3ToRedshiftOperator
from redshift_plugin import S3ToRedshiftOperator
from salesforce_plugin import SalesforceToS3Operator, SalesforceSchemaToRedshiftOperator
from airflow.operators.s3_to_redshift_operator import S3ToRedshiftTransfer

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2017, 8, 29),
    'email': [],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG('salesforce_to_redshift',
          default_args=default_args,
          schedule_interval='@daily',
          catchup=False)

tables = [{'name': 'Account', 'load_type': 'Upsert'},
          {'name': 'Campaign', 'load_type': 'Upsert'},
          {'name': 'CampaignMember', 'load_type': 'Upsert'},
          {'name': 'Contact', 'load_type': 'Upsert'},
          {'name': 'Lead', 'load_type': 'Upsert'},
          {'name': 'Opportunity', 'load_type': 'Upsert'},
          {'name': 'OpportunityContactRole', 'load_type': 'Upsert'},
          {'name': 'OpportunityHistory', 'load_type': 'Upsert'},
          {'name': 'Task', 'load_type': 'Upsert'},
          {'name': 'User', 'load_type': 'Upsert'}]



start = DummyOperator(task_id="start", dag=dag)

end = DummyOperator(task_id="end", dag=dag)

SF_CONN_ID = 'salesforce'
S3_CONN_ID = defaults.AWS_CONN_ID
S3_BUCKET = 'bancobari-salesforce-raw-213912952026'
REDSHIFT_CONN_ID = defaults.REDSHIFT_CONN_ID
REDSHIFT_SCHEMA_NAME = 'salesforce'
ORIGIN_SCHEMA = 's3'
SCHEMA_LOCATION = 's3://bancobari-salesforce-raw-213912952026/salesforce/schema'

for table in tables:
    S3_KEY = 'salesforce/{}/{}.json'.format('{{ execution_date }}',
                                            table['name'].lower())

    S3_KEY_JSONPATH = 'salesforce/jsonpath/{}.json'.format(table['name'].lower())
    S3_KEY_SCHEMA = 'salesforce/schema/{}.json'.format(table['name'].lower())

    S3Hook(aws_conn_id=S3_CONN_ID)

    salesforce_to_s3 = SalesforceToS3Operator(
        task_id='{0}_to_S3'.format(table['name']),
        sf_conn_id=SF_CONN_ID,
        sf_obj=table['name'],
        s3_conn_id=S3_CONN_ID,
        s3_bucket=S3_BUCKET,
        s3_key=S3_KEY,
        record_time_added=False,
        coerce_to_timestamp=False,
        fmt='ndjson',
        dag=dag
    )

    schema = SalesforceSchemaToRedshiftOperator(
        sf_conn_id=SF_CONN_ID,
        s3_conn_id=S3_CONN_ID,
        rs_conn_id=REDSHIFT_CONN_ID,
        sf_object=table['name'],
        rs_schema="salesforce",
        rs_table=table['name'],
        s3_bucket=S3_BUCKET,
        s3_key_jsonpath=S3_KEY_JSONPATH,
        s3_key_schema=S3_KEY_SCHEMA,
        dag=dag,
        task_id=f"schema_{table['name']}"
    )

    COPY_PARAMS = [
        f"JSON 's3://{S3_BUCKET}/{S3_KEY_JSONPATH}'",
        "TIMEFORMAT 'auto'",
        "COMPUPDATE OFF",
        "STATUPDATE OFF",
        "TRUNCATECOLUMNS",
        "region as 'us-east-1'"
    ]
    s3_to_redshift = S3ToRedshiftOperator(
        task_id='{0}_to_Redshift'.format(table['name']),
        redshift_conn_id=REDSHIFT_CONN_ID,
        redshift_schema=REDSHIFT_SCHEMA_NAME,
        table=table['name'],
        s3_conn_id=S3_CONN_ID,
        s3_bucket=S3_BUCKET,
        s3_key=S3_KEY,
        copy_params=COPY_PARAMS,
        schema_location="s3",
        origin_schema=f"salesforce/schema/{table['name'].lower()}.json",
        load_type=table['load_type'],
        incremental_key="lastmodifieddate",
        primary_key="id",
        dag=dag
    )

    start >> salesforce_to_s3 >> schema >> s3_to_redshift >> end



# pg_query = \
#             """
#             SELECT column_name, udt_name
#             FROM information_schema.columns
#             WHERE table_schema = '{0}' AND table_name = '{1}';
#             """.format(self.redshift_schema, self.table)
# pg_schema = dict(pg_hook.get_records(pg_query))