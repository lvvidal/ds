from datetime import timedelta
import json

import airflow
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator

from dependencies.athena_helper_functions import create_athena_tables
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AWS_CONN_ID, \
    AIRFLOW_HOME
from dependencies.tasks.task_fail import task_fail_alert
from dependencies.tasks.task_success import TaskSuccess

ACCOUNT_ID = get_account_id()

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)


# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

def success_function(context):
    print(f"on_success_callback context={str(context)}")

args = {
    'owner': 'Airflow',
    'start_date': '2020-07-01',
    'on_success_callback': ts.task_success,
    'on_failure_callback': task_fail_alert,
}

dag = DAG(
    dag_id='Salesforce_Athena_SQL_Current_DAG',
    default_args=args,
    schedule_interval='0 4 * * *',
    catchup=False,
)

start_task = DummyOperator(
    task_id="start_task",
    dag=dag
)

end_task = DummyOperator(
    task_id="end_task",
    dag=dag
)

create_athena_salesforce_current_tables = PythonOperator(
    task_id='create_athena_salesforce_current_tables',
    python_callable=create_athena_tables,
    op_kwargs={
        'athena_database_name': 'salesforce_raw',
        'bucket_name': '',
        'ds_str': '{{ ds }}',
        'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/salesforce/current/',
        'task_success': ts,
        'task_id': 'create_athena_salesforce_current_tables'
    },
    on_success_callback=ts.task_success,
    dag=dag)


start_task >> create_athena_salesforce_current_tables >> end_task