"""
Salesforce to Redshift

This files contains an ongoing hourly workflow.

Each DAG makes use of three custom operators:
    - SalesforceToS3Operator
    https://github.com/airflow-plugins/salesforce_plugin/blob/master/operators/salesforce_to_s3_operator.py#L60
    - S3ToRedshiftOperator
    https://github.com/airflow-plugins/redshift_plugin/blob/master/operators/s3_to_redshift_operator.py#L13

This ongoing DAG pulls the following Salesforce objects:
    - Account
    - Campaign
    - CampaignMember
    - Contact
    - Lead
    - Opportunity
    - OpportunityContactRole
    - OpportunityHistory
    - Task
    - User

The output from Salesforce will be formatted as newline delimited JSON (ndjson)
and will include """
from datetime import datetime, timedelta

from airflow import DAG
from airflow.hooks.S3_hook import S3Hook
from airflow.operators.dummy_operator import DummyOperator

import dependencies.bancobari_airflow_defaults as defaults

# from airflow.operators.salesforce_plugin import SalesforceToS3Operator
# from airflow.operators import S3ToRedshiftOperator
from redshift_plugin import S3ToRedshiftOperator
from salesforce_plugin import SalesforceToS3Operator, SalesforceSchemaToRedshiftOperator
from airflow.operators.s3_to_redshift_operator import S3ToRedshiftTransfer

from salesforce_plugin.operators.salesforce_schema_to_athena_operator import SalesforceSchemaToAthenaOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2017, 8, 29),
    'email': [],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

tables = [
    {'name': 'Account', 'load_type': 'Upsert'},
    {'name': 'BusinessProcess', 'load_type': 'Upsert'},
    {'name': 'Campaign', 'load_type': 'Upsert'},
    {'name': 'CampaignMember', 'load_type': 'Upsert'},
    {'name': 'Contact', 'load_type': 'Upsert'},
    {'name': 'Lead', 'load_type': 'Upsert'},
    {'name': 'Opportunity', 'load_type': 'Upsert'},
    {'name': 'OpportunityContactRole', 'load_type': 'Upsert'},
    {'name': 'OpportunityFeed', 'load_type': 'Upsert'},
    {'name': 'OpportunityFieldHistory', 'load_type': 'Upsert'},
    {'name': 'OpportunityHistory', 'load_type': 'Upsert'},
    # {'name': 'OpportunityLineItemSchedule', 'load_type': 'Upsert'},  # not found on salesforce
    # {'name': 'OpportunityOwnerSharingRule', 'load_type': 'Upsert'},  # not found on salesforce
    {'name': 'OpportunityShare', 'load_type': 'Upsert'},
    {'name': 'OpportunityStage', 'load_type': 'Upsert'},
    # {'name': 'PicklistValue', 'load_type': 'Upsert'},  # not found on salesforce
    # {'name': 'PicklistValues', 'load_type': 'Upsert'},  # not found on salesforce
    # {'name': 'PicklistValuesCollection', 'load_type': 'Upsert'},  # not found on salesforce
    {'name': 'RecordType', 'load_type': 'Upsert'},
    {'name': 'Task', 'load_type': 'Upsert'},
    {'name': 'User', 'load_type': 'Upsert'}
]

SF_CONN_ID = 'salesforce'
S3_CONN_ID = defaults.AWS_CONN_ID
S3_BUCKET_RAW = 'bancobari-salesforce-raw-213912952026'
S3_BUCKET_PROCESSED = 'bancobari-salesforce-processed-213912952026'
AWS_CONN_ID = defaults.AWS_CONN_ID
REDSHIFT_SCHEMA_NAME = 'salesforce'
ORIGIN_SCHEMA = 's3'
SCHEMA_LOCATION = 's3://bancobari-salesforce-raw-213912952026/salesforce/schema'

dag = DAG('salesforce_to_athena',
          default_args=default_args,
          schedule_interval='0 3 * * *',
          catchup=False)

start = DummyOperator(task_id="start", dag=dag)

end = DummyOperator(task_id="end", dag=dag)


for table in tables:
    S3_KEY = 'salesforce/{table_name}/{date_str}/{table_name}.csv'.format(
        date_str='{{ execution_date.strftime("%Y/%m/%d") }}',
        table_name=table['name'].lower())

    S3_KEY_JSONPATH = 'salesforce/jsonpath/{}.json'.format(table['name'].lower())
    S3_KEY_SCHEMA = 'salesforce/schema/{}.json'.format(table['name'].lower())

    S3Hook(aws_conn_id=S3_CONN_ID)

    salesforce_to_s3 = SalesforceToS3Operator(
        task_id='{0}_to_S3'.format(table['name']),
        sf_conn_id=SF_CONN_ID,
        sf_obj=table['name'],
        s3_conn_id=S3_CONN_ID,
        s3_bucket=S3_BUCKET_RAW,
        s3_key=S3_KEY,
        record_time_added=False,
        coerce_to_timestamp=True,
        fmt='csv_raw',
        dag=dag
    )

    raw = SalesforceSchemaToAthenaOperator(
        sf_conn_id=SF_CONN_ID,
        s3_conn_id=S3_CONN_ID,
        athena_conn_id=AWS_CONN_ID,
        sf_object=table['name'],
        athena_schema="salesforce_raw",
        athena_table=table['name'].lower(),
        s3_bucket=S3_BUCKET_RAW,
        s3_key=f"salesforce/{table['name'].lower()}",
        updated_at="{{ ds }}",
        s3_key_jsonpath=S3_KEY_JSONPATH,
        s3_key_schema=S3_KEY_SCHEMA,
        dag=dag,
        task_id=f"raw_{table['name']}",
        database_type="raw"
    )

    processed = SalesforceSchemaToAthenaOperator(
        sf_conn_id=SF_CONN_ID,
        s3_conn_id=S3_CONN_ID,
        athena_conn_id=AWS_CONN_ID,
        sf_object=table['name'],
        athena_schema="salesforce_processed",
        athena_table=table['name'].lower(),
        s3_bucket=S3_BUCKET_PROCESSED,
        s3_key=f"salesforce/{table['name'].lower()}",
        updated_at="{{ ds }}",
        s3_key_jsonpath=S3_KEY_JSONPATH,
        s3_key_schema=S3_KEY_SCHEMA,
        dag=dag,
        task_id=f"processed_{table['name']}",
        database_type="processed"
    )

    # COPY_PARAMS = [
    #     f"JSON 's3://{S3_BUCKET}/{S3_KEY_JSONPATH}'",
    #     "TIMEFORMAT 'auto'",
    #     "COMPUPDATE OFF",
    #     "STATUPDATE OFF",
    #     "TRUNCATECOLUMNS",
    #     "region as 'us-east-1'"
    # ]
    # s3_to_redshift = S3ToRedshiftOperator(
    #     task_id='{0}_to_Redshift'.format(table['name']),
    #     redshift_conn_id=AWS_CONN_ID,
    #     redshift_schema=REDSHIFT_SCHEMA_NAME,
    #     table=table['name'],
    #     s3_conn_id=S3_CONN_ID,
    #     s3_bucket=S3_BUCKET,
    #     s3_key=S3_KEY,
    #     copy_params=COPY_PARAMS,
    #     schema_location="s3",
    #     origin_schema=f"salesforce/schema/{table['name'].lower()}.json",
    #     load_type=table['load_type'],
    #     incremental_key="lastmodifieddate",
    #     primary_key="id",
    #     dag=dag
    # )

    start >> salesforce_to_s3 >> raw >> processed >> end
    # start >> salesforce_to_s3 >> raw >> end

