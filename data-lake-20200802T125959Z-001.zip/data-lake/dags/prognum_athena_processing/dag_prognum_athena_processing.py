# Name:  dag_prognum_athena_processing.py
# Purpose : This DAG produces credit KPI's and analytics for the Self-Service BI, yet to be consumed by the Credit area.
# Created at: 2019-11-22
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
#          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>

from __future__ import print_function

from datetime import datetime, timedelta

from airflow.contrib.operators.s3_copy_object_operator import S3CopyObjectOperator
from airflow.contrib.operators.s3_delete_objects_operator import S3DeleteObjectsOperator
from airflow.models import DAG
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook

from dependencies.tasks.task_success import TaskSuccess
from dependencies.tasks.task_fail import task_fail_alert
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AWS_CONN_ID, \
    AIRFLOW_HOME
from dependencies.athena_helper_functions import (create_athena_tables,
                                                  drop_athena_databases,
                                                  create_athena_databases,
                                                  athena_remove_partition_from_bucket)
from dependencies.s3_helper_functions import download_file, remove_objects_from_bucket
from dependencies.tasks.task_colors import set_operator_color

# DAG Colors
set_operator_color()

# Global Variables
DAG_NAME = 'Prognum_Athena_Processing'

ACCOUNT_ID = get_account_id()

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

args = {
    'owner': 'data-team',
    'start_date': datetime(2020, 1, 2),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': True,
    'email_on_failure': True,
    'on_failure_callback': task_fail_alert,
    'on_success_callback': ts.task_success,
}

dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval='30 5 * * *')  # 05:30 UTC is 02:30 America/Sao_Paulo

with open(f'{AIRFLOW_HOME}/dags/prognum_athena_processing/dag_prognum_athena_processing.md', 'r') as f:
    dag.doc_md = f.read()


start_log = DummyOperator(
    task_id='start_log',
    dag=dag)


db_info_raw = {
    "hipotecaria": {
        "prefix": "scci",
        "concatenator": "_",
        "suffix": "raw", 
        "bucket": f'bancobari-prognum-raw-{ACCOUNT_ID}',
        "key": f'scci/hipotecaria/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/ddl' 
    },
    "securitizadora": {
        "prefix": "scci",
        "concatenator": "_",
        "suffix": "raw",
        "bucket": f'bancobari-prognum-raw-{ACCOUNT_ID}',
        "key": f'scci/securitizadora/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/ddl/' 
    },
    "banco": {
        "prefix": "scci",
        "concatenator": "_",
        "suffix": "raw",
        "bucket": f'bancobari-prognum-raw-{ACCOUNT_ID}',
        "key": f'scci/banco/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/ddl'  
    },
}


# echo "sync bucket current"
# aws s3 sync "s3://${destination_bucket}/scci/${database}/${year}/${month}/${day}" "s3://${destination_bucket}/scci/${database}/current/" --delete


drop_athena_database_processed = PythonOperator(
    task_id='drop_athena_database_processed',
    python_callable=drop_athena_databases,
    op_kwargs={
        'database': 'scci_processed',
        'task_success': ts,
        'task_id': 'drop_athena_database_processed'
    },
    on_success_callback=ts.task_success,
    dag=dag)


# limpa objetos dos buckets
remove_files_s3_processed = PythonOperator(
    task_id='remove_processed_files_s3',
    python_callable=remove_objects_from_bucket,
    op_kwargs={
        's3_hook': s3_hook,
        'bucket': f'bancobari-prognum-processed-{ACCOUNT_ID}',
        'prefix': 'scci/processed/',
        'task_success': ts,
        'task_id': 'remove_objects_raw_s3'
    },
    on_success_callback=ts.task_success,
    dag=dag)


create_athena_database_processed = PythonOperator(
    task_id='create_athena_database_processed',
    python_callable=create_athena_databases,
    op_kwargs={
        'database': 'scci_processed',
        'task_success': ts,
        'task_id': 'create_athena_database_processed'
    },
    on_success_callback=ts.task_success,
    dag=dag)


remove_old_ddl_processed = BashOperator(
    task_id='remove_old_ddl_processed',
    bash_command=f"""
    data_dir={AIRFLOW_HOME}/dags/athena/processed
    if [ -d  $data_dir ]; then
        echo "Removing previous date ddl scripts from folder: $data_dir"
        rm -rf $data_dir/*
    fi
    """,
    on_success_callback=ts.task_success,
    dag=dag)


download_dlls_from_s3_processed = PythonOperator(
    task_id='download_dlls_from_s3_processed',
    python_callable=download_file,
    op_kwargs={
        's3_hook': s3_hook,
        'bucket': f'bancobari-prognum-processed-{ACCOUNT_ID}',
        'key': f'scci/ddl/{{{{ execution_date.strftime("%Y/%m/%d") }}}}',
        'destination': f'{AIRFLOW_HOME}/dags/athena/processed/{{{{ ds }}}}',
        'task_success': ts,
        'task_id': 'download_dlls_processed_from_s3'
    },
    on_success_callback=ts.task_success,
    dag=dag)


create_processed_tables = PythonOperator(
    task_id='create_processed_tables',
    python_callable=create_athena_tables,
    op_kwargs={
        'athena_database_name': 'scci_processed',
        'bucket_name': f'bancobari-prognum-processed-{ACCOUNT_ID}',
        'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/processed/{{{{ ds }}}}',
        'task_success': ts,
        'task_id': 'create_processed_tables'
    },
    on_success_callback=ts.task_success,
    dag=dag)


create_athena_database_business = PythonOperator(
    task_id='create_athena_database_business',
    python_callable=create_athena_databases,
    op_kwargs={
        'database': 'scci_business',
        'task_success': ts,
        'task_id': 'create_athena_database_business'
    },
    on_success_callback=ts.task_success,
    dag=dag)

# s3://bancobari-prognum-business-213912952026/portfolio/dw/DIM_CLIENTE/c_dtobservacao=2020-03-30/20200417_201443_00003_pvwpx_4b25c6ca-dcbf-49a2-83f2-585994c2dbfb.gz
business_tables = [
    {
        "database": "scci_business",
        "table": "dim_atraso",
        "partition_column": "a_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_ATRASO"
    },
    {
        "database": "scci_business",
        "table": "dim_cliente",
        "partition_column": "c_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_CLIENTE"
    },
    {
        "database": "scci_business",
        "table": "dim_mutuario",
        "partition_column": "m_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_MUTUARIO"
    },
    {
        "database": "scci_business",
        "table": "dim_imovel",
        "partition_column": "i_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_IMOVEL"
    },
    {
        "database": "scci_business",
        "table": "dim_parcela",
        "partition_column": "p_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_PARCELA"
    },
    {
        "database": "scci_business",
        "table": "dim_serie",
        "partition_column": "s_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_SERIE"
    },
    {
        "database": "imob_dw",
        "table": "dim_entidade",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_ENTIDADE"
    },
    {
        "database": "imob_dw",
        "table": "dim_tarefa",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_TAREFA"
    },
    {
        "database": "imob_dw",
        "table": "dim_fase",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_FASE"
    },
    {
        "database": "imob_dw",
        "table": "dim_operacao",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/DIM_OPERACAO"
    },
    {
        "database": "scci_business",
        "table": "fato_portfolio",
        "partition_column": "f_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/FATO_PORTFOLIO"
    },
    {
        "database": "scci_business",
        "table": "fato_vintage",
        "partition_column": "f_dtobservacao",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/dw/FATO_VINTAGE"
    },
    {
        "database": "imob_dw",
        "table": "portfolio",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/portfolio/TODAY"
    },
    {
        "database": "imob_dw",
        "table": "performancefull",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/outros/PERFORMANCEFULL"
    },
    {
        "database": "imob_dw",
        "table": "portfolio_daily",
        "partition_column": "dt_obs",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/portfolio/DAILY"
    },
    {
        "database": "imob_dw",
        "table": "portfolio_monthly",
        "partition_column": "anomes",
        "partition_pattern": "%Y-%m",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/portfolio/MONTHLY"
    },
    {
        "database": "imob_dw",
        "table": "formalizacao",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/esteira/formalizacao"
    },
    {
        "database": "imob_dw",
        "table": "originacao",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/esteira/originacao"
    },
    {
        "database": "imob_dw",
        "table": "vintage",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/vintage/TODAY"
    },
    {
        "database": "imob_dw",
        "table": "vintage_aux",
        "partition_column": "dt_obs",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/vintage/AUX/"
    },
    {
        "database": "imob_dw",
        "table": "vintage_daily",
        "partition_column": "dt_obs",
        "partition_pattern": "%Y-%m-%d",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/vintage/DAILY/"
    },
    {
        "database": "imob_dw",
        "table": "vintage_monthly",
        "partition_column": "anomes",
        "partition_pattern": "%Y-%m",
        "bucket_name": f"bancobari-prognum-business-{ACCOUNT_ID}",
        "key": "imobiliario/vintage/MONTHLY"
    }
]


athena_remove_partition_from_bucket_business = PythonOperator(
    task_id='athena_remove_partition_from_bucket_business',
    python_callable=athena_remove_partition_from_bucket,
    op_kwargs={
        'task_success': ts,
        'task_id': 'athena_remove_partition_from_bucket_business',
        'tables_metadata': business_tables,
        'ds_str': '{{ ds }}',
        's3_hook': s3_hook
    },
    xcom_push=True,
    on_success_callback=ts.task_success,
    dag=dag)


create_athena_tables_business = PythonOperator(
    task_id='create_athena_tables_business',
    python_callable=create_athena_tables,
    op_kwargs={
        'athena_database_name': 'scci_business',
        'bucket_name': f'bancobari-prognum-processed-{ACCOUNT_ID}',
        'ds_str': '{{ ds }}',
        'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/ddl/',
        'task_success': ts,
        'task_id': 'create_processed_tables'
    },
    on_success_callback=ts.task_success,
    dag=dag)


end_log = DummyOperator(
    task_id='end_log',
    dag=dag)

create_raw_tables_operators = []
for db, val in db_info_raw.items():
    prefix = val['prefix']
    concatenator = val['concatenator']
    suffix = val['suffix']
    bucket = val['bucket']
    key = val['key']
    create_raw_tables = PythonOperator(
            task_id=f'create_raw_tables_{db}',
            python_callable=create_athena_tables,
            op_kwargs={
                'athena_database_name': f'{prefix}{concatenator}{db}{concatenator}{suffix}',
                'bucket_name': f'bancobari-prognum-raw-{ACCOUNT_ID}',
                'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/raw/{db}/',
                'task_success': ts,
                'task_id': f'create_raw_tables_{db}'
            },
            on_success_callback=ts.task_success,
            dag=dag)

    create_raw_tables_operators.append(create_raw_tables)


for db, val in db_info_raw.items():

    prefix = val['prefix']
    concatenator = val['concatenator']
    suffix = val['suffix']
    bucket = val['bucket']
    key = val['key']

    drop_athena_database_raw = PythonOperator(
        task_id=f'drop_athena_database_{prefix}{concatenator}{db}{concatenator}{suffix}',
        python_callable=drop_athena_databases,
        op_kwargs={
            'database': f'{prefix}{concatenator}{db}{concatenator}{suffix}',
            'task_success': ts,
            'task_id': f'drop_athena_database_{prefix}{concatenator}{db}{concatenator}{suffix}'
        },
        on_success_callback=ts.task_success,
        dag=dag)

    create_athena_database_raw = PythonOperator(
        task_id=f'create_athena_database_{prefix}{concatenator}{db}{concatenator}{suffix}',
        python_callable=create_athena_databases,
        op_kwargs={
            'database': f'{prefix}{concatenator}{db}{concatenator}{suffix}',
            'task_success': ts,
            'task_id': f'create_athena_database_{prefix}{concatenator}{db}{concatenator}{suffix}'
        },
        on_success_callback=ts.task_success,
        dag=dag)

    remove_local_ddl_raw = BashOperator(
        task_id=f'remove_local_ddl_raw_{db}',
        bash_command=f"""
        data_dir={AIRFLOW_HOME}/dags/athena/raw/{db}/
        if [ -d  $data_dir ]; then
            echo "Removing previous ddl scripts from folder: $data_dir"
            rm -rf $data_dir
        fi
        """,
        on_success_callback=ts.task_success,
        dag=dag)

    # delete_s3_bucket_current = S3DeleteObjectsOperator(
    #     task_id=f"delete_s3_bucket_current_{db}",
    #     aws_conn_id=AWS_CONN_ID,
    #     bucket=bucket,
    #     keys=f'scci/{db}/current/',
    #     dag=dag
    # )

    # limpa objetos dos bucket raw current
    delete_s3_raw_bucket_current = PythonOperator(
        task_id=f"delete_s3_raw_bucket_current_{db}",
        python_callable=remove_objects_from_bucket,
        op_kwargs={
            's3_hook': s3_hook,
            'bucket': f'bancobari-prognum-raw-{ACCOUNT_ID}',
            'prefix': [f'scci/{db}/current/ddl', f'scci/{db}/current/csv'],
            'task_success': ts,
            'task_id': f"delete_s3_raw_bucket_current_{db}"
        },
        on_success_callback=ts.task_success,
        dag=dag)

    copy_s3_ddl_csv_to_current = BashOperator(
        task_id=f"copy_s3_ddl_csv_to_current_{db}",
        bash_command=f'aws s3 sync s3://bancobari-prognum-raw-{ACCOUNT_ID}/scci/{db}/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/ s3://bancobari-prognum-raw-{ACCOUNT_ID}/scci/{db}/current/ --delete',
        dag=dag
    )

    # copy_s3_ddl_csv_to_current = S3CopyObjectOperator(
    #     task_id=f"copy_s3_ddl_csv_to_current_{db}",
    #     aws_conn_id=AWS_CONN_ID,
    #     source_bucket_name=f'bancobari-prognum-raw-{ACCOUNT_ID}',
    #     source_bucket_key=f'scci/{db}/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/',
    #     dest_bucket_name=bucket,
    #     dest_bucket_key=f'scci/{db}/current/',
    #     on_success_callback=ts.task_success,
    #     dag=dag
    # )

    download_ddl_from_s3 = PythonOperator(
        task_id=f'download_dlls_{db}_from_s3',
        python_callable=download_file,
        op_kwargs={
            's3_hook': s3_hook,
            'bucket': bucket,
            'key': key,
            'destination': f'{AIRFLOW_HOME}/dags/athena/raw/{db}/',
            'task_success': ts,
            'task_id': f'download_dlls_{db}_from_s3'
        },
        on_success_callback=ts.task_success,
        dag=dag)
    
    # create_raw_tables = PythonOperator(
    #         task_id=f'create_raw_tables_{db}',
    #         python_callable=create_athena_tables,
    #         op_kwargs={
    #             'athena_database_name': f'{prefix}{concatenator}{db}{concatenator}{suffix}',
    #             'bucket_name': f'bancobari-prognum-raw-{ACCOUNT_ID}',
    #             'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/raw/{db}/',
    #             'task_success': ts,
    #             'task_id':f'create_raw_tables_{db}'
    #         },
    #         on_success_callback=ts.task_success,
    #         dag=dag)

    start_log >> drop_athena_database_raw >> create_athena_database_raw >> remove_local_ddl_raw >> \
    delete_s3_raw_bucket_current >> copy_s3_ddl_csv_to_current >> download_ddl_from_s3 >> \
    create_raw_tables_operators[0] >> create_raw_tables_operators[1] >> create_raw_tables_operators[2] >> \
    drop_athena_database_processed >> remove_files_s3_processed >> create_athena_database_processed >> \
    remove_old_ddl_processed >> download_dlls_from_s3_processed >> create_processed_tables >> \
    create_athena_database_business >> athena_remove_partition_from_bucket_business >> \
    create_athena_tables_business >> \
    end_log






