# import logging
# from datetime import timedelta
# from time import sleep

# import docker
# from airflow import DAG
# from airflow.plugins.bash_operator import BashOperator
# from airflow.plugins.docker_operator import DockerOperator
# from airflow.plugins.python_operator import PythonOperator
# from airflow.plugins.jdbc_operator import JdbcOperator
# from airflow.utils.dates import days_ago
# from airflow.models import Variable

# log = logging.getLogger(__name__)

# args = {
#     'owner': 'Airflow',
#     'start_date': days_ago(1)
# }

# dag = DAG(
#     dag_id="prognum_cep_etl",
#     default_args=args,
#     schedule_interval='0 0 * * *',
#     dagrun_timeout=timedelta(minutes=60)
# )

# AWS_CREDENTIALS = Variable.get("AWS_CREDENTIALS", deserialize_json=True)

# def start_firebird():
#     client = docker.from_env()
#     try:
#         client.containers.get('firebird_cep')
#     except:
#         client.containers.run(
#             'bari/firebird',
#             detach=True,
#             auto_remove=True,
#             environment=AWS_CREDENTIALS,
#             ports={'3050/tcp': 3050},
#             name='firebird_cep'
#         )

#         # Wait container to be healthy
#         container = client.containers.get('firebird_cep')
#         while container.attrs.get('State').get('Health').get('Status') != 'healthy':
#             sleep(2)
#             container.reload()

# def download_database():
#     client = docker.from_env()
#     container = client.containers.get('firebird_cep')
#     log = container.exec_run('./download_db.sh cep.gdb cep.gdb', stream=True)
#     for line in log[1]:
#         print(line.decode())

# def get_tables(**kwargs):
#     client = docker.from_env()
#     container = client.containers.get('firebird_cep')
#     log = container.exec_run('python3 list_tables.py /firebird/data/cep.gdb')
#     tables = log[1].decode().replace('\n', '').split(',')
#     return tables

# def extract_tables(**kwargs):
#     client = docker.from_env()
#     container = client.containers.get('firebird_cep')
#     ti = kwargs.get('ti')
#     tables = ti.xcom_pull(task_ids='get_tables')
#     container.exec_run('mkdir -p /outcsv')
#     for i, table in enumerate(tables):
#         print('Extracting CSV from {} ({} of {})'.format(table, 1 + i, len(tables)))
#         container.exec_run('python3 extract_table.py /firebird/data/cep.gdb {} /outcsv/{}.csv'.format(table, table))

# def upload_tables(**kwargs):
#     client = docker.from_env()
#     container = client.containers.get('firebird_cep')
#     ti = kwargs.get('ti')
#     ds = kwargs.get('ds')
    
#     tables = ti.xcom_pull(task_ids='get_tables')
#     for i, table in enumerate(tables):
#         print('Uploading {} to S3 bucket. ({} of {})'.format(table, 1 + i, len(tables)))
#         filename = table + '.csv'
#         container.exec_run('aws s3 cp /outcsv/{} s3://prognum_processed_table-backup/cep/{}/{}'.format(filename, ds.replace('-', '/'), filename))
    

# def stop_firebird():
#     client = docker.from_env()
#     try:
#         container = client.containers.get('firebird_cep')
#         container.stop()
#     except:
#         pass

# with dag:
#     restore_t = DockerOperator(
#         task_id='restore_database',
#         image='bari/firebird',
#         command='./restore_db.sh cep.gbk cep.gdb',
#         environment=AWS_CREDENTIALS,
#         auto_remove=True
#     )

#     start_firebird_t = PythonOperator(
#         task_id='start_firebird',
#         python_callable=start_firebird
#     )

#     download_db_t = PythonOperator(
#         task_id='download_database',
#         python_callable=download_database
#     )

#     get_tables_t = PythonOperator(
#         task_id='get_tables',
#         python_callable=get_tables,
#     )

#     extract_tables_t = PythonOperator(
#         task_id='extract_tables',
#         python_callable=extract_tables,
#         provide_context=True
#     )

#     upload_tables_to_s3_t = PythonOperator(
#         task_id='upload_tables_to_s3',
#         python_callable=upload_tables,
#         provide_context=True
#     )

#     delay_t = BashOperator(
#         task_id="delayer",
#         bash_command="sleep 10"
#     )

#     stop_firebird_t = PythonOperator(
#         task_id='stop_firebird',
#         python_callable=stop_firebird
#     )

#     [restore_t, start_firebird_t] >> download_db_t >> get_tables_t >> extract_tables_t >> upload_tables_to_s3_t >> delay_t
#     delay_t >> stop_firebird_t
