# Name:  dag_prognum_athena_processing.py
# Purpose : This DAG produces credit KPI's and analytics for the Self-Service BI, yet to be consumed by the Credit area.
# Created at: 2020-04-27
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
#          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>

from __future__ import print_function

from calendar import monthrange

from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook

from dependencies.tasks.task_success import TaskSuccess
from dependencies.tasks.task_fail import task_fail_alert
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AWS_CONN_ID, \
    AIRFLOW_HOME
from dependencies.athena_helper_functions import (create_athena_tables,
                                                  drop_athena_databases,
                                                  create_athena_databases,
                                                  athena_remove_partition_from_bucket)
from dependencies.s3_helper_functions import download_file, remove_objects_from_bucket
from dependencies.tasks.task_colors import set_operator_color

# DAG Colors
from redshift.RedshiftExecuteSQLsOperator import RedshiftExecuteSQLsOperator

set_operator_color()

# Global Variables
DAG_NAME = 'Prognum_Redshift_Processing'

ACCOUNT_ID = get_account_id()

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

args = {
    'owner': 'data-team',
    'start_date': datetime(2020, 1, 3),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': True,
    'email_on_failure': True,
    'on_failure_callback': task_fail_alert,
    'on_success_callback': ts.task_success,
}

week_days = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
MON, TUE, WED, THU, FRI, SAT, SUN = range(7)

def last_day_of_month(dt: datetime):
    return monthrange(dt.year, dt.month)[1]

def decide_which_path(**context):
    ds = context['ds']
    ds_date_obj = datetime.strptime(ds, "%Y-%m-%d")

    if ds_date_obj.day == last_day_of_month(ds_date_obj):
        print("final do mês")
        return "execute_sqls_monthly"
    else:
        print("não faz nada")
        return "do_nothing"


dag = DAG(
    dag_id=DAG_NAME,
    default_args=args,
    catchup=False,
    schedule_interval='0 7 * * *')  # 02:00 GMT-3

with open(f'{AIRFLOW_HOME}/dags/prognum_redshift_processing/dag_prognum_redshift.md', 'r') as f:
    dag.doc_md = f.read()

start_log = DummyOperator(
    task_id='start_log',
    dag=dag)

execute_sqls_daily = RedshiftExecuteSQLsOperator(
    task_id="execute_sqls_daily",
    redshift_conn_id=REDSHIFT_CONN_ID,
    sql_directory=f"{AIRFLOW_HOME}/dags/redshift/ddl/daily",
    replacement_params={
        'ds_str': {
            'value': '{{ ds }}',
            'format': '%Y-%m-%d'
        },
        'bucket_name': f'bancobari-prognum-business-{ACCOUNT_ID}'
    },
    dag=dag
)

execute_sqls_monthly = RedshiftExecuteSQLsOperator(
    task_id="execute_sqls_monthly",
    redshift_conn_id=REDSHIFT_CONN_ID,
    sql_directory=f"{AIRFLOW_HOME}/dags/redshift/ddl/monthly",
    replacement_params={
        'ds_str': {
            'value': '{{ ds }}',
            'format': '%Y-%m'
        },
        'bucket_name': f'bancobari-prognum-business-{ACCOUNT_ID}'
    },
    dag=dag
)

do_nothing = DummyOperator(
    task_id='do_nothing',
    dag=dag)

branch_task = BranchPythonOperator(
    task_id='run_this_first',
    python_callable=decide_which_path,
    trigger_rule="all_done",
    provide_context=True,
    dag=dag)

end_log = DummyOperator(
    task_id='end_log',
    dag=dag)

start_log >> execute_sqls_daily >> branch_task >> [execute_sqls_monthly, do_nothing] >> end_log
