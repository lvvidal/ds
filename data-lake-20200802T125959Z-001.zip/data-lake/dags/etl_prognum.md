### Dag: ETL Originação

<details>
  <summary>
  Clique aqui para maiores informações sobre a Dag
  </summary>
<p>

<p align="center">
  <a href="http://www.bariguifinanceira.com.br/">
    <img src="http://www.bariguicreditointeligente.com.br/wp-content/themes/barigui-v2/images/bari.png" alt="Barigui" width="120" height="50">
  </a>
</p>

#### Propósito

Esta DAG busca a base Firebird do sistema legado da Prognum, envia para um bucket s3, extrai as tabelas, cria os bancos a serem utilizados para os
processos RAW, PROCESSED e BUSINESS e por fim cria o Datawarehouse no Amazon Reshift. 

#### Tasks

Este workflow faz as seguintes tarefas:

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
.tg .header{border-color:inherit;font-weight:bold;text-align:center;vertical-align:center}
.tg .subheader{border-color:inherit;font-size:12px;color: red;font-weight:bold;text-align:left;vertical-align:center}
.tg .texto{border-color:inherit;font-size:12px;font-weight:normal;text-align:left;vertical-align:center}
</style>
<table class="tg">
  <tr>
    <th class="header">Task</th>
    <th class="header">Função</th>
  </tr>
  <tr>
    <td class="subheader">start_log</td>
    <td class="texto">Task Inicial - apenas indica o horário de início da execução do fluxo.</td>
  </tr>
  <tr>
    <td class="subheader">file_sensor</td>
    <td class="texto">Verifica se a base Firebird - Prognum já está disponível no Bucket s3.</td>
  </tr>
  <tr>
    <td class="subheader">download_from_s3</td>
    <td class="texto">Uma vez que o arquivo está no bucket, é feito o seu download para o container que está executando o Airflow.</td>
  </tr>
  <tr>
    <td class="subheader">restore_db</td>
    <td class="texto">Restaura a base Firebird - Prognum no container, via gbak, utilitário que transforma o arquivo em formato .gbk para gbd. </td>
  </tr>
  <tr>
    <td class="subheader">extract_backup</td>
    <td class="texto">Extrai as tabelas e gera os CSV's de todas as tabela da base SCCI.</td>
  </tr>
  <tr>
    <td class="subheader">remove_objects_raw_s3</td>
    <td class="texto" rowspan="3">Limpa todos os objetos do bucket para que a task possa fazer o upload de novos arquivos sem que haja conflito.</td>
  </tr>
  <tr>
    <td class="subheader">remove_objects_business_s3</td>
  </tr> 
  <tr>  
    <td class="subheader">remove_objects_processed_s3</td>
  </tr>
  <tr>
    <td class="subheader">drop_athena_databases</td>
    <td class="texto">Exclui os databases do Athena, caso eles existeam(scci_raw, scci_processed, scci_business).</td>
  </tr>
  <tr>
    <td class="subheader">upload_to_s3</td>
    <td class="texto">Envia os CSVs gerados das tabelas para o bucket bancobari-prognum-raw de todas as tabelas da base SCCI.</td>
  </tr>
  <tr>
    <td class="subheader">create_athena_databases</td>
    <td class="texto">Cria os bancos do Athena - scci_raw, scci_processed, scci_business.</td>
  </tr>
  <tr>
    <td class="subheader">create_raw_tables</td>
    <td class="texto" rowspan="3">Cria as tabelas de cada banco respectivamente.</td>
  </tr>
  <tr>
    <td class="subheader">create_processed_tables</td>
  </tr> 
  <tr>  
    <td class="subheader">create_business_tables</td>
  </tr>
  <tr>
    <td class="subheader">drop_tables_redshift</td>
    <td class="texto">Faz o drop das tabelas no Redshift, caso elas existam.</td>
  </tr>
  <tr>
    <td class="subheader">create_tables_redshift</td>
    <td class="texto">Cria as tabelas no Redshift, referentes ao DW Originação</td>
  </tr>
  <tr>
    <td class="subheader">load_table_DIM_CUSTOMER_redshift</td>
    <td class="texto" rowspan="4">Faz o carregamento dos dados que estão armazenados no s3 em cada uma das tabelas do DW no Redshift, estas tarefas são executadas de maneira concomitante.</td>
  </tr>
  <tr>
    <td class="subheader">load_table_DIM_LOCATION_redshift</td>
  </tr> 
  <tr>  
    <td class="subheader">load_table_DIM_DATE_redshift</td>
  </tr>
  <tr>  
    <td class="subheader">load_table_FACT_PROSPECTS_redshift</td>
  </tr>
  <tr>
    <td class="subheader">end_log</td>
    <td class="texto">Task Final - apenas indica o horário de encerramento da execução do fluxo.</td>
  </tr> 
</table><br>

                                                                                                                                                
#### Data-Team

Em caso de dúvidas, favor contactar:

- [Anderson Igarashi](mailto:anderson.igarashi@baripromotora.com.br)
- [Marcos Gritti](mailto:marcos.gritti@baritecnologia.com.br)
- [Luiz Vidal](mailto:luiz.vidal@baritecnologia.com.br)

</p>
</details>