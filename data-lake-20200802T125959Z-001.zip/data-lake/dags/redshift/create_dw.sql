CREATE TABLE dim_date(
  d_key 		INTEGER 	NOT NULL, 
  d_date 		DATE 		NOT NULL, 
  d_year 		INTEGER 	NOT NULL, 
  d_quarter 	INTEGER 	NOT NULL, 
  d_month 		VARCHAR(10) NOT NULL, 
  d_monthnum 	INTEGER 	NOT NULL, 
  d_week 		INTEGER 	NOT NULL, 
  d_day 		VARCHAR(10) NOT NULL, 
  d_daynum 		INTEGER 	NOT NULL
);

CREATE TABLE dim_location(
  l_key 		INTEGER 	NOT NULL, 
  l_city 		VARCHAR(50) NOT NULL, 
  l_state 		CHAR(2) NOT NULL,  
  l_region 	VARCHAR(15) NOT NULL, 
  l_country 		VARCHAR(50) NOT NULL
);

CREATE TABLE dim_customer(
  c_key 		BIGINT NOT NULL, 
  c_number 	SMALLINT, 
  c_name 		VARCHAR(50) NOT NULL,  
  c_age 	SMALLINT , 
  c_age_range VARCHAR(30) NOT NULL,
  c_type VARCHAR(10) NOT NULL,
  c_function VARCHAR(15) NOT NULL,
  c_gender VARCHAR(10) NOT NULL,
  c_occupation VARCHAR(200) NOT NULL
);

CREATE TABLE fact_prospects(
  p_key 		BIGINT NOT NULL, 
  p_city 	INTEGER, 
  p_date 		INTEGER NOT NULL,  
  p_phase 	VARCHAR(15) , 
  p_status 	VARCHAR(15) , 
  p_productname VARCHAR(20) ,
  p_payertype CHAR(2) ,
  p_financialmodel VARCHAR(5) ,
  p_index VARCHAR(15) ,
  p_warranty VARCHAR(15)
);