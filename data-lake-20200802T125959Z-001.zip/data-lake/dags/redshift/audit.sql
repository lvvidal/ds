CREATE TABLE IF NOT EXISTS audit_dag(
  dag_id 		VARCHAR(255) 	NOT NULL, 
  task_id 		VARCHAR(255) 	NOT NULL,
  job_id      VARCHAR(255) 	NOT NULL, 
  task_type 	VARCHAR(255) 	NOT NULL, 
  execution_date 	DATE NOT NULL,
  start_date 	TIMESTAMP NOT NULL, 
  end_date 		TIMESTAMP NOT NULL, 
  task_function	 	VARCHAR(255),
  script_command VARCHAR(MAX),
  bucket 		VARCHAR(255), 
  filesize		VARCHAR(255),
  dbtype		VARCHAR(255),
  dbname		VARCHAR(255),
  ddltype		VARCHAR(255),
  tablename		VARCHAR(255),
  rowquantity	BIGINT  
);