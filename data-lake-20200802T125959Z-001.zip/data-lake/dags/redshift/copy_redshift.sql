copy dim_date from 's3://{bucket_name}/originacao/DIM_DATE' 
credentials 'aws_access_key_id=AKIA2RJZGORW73QQC3WK;aws_secret_access_key=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' 
delimiter '\001' 
gzip
region 'us-east-1';

copy credito.dim_serie from 's3://bancobari-prognum-business-213912952026/credito/DIM_SERIE' 
iam_role 'arn:aws:iam::213912952026:role/RedShift-redshift-cluster-dw'
delimiter '|' 
gzip
region 'us-east-1'; 

copy credito.dim_imovel from 's3://bancobari-prognum-business-213912952026/credito/DIM_IMOVEL' 
iam_role 'arn:aws:iam::213912952026:role/RedShift-redshift-cluster-dw'
delimiter '|' 
gzip
region 'us-east-1'; 

copy credito.dim_cliente from 's3://bancobari-prognum-business-213912952026/credito/DIM_CLIENTE' 
iam_role 'arn:aws:iam::213912952026:role/RedShift-redshift-cluster-dw'
delimiter '|' 
gzip
region 'us-east-1'; 

copy fact_prospects from 's3://{bucket_name}/originacao/FACT_PROSPECTS' 
credentials 'aws_access_key_id=AKIA2RJZGORW73QQC3WK;aws_secret_access_key=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' 
delimiter '\001' 
gzip
region 'us-east-1';