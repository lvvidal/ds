### Dag: Prognum_CSV_Extraction_Upload_S3
<details>
  <summary>
  Clique aqui para maiores informações sobre a Dag
  </summary>
<p>

<p align="center">
  <a href="http://www.bariguifinanceira.com.br/">
    <img src="http://www.bariguicreditointeligente.com.br/wp-content/themes/barigui-v2/images/bari.png" alt="Barigui" width="128" height="44">
  </a>
</p>

#### Propósito

Esta DAG aguarda o arquivo de backup da base Firebird - SCCI estar disponível no bucket S3, faz o download para o servidor onde roda o Firebird e o Airflow, em seguida restaura a base e extrai o backup, por fim um script python transforma todas as tabelas em arquivos CSV e os copia para o bucket que será lido pelo AWS Athena na nuvem. 

#### Tasks

Este workflow faz as seguintes tarefas:

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
.tg .header{border-color:inherit;font-weight:bold;text-align:center;vertical-align:center}
.tg .subheader{border-color:inherit;font-size:12px;color: red;font-weight:bold;text-align:left;vertical-align:center}
.tg .texto{border-color:inherit;font-size:12px;font-weight:normal;text-align:left;vertical-align:center}
</style>
<table class="tg">
  <tr>
    <th class="header">Task</th>
    <th class="header">Função</th>
  </tr>
  <tr>
    <td class="subheader">start_log</td>
    <td class="texto">Task Inicial - apenas indica o horário de início da execução do fluxo.</td>
  </tr>
  <tr>
    <td class="subheader">file_sensor_hipotecaria</td>
    <td class="texto">Esta task verifica se a base Firebird - Prognum, arquivo scci.gdb correspondente a base da Barigui Hipotecária, oriunda do servidor da Central Server, na pasta /home/barigui/bkp/barigui.gbk.bz2, já está disponível no Bucket s3.</td>
  </tr>
  <tr>
    <td class="subheader">file_sensor_securitizadora</td>
    <td class="texto">Esta task verifica se a base Firebird - Prognum, arquivo scci.gdb correspondente a base da Barigui Securitizadora, oriunda do servidor da Central Server, na pasta já está /home/aster/bkp/aster.gbk.bz2, disponível no Bucket s3.</td>
  </tr>
    <tr>
    <td class="subheader">file_sensor_banco</td>
    <td class="texto">Esta task verifica se a base Firebird - Prognum, arquivo scci.gdb correspondente a base da Bari, oriunda do servidor da AWS, na pasta já está /home/bari/bkp/bari.gbk.bz2, disponível no Bucket s3.</td>
  </tr>
  <tr>
    <td class="subheader">download_from_s3_securitizadora</td>
    <td class="texto" rowspan="3">Uma vez que a base da Securitizadora esteja disponível no bucket S3, o mesmo é baixado para o servidor ec2 onde está rodando o Airflow, mais precisamente no docker que está rodando o Firebird.</td>
  </tr>
  <tr>
    <td class="subheader">download_from_s3_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">download_from_s3_banco</td>
  </tr>
  <tr>
    <td class="subheader">restore_db_securitizadora</td>
    <td class="texto" rowspan="3">Esta task tem por função descompactar o arquivo zipado em formato bzip2 para gbk e em seguida chamar o utilitário do Firebird - gbak - que irá transformar o arquivo gbk em gdb.</td>
  </tr>
  <tr>
    <td class="subheader">restore_db_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">restore_db_banco</td>
  </tr>
  <tr>
    <td class="subheader">extract_backup_securitizadora</td>
    <td class="texto" rowspan="3">Esta task roda um script python que conecta-se a base Firebird - e extrai todas as tabelas que possuem pelo menos 1 registro (uma linha), em seguida le o conteúdo de cada campo e transforma tudo em string, por fim salva em um arquivo .csv com o nome da tabela.</td>
  </tr>
  <tr>
    <td class="subheader">extract_backup_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">extract_backup_banco</td>
  </tr>
  <tr>
    <td class="subheader">create_ddl_raw_athena_tables_securitizadora</td>
    <td class="texto" rowspan="3">Esta task roda um script python que conecta-se a base Firebird - e extrai o schema de todas as tabelas que possuem pelo menos 1 registro (uma linha), em seguida é gerado um script .sql de criação de tabela, a ser utilizado pelo AWS Athena.</td>
  </tr>
  <tr>
    <td class="subheader">create_ddl_raw_athena_tables_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">create_ddl_raw_athena_tables_banco</td>
  </tr>
  <tr>
    <td class="subheader">remove_objects_raw_s3_securitizadora</td>
    <td class="texto" rowspan="3">Esta task remove os objetos do bucket a partir de uma chave determinada, por exemplo, caso a chave seja scci/securitizadora/2020/01/01, todos os objetos s3 que estiver nesta pasta serão removidos.</td>
  </tr>
  <tr>
    <td class="subheader">remove_objects_raw_s3_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">remove_objects_raw_s3_banco</td>
  </tr>
  <tr>
    <td class="subheader">upload_to_s3_securitizadora</td>
    <td class="texto" rowspan="3">Esta task tem por função mover todos os arquivos .csv's extraídos da base Firebird para sua respectiva pasta no bucket "Raw" que posteriormente será consumido pelo AWS Athena.</td>
  </tr>
  <tr>
    <td class="subheader">upload_to_s3_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">upload_to_s3_banco</td>
  </tr>
  <tr>
    <td class="subheader">end_log</td>
    <td class="texto">Task Final - apenas indica o horário de encerramento da execução do fluxo.</td>
  </tr>
</table><br>
                                                                                                                                               
#### Data-Team

Em caso de dúvidas, favor contactar:

- [Anderson Igarashi](mailto:anderson.igarashi@baripromotora.com.br)
- [Marcos Gritti](mailto:marcos.gritti@baritecnologia.com.br)
- [Luiz Vidal](mailto:luiz.vidal@baritecnologia.com.br)

</p>
</details>