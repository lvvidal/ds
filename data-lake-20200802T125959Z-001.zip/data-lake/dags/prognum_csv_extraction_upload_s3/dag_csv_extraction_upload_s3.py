# Name:  dag_prognum_athena_processing.py
# Purpose : This DAG produces extracts CSVs from SCCI - Firebird and upload it to S3, to be consumed by AWS Athena.
# Created at: 2019-11-22
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
#          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>

from __future__ import print_function

from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook

from dependencies.tasks.task_success import TaskSuccess
from dependencies.tasks.task_fail import task_fail_alert
from dependencies.bancobari_airflow_defaults import (
    get_account_id,
    REDSHIFT_CONN_ID,
    AWS_CONN_ID,
    AIRFLOW_HOME
)
from dependencies.s3_helper_functions import remove_objects_from_bucket
from dependencies.tasks.task_colors import set_operator_color

# DAG Colors
from dependencies.bari_s3_key_sensor import BariS3KeySensor

set_operator_color()

BANCO = "banco"
SECURITIZADORA = "securitizadora"
HIPOTECARIA = "hipotecaria"

# Global Variables
DATABASES = [
    (BANCO,          '0  4 * * *'),
    (SECURITIZADORA, '0  4 * * *'),
    (HIPOTECARIA,    '15 4 * * *'),  # 03:45UTC is 00:45 'America/Sao_Paulo'
]

ACCOUNT_ID = get_account_id()

RAW_BUCKET_NAME = f'bancobari-prognum-raw-{ACCOUNT_ID}'
PROCESSED_BUCKET_NAME = f'bancobari-prognum-processed-{ACCOUNT_ID}'
BACKUP_BUCKET_NAME = f'bancobari-prognum-backup-{ACCOUNT_ID}'

DESTINATION_BUCKET_NAME = f"bancobari-prognum-raw-{ACCOUNT_ID}"

DAG_NAME = 'Prognum_CSV_Extraction_Upload_S3'

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

args = {
    'owner': 'data-team',
    'start_date': datetime(2020, 1, 3),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': True,
    'email_on_failure': True,
    'on_failure_callback': task_fail_alert,
    'on_success_callback': ts.task_success,
}

for database, cron_expr in DATABASES:

    dag_name = f"{DAG_NAME}_{database}"

    dag = DAG(
        dag_id=dag_name,
        default_args=args,
        catchup=False,
        schedule_interval=cron_expr)

    with open(f'{AIRFLOW_HOME}/dags/prognum_csv_extraction_upload_s3/dag_csv_extraction_upload_s3.md', 'r') as f:
        dag.doc_md = f.read()

    start_log = DummyOperator(
        task_id='start_log',
        dag=dag)

    BACKUP_BUCKET_KEY = f'scci/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/{database}.gbk.bz2'

    file_sensor = BariS3KeySensor(
        s3_hook=s3_hook,
        pg_hook=pg_hook,
        task_id=f'file_sensor_{database}',
        bucket_key=BACKUP_BUCKET_KEY,
        bucket_name=BACKUP_BUCKET_NAME,
        aws_conn_id=AWS_CONN_ID,
        poke_interval=60,  # 1 minute
        timeout=60 * 60 * 4,  # 4 hours
        wildcard_match=True,
        soft_fail=True,
        dag=dag)

    # faz o download do backup armazenado no s3
    download_from_s3 = SSHOperator(
        task_id=f'download_from_s3_{database}',
        ssh_conn_id="ssh_firebird",
        command=f'/download_backup_from_s3.sh {BACKUP_BUCKET_NAME} {BACKUP_BUCKET_KEY} {database} {{{{ ds }}}} ',
        dag=dag)

    # restaura arquivo .gbd
    restore_db = SSHOperator(
        task_id=f'restore_db_{database}',
        ssh_conn_id="ssh_firebird",
        command=f'/restore_db.sh {database} {{{{ ds }}}}',
        dag=dag)

    # extrai o backup do arquivo .gbd
    extract_backup = SSHOperator(
        task_id=f'extract_backup_{database}',
        ssh_conn_id="ssh_firebird",
        command=f'/extract_db.sh {database} {{{{ ds }}}}',
        dag=dag)

    # cria os ddls a serem utilizados pelo Athena
    create_ddl_raw_athena_tables = SSHOperator(
        task_id=f'create_ddl_raw_athena_tables_{database}',
        ssh_conn_id="ssh_firebird",
        command=f'/create_ddl_raw_athena_tables.sh {database} {{{{ ds }}}}',
        dag=dag)

    # limpa objetos dos buckets
    remove_objects_raw_s3 = PythonOperator(
        task_id=f'remove_objects_raw_s3_{database}',
        python_callable=remove_objects_from_bucket,
        op_kwargs={
            's3_hook': s3_hook,
            'bucket': f'bancobari-prognum-raw-{ACCOUNT_ID}',
            'prefix': f'scci/{database}/{{{{ execution_date.strftime("%Y/%m/%d") }}}}',
            'task_success': ts,
            'task_id': 'remove_objects_raw_s3'
        },
        on_success_callback=ts.task_success,
        dag=dag)

    # faz o upload dos csv para o bucket s3
    upload_raw_files_to_s3 = SSHOperator(
        task_id=f'upload_raw_files_to_s3_{database}',
        ssh_conn_id="ssh_firebird",
        command=f'/upload_raw_files_to_s3.sh {database} {RAW_BUCKET_NAME} {{{{ ds }}}}',
        dag=dag)

    end_log = DummyOperator(
        task_id='end_log',
        dag=dag)

    if database == HIPOTECARIA:
        # python3 create_ddl_processed_athena_tables.py banco 2020-02-10 /tmp/ddl
        # cria os ddls a serem utilizados pelo Athena
        create_ddl_processed_athena_tables = SSHOperator(
            task_id=f'create_ddl_processed_athena_tables',
            ssh_conn_id="ssh_firebird",
            command='/usr/bin/python3 /create_ddl_processed_athena_tables.py banco,hipotecaria,securitizadora {{ ds }} /firebird/data ',
            dag=dag)

        # faz o upload dos csv para o bucket s3
        upload_processed_ddls_to_s3 = SSHOperator(
            task_id='upload_processed_ddls_to_s3',
            ssh_conn_id="ssh_firebird",
            command=f'/upload_processed_ddls_to_s3.sh {PROCESSED_BUCKET_NAME} {{{{ ds }}}}',
            dag=dag)

        start_log >> file_sensor >> download_from_s3 >> restore_db >> \
        extract_backup >> create_ddl_raw_athena_tables >> \
        create_ddl_processed_athena_tables >> upload_processed_ddls_to_s3 >> \
        remove_objects_raw_s3 >> upload_raw_files_to_s3 >> end_log

    else:
        start_log >> file_sensor >> download_from_s3 >> restore_db >> \
        extract_backup >> create_ddl_raw_athena_tables >> \
        remove_objects_raw_s3 >> upload_raw_files_to_s3 >> end_log

    globals()[dag_name] = dag
