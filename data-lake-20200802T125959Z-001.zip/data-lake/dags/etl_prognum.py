# # Name:  dag_prognum_athena_processing.py
# # Purpose : This DAG produces credit KPI's and analytics for the Self-Service BI, yet to be consumed by the Credit area.
# # Created at: 2019-11-22
# # Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
# #          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
# #          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>
#
# from __future__ import print_function
#
# from datetime import datetime, timedelta
# from airflow.models import DAG
# from airflow.operators.subdag_operator import SubDagOperator
# from airflow.contrib.operators.ssh_operator import SSHOperator
# from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
# from airflow.operators.python_operator import PythonOperator
# from airflow.operators.dummy_operator import DummyOperator
# from airflow.operators.bash_operator import BashOperator
# from airflow.operators.postgres_operator import PostgresOperator
# from airflow.operators.s3_to_redshift_operator import S3ToRedshiftTransfer
# from airflow.operators.sensors import S3KeySensor
# from airflow.hooks.S3_hook import S3Hook
# from airflow.hooks.postgres_hook import PostgresHook
#
# from dependencies.tasks.task_success import TaskSuccess
# from dependencies.tasks.task_fail import task_fail_alert
# from dependencies.bancobari_airflow_defaults import \
#     get_account_id, \
#     REDSHIFT_CONN_ID, \
#     AWS_CONN_ID, \
#     AIRFLOW_HOME
# from dependencies.athena_helper_functions import create_athena_tables, drop_athena_databases, create_athena_databases
# from dependencies.s3_helper_functions import download_file, remove_objects_from_bucket, upload_files
# from etl_originacao import create_sub_dag_originacao
#
# # Operator Colors
# BashOperator.ui_color = '#c9c5b9'
# DummyOperator.ui_color = '#c9c5b9'
# S3KeySensor.ui_color = '#c72724'
# PythonOperator.ui_color = '#daed07'
# PostgresOperator.ui_color = '#2c18db'
# S3ToRedshiftTransfer.ui_color = '#ed8907'
# SSHOperator.ui_color = '#146b1c'
#
# DAG_NAME = 'ETL_Prognum'
# DAG_ORIGINACAO_NAME = 'ETL_Originacao'
# DAG_CADASTRO_NAME = 'ETL_Cadastro'
#
# # Global Variables
# DATABASE = "scci"
#
# ACCOUNT_ID = get_account_id()
#
# SOURCE_BUCKET_NAME = f'bancobari-prognum-backup-{ACCOUNT_ID}'
# SOURCE_BUCKET_KEY = '{DATABASE}/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/{DATABASE}.gbk.bz2' \
#     .format(DATABASE=DATABASE)
#
# DESTINATION_BUCKET_NAME = f"bancobari-prognum-raw-{ACCOUNT_ID}"
#
# # Hooks
# s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
# athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
# pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
#
#
# args = {
#     'owner': 'data-team',
#     'start_date': datetime(2020, 1, 1),
#     'depends_on_past': False,
#     'retries': 3,
#     'retry_delay': timedelta(minutes=5),
#     'email_on_retry': True,
#     'email_on_failure': True,
#     'on_failure_callback': task_fail_alert,
# }
#
#
# dag = DAG(
#     dag_id=DAG_NAME,
#     default_args=args,
#     start_date=datetime.utcnow() - timedelta(days=2),
#     catchup=False,
#     schedule_interval='0 2 * * *')
#
# with open(f'{AIRFLOW_HOME}/dags/etl_originacao.md', 'r') as f:
#     dag.doc_md = f.read()
#
# start_log = DummyOperator(
#     task_id='start_log',
#     dag=dag)
#
# file_sensor = S3KeySensor(
#     task_id='file_sensor',
#     bucket_key=SOURCE_BUCKET_KEY,
#     bucket_name=SOURCE_BUCKET_NAME,
#     aws_conn_id=AWS_CONN_ID,
#     poke_interval=10,
#     timeout=10,
#     wildcard_match=True,
#     soft_fail=True,
#     dag=dag)
#
# download_from_s3_success = TaskSuccess(s3_hook, pg_hook)
# download_from_s3 = PythonOperator(
#     task_id='download_from_s3',
#     python_callable=download_file,
#     op_kwargs={
#         'bucket': SOURCE_BUCKET_NAME,
#         'key': SOURCE_BUCKET_KEY,
#         'destination': '/firebird/data/{DATABASE}.gbk.bz2'.format(DATABASE=DATABASE),
#         'task_success': download_from_s3_success
#     },
#     on_success_callback=download_from_s3_success.task_success,
#     dag=dag)
#
# # restaura arquivo .gbd
# restore_db_success = TaskSuccess(s3_hook, pg_hook)
# restore_db = SSHOperator(
#     task_id='restore_db',
#     ssh_conn_id="ssh_firebird",
#     command='/restore_db.sh {}'.format(DATABASE),
#     on_success_callback=restore_db_success.task_success,
#     dag=dag)
#
# # gera .csv
# extract_backup_success = TaskSuccess(s3_hook, pg_hook)
# extract_backup = SSHOperator(
#     task_id='extract_backup',
#     ssh_conn_id="ssh_firebird",
#     command='/extract_db.sh {}'.format(DATABASE),
#     on_success_callback=extract_backup_success.task_success,
#     dag=dag)
#
# # limpa objetos dos buckets
# remove_objects_raw_s3_success = TaskSuccess(s3_hook, pg_hook)
# remove_objects_raw_s3 = PythonOperator(
#     task_id='remove_objects_raw_s3',
#     python_callable=remove_objects_from_bucket,
#     op_kwargs={
#         'bucket': f'bancobari-prognum-raw-{ACCOUNT_ID}',
#         'task_success': download_from_s3_success
#     },
#     on_success_callback=remove_objects_raw_s3_success.task_success,
#     dag=dag)
#
# remove_objects_processed_s3_success = TaskSuccess(s3_hook, pg_hook)
# remove_objects_processed_s3 = PythonOperator(
#     task_id='remove_objects_processed_s3',
#     python_callable=remove_objects_from_bucket,
#     op_kwargs={
#         'bucket': f'bancobari-prognum-processed-{ACCOUNT_ID}',
#         'task_success': remove_objects_processed_s3_success
#     },
#     on_success_callback=remove_objects_processed_s3_success.task_success,
#     dag=dag)
#
# remove_objects_business_s3_success = TaskSuccess(s3_hook, pg_hook)
# remove_objects_business_s3 = PythonOperator(
#     task_id='remove_objects_business_s3',
#     python_callable=remove_objects_from_bucket,
#     op_kwargs={
#         'bucket': f'bancobari-prognum-business-{ACCOUNT_ID}',
#         'task_success': remove_objects_business_s3_success
#     },
#     on_success_callback=remove_objects_business_s3_success.task_success,
#     dag=dag)
#
# upload_to_s3_success = TaskSuccess(s3_hook, pg_hook)
# upload_to_s3 = PythonOperator(
#     task_id='upload_to_s3',
#     python_callable=upload_files,
#     op_kwargs={
#         'bucket': DESTINATION_BUCKET_NAME,
#         'source_file_pattern': f'/firebird/data/{DATABASE}/*.csv',
#         'destination': DATABASE,
#         'task_success': upload_to_s3_success
#     },
#     on_success_callback=upload_to_s3_success.task_success,
#     dag=dag)
#
# drop_athena_databases_success = TaskSuccess(s3_hook, pg_hook)
# drop_athena_databases = PythonOperator(
#     task_id='drop_athena_databases',
#     python_callable=drop_athena_databases,
#     op_kwargs={
#         'prefix': 'scci_',
#         'databases': f'{AIRFLOW_HOME}/dags/athena/',
#         'task_success': drop_athena_databases_success
#     },
#     on_success_callback=drop_athena_databases_success.task_success,
#     dag=dag)
#
# create_athena_databases_success = TaskSuccess(s3_hook, pg_hook)
# create_athena_databases = PythonOperator(
#     task_id='create_athena_databases',
#     python_callable=create_athena_databases,
#     op_kwargs={
#         'prefix': 'scci_',
#         'databases': f'{AIRFLOW_HOME}/dags/athena/',
#         'task_success': create_athena_databases_success
#     },
#     on_success_callback=create_athena_databases_success.task_success,
#     dag=dag)
#
# create_raw_tables_success = TaskSuccess(s3_hook, pg_hook)
# create_raw_tables = PythonOperator(
#     task_id='create_raw_tables',
#     python_callable=create_athena_tables,
#     op_kwargs={
#         'athena_database_name': 'scci_raw',
#         'bucket_name': f'bancobari-prognum-raw-{ACCOUNT_ID}',
#         'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/raw/',
#         'task_success': create_raw_tables_success
#     },
#     on_success_callback=create_raw_tables_success.task_success,
#     dag=dag)
#
# create_processed_tables_success = TaskSuccess(s3_hook, pg_hook)
# create_processed_tables = PythonOperator(
#     task_id='create_processed_tables',
#     python_callable=create_athena_tables,
#     op_kwargs={
#         'athena_database_name': 'scci_processed',
#         'bucket_name': f'bancobari-prognum-processed-{ACCOUNT_ID}',
#         'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/processed/',
#         'task_success': create_processed_tables_success
#     },
#     on_success_callback=create_processed_tables_success.task_success,
#     dag=dag)
#
# sub_dag_originacao = SubDagOperator(
#   subdag=create_sub_dag_originacao(
#         DAG_NAME,
#         DAG_ORIGINACAO_NAME,
#         dag.start_date,
#         dag.schedule_interval),
#   task_id=DAG_ORIGINACAO_NAME,
#   dag=dag,
# )
#
# end_log = DummyOperator(
#     task_id='end_log',
#     dag=dag)
#
# start_log >> file_sensor >> download_from_s3 >> restore_db >> \
#     extract_backup >> [remove_objects_raw_s3, remove_objects_processed_s3, remove_objects_business_s3] >> \
#     drop_athena_databases >> upload_to_s3 >> create_athena_databases >> \
#     create_raw_tables >> create_processed_tables >> sub_dag_originacao >> \
#     end_log
