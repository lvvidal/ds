#!/bin/bash
REMOTEHOST=redshift-cluster-dw.ca7g2lurue6s.us-east-1.redshift.amazonaws.com
REMOTEPORT=5439
TIMEOUT=1

dt=$(date +%FT%H:%M:%S)

if nc -w $TIMEOUT -z $REMOTEHOST $REMOTEPORT; then
    echo "${dt} I was able to connect to ${REMOTEHOST}:${REMOTEPORT}"
else
    echo "${dt} Connection to ${REMOTEHOST}:${REMOTEPORT} failed. Exit code from Netcat was ($?)."
fi