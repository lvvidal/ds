# def print_context(ds, x, *args, **kwargs):
#     pprint(args)
#     pprint(kwargs)
#     print(ds)
#     print(x)
#     return 'Whatever you return gets printed in the logs'
#
# workflow = DAG('foo', default_args=default_args)
#
# run_this = PythonOperator(
#     task_id='print_the_context',
#     provide_context=True,
#     python_callable=print_context,
#     dag=workflow,
#     op_args=['1',])