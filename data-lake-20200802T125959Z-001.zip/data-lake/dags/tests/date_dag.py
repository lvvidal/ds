from datetime import datetime

from pprint import pprint
import pytz
from airflow import DAG
from airflow.operators.python_operator import PythonOperator

local = pytz.timezone ("America/Sao_Paulo")

default_args = {"owner": "airflow", "start_date": datetime(2020, 4, 1)}

dag = DAG(
    dag_id="context_demo",
    default_args=default_args,
    schedule_interval="0 14 * * *"
)

# The PythonOperator with provide_context=True passes the Airflow context to the given callable
def _print_exec_date(**context):
    now = datetime.utcnow()
    now_br = now.astimezone(local)
    print(f"now   = {now}")
    print(f"local = {now_br}")
    pprint(context)
    # Prints e.g. 2018-10-01T00:00:00+00:00

print_exec_date = PythonOperator(
    task_id="print_exec_date",
    python_callable=_print_exec_date,
    provide_context=True,
    dag=dag,
)