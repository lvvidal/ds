import psycopg2
from pprint import pprint

# AIRFLOW_CONN_REDSHIFT=postgres://awsuser:AwSPr0gn1@redshift-cluster-dw.ca7g2lurue6s.us-east-1.redshift.amazonaws.com:5439/bari_dw

configuration = {
    'dbname': 'bari_dw',
    'user': 'awsuser',
    'pwd': 'AwSPr0gn1',
    # 'host': 'localhost',
    'host': 'redshift-cluster-dw.ca7g2lurue6s.us-east-1.redshift.amazonaws.com',
    'port': '5439'
}

def create_conn(*args, **kwargs):
    config = kwargs['config']
    conn = None
    try:
        conn = psycopg2.connect(dbname=config['dbname'],
                                host=config['host'],
                                port=config['port'],
                                user=config['user'],
                                password=config['pwd'])
    except Exception as err:
        print(err)
        exit(1)

    return conn


def select(*args, **kwargs):
    # need a connection with dbname=<username>_db
    cur = kwargs['cur']

    load_statement = """
    SELECT count(*), dp.p_dtobservacao 
    FROM credito.dim_parcela dp
    group by dp.p_dtobservacao
    order by dp.p_dtobservacao desc;
    """

    try:
        # retrieving all tables in my search_path
        cur.execute(load_statement)
    except Exception as err:
        print(err)

    rows = cur.fetchall()
    for row in rows:
        print(row)

print('start')
conn = create_conn(config=configuration)
cursor = conn.cursor()
print('start select')
select(cur=cursor)
print('finish')

cursor.close()
conn.close()
