from datetime import datetime

from pprint import pprint
import pytz
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator

from calendar import monthrange

from datetime import datetime, timedelta
from airflow.models import DAG
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook

from dependencies.tasks.task_success import TaskSuccess
from dependencies.tasks.task_fail import task_fail_alert
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AWS_CONN_ID, \
    AIRFLOW_HOME
from dependencies.athena_helper_functions import (create_athena_tables,
                                                  drop_athena_databases,
                                                  create_athena_databases,
                                                  athena_remove_partition_from_bucket)
from dependencies.s3_helper_functions import download_file, remove_objects_from_bucket
from dependencies.tasks.task_colors import set_operator_color

# DAG Colors
from redshift.RedshiftExecuteSQLsOperator import RedshiftExecuteSQLsOperator

set_operator_color()

local = pytz.timezone ("America/Sao_Paulo")

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

default_args = {
    "owner": "airflow",
    "start_date": datetime(2020, 4, 1),
    # 'on_failure_callback': task_fail_alert,
    # 'on_success_callback': ts.task_success,
}

dag = DAG(
    dag_id="redshift_test",
    default_args=default_args,
    schedule_interval="*/5 * * * *",
    dagrun_timeout=timedelta(seconds=90),
    catchup=False
)

# The PythonOperator with provide_context=True passes the Airflow context to the given callable
def _print_exec_date(**context):
    now = datetime.utcnow()
    now_br = now.astimezone(local)
    print(f"now   = {now}")
    print(f"local = {now_br}")
    pprint(context)
    # Prints e.g. 2018-10-01T00:00:00+00:00

def process_product_dim_py(**kwargs):
    pg_hook = kwargs.get('pg_hook')
    sql = kwargs.get('sql')
    print(f"sql={sql}")
    records = pg_hook.get_records(sql)
    print(f"return from redshift at {datetime.now(pytz.utc)}, records: {records}")
    return records

start_log = DummyOperator(
    task_id='start_log',
    dag=dag)

print_exec_date = PythonOperator(
    task_id="print_exec_date",
    python_callable=_print_exec_date,
    provide_context=True,
    dag=dag,
)

# show_tables_id = PythonOperator(
#     task_id='show_tables_id',
#     op_kwargs={
#         'pg_hook': pg_hook,
#         'sql': "show tables;"
#     },
#     python_callable=process_product_dim_py,
#     dag=dag)

select_id_1 = PythonOperator(
    task_id='select_id_1',
    op_kwargs={
        'pg_hook': pg_hook,
        'sql': """
            select count(*) as total, dt_obs , tp_origem 
            from imobiliario.portfolio_daily
            where flag_renegociacao = true
            group by dt_obs , tp_origem
            order by tp_origem asc, dt_obs desc;
        """
    },
    python_callable=process_product_dim_py,
    dag=dag)

select_id_2 = PythonOperator(
    task_id='select_id_2',
    op_kwargs={
        'pg_hook': pg_hook,
        'sql': """
            select count(*) as "countctrmonthly" , pm.anomes , pm.tp_origem 
            from imobiliario.portfolio_monthly pm
            group by pm.anomes , pm.tp_origem 
            order by pm.tp_origem  asc, pm.anomes desc;
        """
    },
    python_callable=process_product_dim_py,
    dag=dag)

select_id_3 = PythonOperator(
    task_id='select_id_3',
    op_kwargs={
        'pg_hook': pg_hook,
        'sql': """
            select count(*) as "countctrdaily", pd.dt_obs , pd.tp_origem 
            from imobiliario.portfolio_daily pd
            group by pd.dt_obs , pd.tp_origem 
            order by pd.tp_origem asc, pd.dt_obs desc;
        """
    },
    python_callable=process_product_dim_py,
    dag=dag)

end_log = DummyOperator(
    task_id='end_log',
    dag=dag)

start_log >> print_exec_date >> select_id_1 >> select_id_2 >> select_id_3 >> end_log

