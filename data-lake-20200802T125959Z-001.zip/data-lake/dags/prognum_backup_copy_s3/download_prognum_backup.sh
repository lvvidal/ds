#!/bin/bash

# usage: ./download_prognum_backup.sh $(date +%F) root localhost $HOME/.ssh/id_rsa.pub /tmp/id_rsa.pub

date_time=$1
ssh_user=$2
ssh_server=$3
remote_file=$4
local_file=$5

file_name=$(basename $local_file | cut -d'.' -f1)

dir_local=$(dirname $local_file)

checksum_local_file="${dir_local}/${file_name}_checksum_local.txt"
checksum_remote_file="${dir_local}/${file_name}_checksum_remote.txt"

chmod 600 "$HOME"/.ssh/id_rsa*

ssh_opts="-o StrictHostKeyChecking=no -i $HOME/.ssh/id_rsa ${ssh_user}@${ssh_server}"

echo "home=$HOME"

function test_exit_status() {
    if [ $1 -ne 0 ]; then
        exit $1
    fi
}

if [ ! -d  "$(dirname $local_file)" ]; then
    mkdir -p "$(dirname $local_file)"
fi

echo "creating checksum for remote file ${remote_file}"
ssh ${ssh_opts} "openssl md5 -binary ${remote_file} | base64" > ${checksum_remote_file}
test_exit_status $?

# if file exists and checksum matches, skip download
if [ -f "$local_file" ]; then
    echo "file ${local_file} exists"

    echo "creating checksum for local file ${local_file}"
    openssl md5 -binary ${local_file} | base64 > ${checksum_local_file}
    test_exit_status $?

    checksum_local="$(cat ${checksum_local_file})"
    checksum_remote="$(cat ${checksum_remote_file})"

    echo "checksum_remote =>  $checksum_remote"
    echo "checksum_local  =>  $checksum_local"

    if [ "${checksum_remote}" != "${checksum_local}" ]; then
        echo "The checksums are different removing files ${local_file}, local=${checksum_local}, remote=${checksum_remote}"
        rm -f "${local_file}" "${checksum_local_file}"
    else
        echo $checksum_local
        exit 0
    fi
fi

echo "copy file from remote site"
scp ${ssh_opts}:${remote_file} ${local_file}
test_exit_status $?

echo "creating checksum for local file ${local_file}"
openssl md5 -binary ${local_file} | base64 > ${checksum_local_file}
test_exit_status $?

checksum_local="$(cat ${checksum_local_file})"
checksum_remote="$(cat ${checksum_remote_file})"

echo "checksum_remote =>  $checksum_remote"
echo "checksum_local  =>  $checksum_local"

if [ "${checksum_remote}" != "${checksum_local}" ]; then
    exit 1
fi

echo ${checksum_local}
exit 0