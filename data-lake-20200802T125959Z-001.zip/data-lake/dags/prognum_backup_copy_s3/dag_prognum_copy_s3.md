### Dag: Prognum_Copy_S3
<details>
  <summary>
  Clique aqui para maiores informações sobre a Dag
  </summary>
<p>

<p align="center">
  <a href="http://www.bariguifinanceira.com.br/">
    <img src="http://www.bariguicreditointeligente.com.br/wp-content/themes/barigui-v2/images/bari.png" alt="Barigui" width="128" height="44">
  </a>
</p>

#### Propósito

Esta DAG aguarda o arquivo de backup da base Firebird - SCCI estar disponível no servidor Prognum, então um checksum é feito do arquivo e em seguida o arquivo é enviado para um bucket s3, servindo como um backup diário das bases da Prognum e também para as atividades da área de dados (BI & ETL). 

#### Tasks

Este workflow faz as seguintes tarefas:

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
.tg .header{border-color:inherit;font-weight:bold;text-align:center;vertical-align:center}
.tg .subheader{border-color:inherit;font-size:12px;color: red;font-weight:bold;text-align:left;vertical-align:center}
.tg .texto{border-color:inherit;font-size:12px;font-weight:normal;text-align:left;vertical-align:center}
</style>
<table class="tg">
  <tr>
    <th class="header">Task</th>
    <th class="header">Função</th>
  </tr>
  <tr>
    <td class="subheader">start_log</td>
    <td class="texto">Task Inicial - apenas indica o horário de início da execução do fluxo.</td>
  </tr>
  <tr>
    <td class="subheader">get_file_securitizadora</td>
    <td class="texto" rowspan="3">Esta task faz o donwload da base da Prognum (arquivo scci.gdb) - referentes aos dados que se encontram no servidor da Central Server atualmente, faz o checksum do arquivo para garantir que o tamanho do arquivo no servidor é o mesmo do arquivo copiado, por fim coloca o mesmo no servidor ec2 da aws.</td>
  </tr>
  <tr>
    <td class="subheader">get_file_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">get_file_banco</td>
  </tr>
  <tr>
    <td class="subheader">copy_to_s3_securitizadora</td>
    <td class="texto" rowspan="3">Copia o arquivo da instância ec2 na AWS para um bucket s3, este bucket funciona será utilizado posteriormente para extração dos dados a serem criados no AWS Athena e serve também como backup da base de produção.</td>
  </tr>
  <tr>
    <td class="subheader">copy_to_s3_hipotecaria</td>
  </tr>
  <tr>
    <td class="subheader">copy_to_s3_banco</td>
  </tr>
  <tr>
    <td class="subheader">remove_old_dirs</td>
    <td class="texto">Esta tarefa tem por missão remover os arquivos da pasta do dia anterior, antes de mover os arquivos do dia corrente, para que não haja nenhum erro de gravação na pasta no momento da cópia.</td>
  </tr>
  <tr>
    <td class="subheader">end_log</td>
    <td class="texto">Task Final - apenas indica o horário de encerramento da execução do fluxo.</td>
  </tr>
</table><br>
                                                                                                                                               
#### Data-Team

Em caso de dúvidas, favor contactar:

- [Anderson Igarashi](mailto:anderson.igarashi@baripromotora.com.br)
- [Marcos Gritti](mailto:marcos.gritti@baritecnologia.com.br)
- [Luiz Vidal](mailto:luiz.vidal@baritecnologia.com.br)

</p>
</details>