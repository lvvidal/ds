# Name:  dag_prognum_copy_s3.py
# Purpose: This DAG backup up Firebird - SCCI databases by copying it from the Central Server and upload it to a S3 bucket.
# Created at: 2019-02-03
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
#          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>

from __future__ import print_function
from datetime import datetime, timedelta

from airflow.models import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.bash_operator import BashOperator
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.contrib.hooks.ssh_hook import SSHHook
from airflow.hooks.postgres_hook import PostgresHook
from airflow.hooks.S3_hook import S3Hook

from dependencies.tasks.task_fail import task_fail_alert
from dependencies.tasks.task_success import TaskSuccess
from dependencies.tasks.task_colors import set_operator_color
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AWS_CONN_ID, \
    AIRFLOW_HOME

# DAG Colors
set_operator_color()

# Global Variables
prognum_ssh_server_conn = "ssh_prognum_producao"

ssh_hook = SSHHook(prognum_ssh_server_conn)

DATABASE = "scci"

ACCOUNT_ID = get_account_id()

BUCKET_NAME = f'bancobari-prognum-backup-{ACCOUNT_ID}'

DAG_NAME = 'Prognum_Copy_to_S3'

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Task Success
ts = TaskSuccess(s3_hook, pg_hook)

args = {
    'owner': 'data-team',
    'start_date': datetime(2020, 1, 1),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': True,
    'email_on_failure': True,
    'on_failure_callback': task_fail_alert,
    'on_success_callback': ts.task_success,
}


# BASE0=34.194.205.116:17400/barigui/;HIPOTECARIA_PRODUCAO;''
# BASE1=3.234.118.114:17400/aster/;SECURITIZADORA_PRODUCAO;''
# 3.227.139.231 172.17.3.55  BANCO

job_info = {
    "hipotecaria": {
        "remote_user": "ubuntu",
        "remote_server": "172.17.3.94",
        "remote_file": "/home/barigui/bkp/barigui.gbk.bz2",
        "local_file": f"{AIRFLOW_HOME}/data/{{{{ ds }}}}/hipotecaria.gbk.bz2"
    },
    "banco": {
        "remote_user": "ubuntu",
        "remote_server": "172.17.3.55",
        "remote_file": "/home/bari/bkp/bari.gbk.bz2",
        "local_file": f"{AIRFLOW_HOME}/data/{{{{ ds }}}}/banco.gbk.bz2"
    },
    "securitizadora": {
        "remote_user": "ubuntu",
        "remote_server": "172.17.3.76",
        "remote_file": "/home/aster/bkp/aster.gbk.bz2",
        "local_file": f"{AIRFLOW_HOME}/data/{{{{ ds }}}}/securitizadora.gbk.bz2"
    }
}



for database, val in job_info.items():

    dag_name = f"{DAG_NAME}_{database}"

    user = val['remote_user']
    server = val['remote_server']
    remote_file = val['remote_file']
    local_file = val['local_file']

    bucket_key = f'scci/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/{database}.gbk.bz2'

    dag = DAG(
        dag_id=dag_name,
        default_args=args,
        catchup=False,
        schedule_interval='30 3 * * *')  # 00:30 GMT-3

    with open(f'{AIRFLOW_HOME}/dags/prognum_backup_copy_s3/dag_prognum_copy_s3.md', 'r') as f:
        dag.doc_md = f.read()

    start_log = DummyOperator(
        task_id='start_log',
        dag=dag)

    get_file = BashOperator(
        task_id=f'get_file_{database}',
        bash_command=f"""{AIRFLOW_HOME}/dags/prognum_backup_copy_s3/download_prognum_backup.sh \
            {{{{ ds }}}} {user} {server} {remote_file} {local_file} """,
        xcom_push=True,
        dag=dag)

    copy_to_s3 = BashOperator(
        task_id=f'copy_to_s3_{database}',
        bash_command=f"""checksum="{{{{ ti.xcom_pull(task_ids='get_file_{database}') }}}}" &&
                         /usr/local/bin/aws s3api put-object \
                            --bucket {BUCKET_NAME} \
                            --key {bucket_key} \
                            --body {local_file} \
                            --content-md5 ${{checksum}} \
                            --metadata md5checksum=${{checksum}} """,
        dag=dag)

    remove_old_dirs = BashOperator(
        task_id='remove_old_dirs',
        bash_command=f"""
        data_dir={AIRFLOW_HOME}/data/{{{{ yesterday_ds }}}}/
        if [ -d  $data_dir ]; then
            echo "removing previous data dir $data_dir"
            rm -rf $data_dir
        fi
        """,
        dag=dag)

    end_log = DummyOperator(
        task_id='end_log',
        dag=dag)

    start_log >> get_file >> copy_to_s3 >> remove_old_dirs >> end_log

    globals()[dag_name] = dag

