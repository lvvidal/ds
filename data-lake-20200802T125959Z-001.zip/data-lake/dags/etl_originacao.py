# Name:  etl_originacao.py
# Purpose : This DAG produces credit KPI's and analytics for the Self-Service BI, yet to be consumed by the Credit area.
# Created at: 2019-11-22
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>
#          Marcos Gritti        <marcos.gritti@baritecnologia.com.br>

from __future__ import print_function

import logging

from airflow.models import DAG
from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.postgres_operator import PostgresOperator
from airflow.hooks.S3_hook import S3Hook
from airflow.hooks.postgres_hook import PostgresHook

from dependencies.tasks.task_success import TaskSuccess
from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AIRFLOW_HOME, \
    AWS_CONN_ID
    

from dependencies.athena_helper_functions import create_athena_tables

# Hooks
s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)
athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
pg_hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)

# Copy command params - Redshift.
redshift_tables = [['/redshift/originacao/drop/dim_date.sql',
                    '/redshift/originacao/drop/dim_customer.sql',
                    '/redshift/originacao/drop/dim_location.sql',
                    '/redshift/originacao/drop/fact_prospects.sql'],
                   ['/redshift/originacao/create/dim_date.sql',
                    '/redshift/originacao/create/dim_customer.sql',
                    '/redshift/originacao/create/dim_location.sql',
                    '/redshift/originacao/create/fact_prospects.sql'],
                   {'DIM_CUSTOMER':'dim_customer', 
                   'DIM_DATE':'dim_date',
                   'DIM_LOCATION':'dim_location', 
                   'FACT_PROSPECTS':'fact_prospects'}
                ]


def create_sub_dag_originacao(parent_dag_name, child_dag_name, start_date, schedule_interval):

    dag = DAG(
        f"{parent_dag_name}.{child_dag_name}",
        start_date=start_date,
        schedule_interval=schedule_interval,
    )

    create_business_tables_success = TaskSuccess(s3_hook, pg_hook)
    create_business_tables = PythonOperator(
        task_id='create_business_tables',
        python_callable=create_athena_tables,
        op_kwargs={
            'athena_database_name': 'scci_business',
            'bucket_name': f'bancobari-prognum_processed_table-business-{get_account_id()}',
            'ddl_dir': f'{AIRFLOW_HOME}/dags/athena/business/',
            'task_success': create_business_tables_success
        },
        on_success_callback=create_business_tables_success.task_success,
        dag=dag)

    drop_tables_redshift_success = TaskSuccess(s3_hook, pg_hook)
    drop_tables_redshift = PostgresOperator(
        task_id='drop_tables_redshift',
        postgres_conn_id=REDSHIFT_CONN_ID,
        sql=redshift_tables[0],
        params={'task_function': 'SQL',
                'dbtype': 'Redshift',
                'dbname': 'bari_dw',
                'ddltype': 'DROP TABLE IF EXISTS <table> CASCADE;',
                'rowquantity': len(redshift_tables[0]),
                'tablename': ','.join([TaskSuccess.get_table_name_from_sql(e) for e in redshift_tables[0]])},
        on_success_callback=drop_tables_redshift_success.task_success,
        dag=dag)

    create_tables_redshift_success = TaskSuccess(s3_hook, pg_hook)
    create_tables_redshift = PostgresOperator(
        task_id='create_tables_redshift',
        postgres_conn_id=REDSHIFT_CONN_ID,
        sql=redshift_tables[1],
        params={'task_function': 'SQL',
                'dbtype': 'Redshift',
                'dbname': 'bari_dw',
                'ddltype': 'CREATE TABLE IF NOT EXISTS <table> ;',
                'rowquantity': len(redshift_tables[1]),
                'tablename': ','.join([TaskSuccess.get_table_name_from_sql(e) for e in redshift_tables[1]])},
        on_success_callback=create_tables_redshift_success.task_success,        
        dag=dag)


    def loop_load_redshift_tables():
        load_table_tasks = []
        for t, v in redshift_tables[2].items():

            logging.info("Loading data into table : {} ".format(t))

            load_tables_redshift_success = TaskSuccess(s3_hook, pg_hook)
            load_tables_redshift = PostgresOperator(
                sql='''
                COPY public.{{ params.tablename }}
                FROM '{{ params.source }}'
                ACCESS_KEY_ID '{{ params.access_key}}'
                SECRET_ACCESS_KEY '{{ params.secret_key }}'
                DELIMITER '\001'
                GZIP 
                REGION 'us-east-1'
                TIMEFORMAT as 'YYYY-MM-DD HH:MI:SS';

                ALTER TABLE public.{{ params.tablename }} RENAME TO {{ params.tablename }}_staging;

                CREATE TABLE
                    public.{{ params.tablename }}
                AS
                SELECT '{{ dag.dag_id }}' as "dw_source",
                    cast('{{ execution_date.strftime("%Y-%m-%d %H:%M:%S") }}' as timestamp) as "dw_inserted_at",
                    cast('{{ (execution_date + macros.timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S") }}' as timestamp) as "dw_updated_at",
                    'scci-prognum_processed_table' as "dw_batch_id",
                st.*
                FROM public.{{ params.tablename }}_staging st;

                DROP TABLE public.{{ params.tablename }}_staging;

                ANALYZE public.{{ params.tablename }};
                ''',
                task_id='load_table_{}_redshift'.format(t),
                postgres_conn_id=REDSHIFT_CONN_ID,
                database="bari_dw",
                params={
                    'source': f's3://bancobari-prognum_processed_table-business-{get_account_id()}/originacao/{t}/',
                    'access_key': s3_hook.get_credentials().access_key,
                    'secret_key': s3_hook.get_credentials().secret_key,
                    'task_function': 'SQL',
                    'dbtype': 'Redshift',
                    'dbname': 'bari_dw',
                    'ddltype': 'COPY <schema>.<table> FROM <bucket> ;',
                    'rowquantity': 0,
                    'tablename': v
                },
                on_success_callback=load_tables_redshift_success.task_success,
                dag=dag)

            load_table_tasks.append(load_tables_redshift)
            
        return load_table_tasks

    create_business_tables >> drop_tables_redshift >> create_tables_redshift >> loop_load_redshift_tables()

    return dag