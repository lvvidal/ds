from __future__ import print_function

import os
import sys
import logging
import uuid
import time
from datetime import datetime
import pytz

from airflow.contrib.hooks.aws_athena_hook import AWSAthenaHook

from dependencies.bancobari_airflow_defaults import \
    get_account_id, \
    REDSHIFT_CONN_ID, \
    AIRFLOW_HOME, \
    AWS_CONN_ID

# Global Variables
from dependencies.s3_helper_functions import remove_objects_from_bucket

athena_hook = AWSAthenaHook(aws_conn_id=AWS_CONN_ID)
ACCOUNT_ID = get_account_id()


def create_athena_tables(bucket_name, athena_database_name, ddl_dir, ds_str=None, task_success=None, task_id=None):

    logging.info(f"create_athena_tables(bucket_name={bucket_name}, athena_database_name={athena_database_name}, "
                 f"ddl_dir={ddl_dir}, ds_str={ds_str}, task_success=..., task_id=...)")

    create_table_sqls = []
    for root, dirs, files in os.walk(ddl_dir):
        for f in files:
            create_table_sqls.append(os.path.join(root, f))

    number_of_tables = len(create_table_sqls)

    # sort é muito importante para garantir a sequencia correta dos sqls
    create_table_sqls.sort()

    logging.info("Create table: #{} scripts.".format(number_of_tables))

    query_context = {
        'Database': athena_database_name
    }

    now = pytz.utc.localize(datetime.utcnow())
    now_str = now.strftime("%Y-%m-%d-%H-%M")

    for i, sql_file in enumerate(create_table_sqls, 1):
        with open(sql_file, 'r') as f:
            logging.info(f"processing sql {sql_file}")
            f_sql = f.read()

            replace_dict = {}
            if ds_str is not None and 'ds_str' in f_sql:
                replace_dict['ds_str'] = ds_str
            elif bucket_name is not None and 'bucket_name' in f_sql:
                replace_dict['bucket_name'] = bucket_name

            logging.info(f"replace_dict={replace_dict}\n{f_sql}")

            f_sql = f_sql.format(**replace_dict)

            logging.info(f"executing sql #{i}/{number_of_tables} => {f_sql}...")
            client_request_token = uuid.uuid4().hex
            # https://docs.aws.amazon.com/athena/latest/ug/service-limits.html
            # não é possível executar mais de 20 DDL's

            file_name = os.path.basename(sql_file)
            file_name = os.path.splitext(file_name)[0]
            result_configuration = {
                'OutputLocation': 's3://bancobari-prognum-athena-logs-{account_id}/create_tables/{db}/{now}/{sql}'
                                .format(db=athena_database_name, account_id=ACCOUNT_ID, now=now_str, sql=file_name)
            }

            print(result_configuration)

            query_execution_id = athena_hook.run_query(f_sql, query_context,
                                                       result_configuration,
                                                       client_request_token)

            time.sleep(1)
            for try_ in range(2000):
                status = athena_hook.check_query_status(query_execution_id)
                if status == "SUCCEEDED":
                    print(f"Query executed with {status} status: {sql_file}")
                    break
                elif status == "FAILED":
                    print(f"Query executed with {status} status: {sql_file}")
                    sys.exit(1)
                else:
                    print(f"Query with {status} status, waiting...: {sql_file}")
                    time.sleep(5)

    if task_success is not None:
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['bucket'] = bucket_name
        var_dict['task_function'] = 'SQL'
        var_dict['dbtype'] = 'Athena'
        var_dict['dbname'] = athena_database_name
        var_dict['ddltype'] = 'CREATE TABLE IF NOT EXISTS <db>.<table> ;'
        var_dict['rowquantity'] = len(create_table_sqls)


def create_athena_databases(database, task_success=None, task_id=None):
    logging.info("Creating database: {} in AWS Athena.".format(database))

    query = f"CREATE DATABASE IF NOT EXISTS {database} ;"

    query_context = {
        'Database': f'{database}'
    }

    result_configuration = {
        'OutputLocation': f's3://bancobari-prognum-athena-logs-{ACCOUNT_ID}/create_database/{database}/'
    }

    client_request_token = uuid.uuid4().hex

    athena_hook.run_query(query, query_context, result_configuration, client_request_token)

    if task_success is not None:
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['task_function'] = 'SQL'
        var_dict['dbtype'] = 'Athena'
        var_dict['dbname'] = f'{database}'
        var_dict['ddltype'] = f'CREATE DATABASE IF NOT EXISTS {database};'
        var_dict['rowquantity'] = 1


def drop_athena_databases(database, task_success=None, task_id=None):
    logging.info("Dropping database : {} in AWS Athena.".format(database))

    query = f"DROP DATABASE IF EXISTS {database} CASCADE;"

    print(f"drop_athena_databases sql={query}")

    query_context = {
        'Database': f'{database}'
    }

    result_configuration = {
        'OutputLocation': f's3://bancobari-prognum-athena-logs-{ACCOUNT_ID}/drop_database/{database}/'
    }

    client_request_token = uuid.uuid4().hex

    query_id = athena_hook.run_query(query, query_context, result_configuration, client_request_token)
    print(f"QueryExecutionId={query_id}")

    if task_success is not None:
        print(f'Task success não é None!!!')
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['task_function'] = 'SQL'
        var_dict['dbtype'] = 'Athena'
        var_dict['dbname'] = database
        var_dict['ddltype'] = query
        var_dict['rowquantity'] = 1


def athena_wait_until_finish(query_execution_id, msg, sleep_interval_s=5, tries=2000):
    """
    wait for the query finish
    :param query_execution_id:
    :param msg:
    :param sleep_interval_s:
    :param tries:
    :return:
    """
    for try_ in range(tries):
        status = athena_hook.check_query_status(query_execution_id)
        if status == "SUCCEEDED":
            print(f"Query executed with status={status}: {msg}")
            break
        elif status == "FAILED":
            result = athena_hook.get_query_results(query_execution_id)
            print(f"Query executed with status={status}, result={result}: {msg}")
            sys.exit(1)
        else:
            print(f"Query with status={status}, waiting...: {msg}")
            time.sleep(sleep_interval_s)


def athena_execute_query(database, query, method_name, sync, return_result):
    if len(query) > 255:
        log_query = f"{query[:255]}..."
    else:
        log_query = query

    logging.info(f"athena_execute_query(database={database}, query={log_query}, method_name={method_name}, "
                 f"sync={sync}, return_result={return_result})")

    query_context = {
        'Database': f'{database}'
    }

    result_configuration = {
        'OutputLocation': f's3://bancobari-prognum-athena-logs-{ACCOUNT_ID}/{method_name}/{database}/'
    }

    client_request_token = uuid.uuid4().hex

    query_execution_id = athena_hook.run_query(query, query_context, result_configuration, client_request_token)
    print(f"QueryExecutionId={query_execution_id}")

    if sync or return_result:
        athena_wait_until_finish(query_execution_id, log_query)

    if return_result:
        return athena_hook.get_query_results(query_execution_id)
    else:
        return None


def athena_remove_partition_from_bucket(tables_metadata,
                                        ds_str,
                                        s3_hook,
                                        task_success=None,
                                        task_id=None):
    ds_date = datetime.strptime(ds_str, "%Y-%m-%d")
    results = []
    for tm in tables_metadata:
        database = tm['database']
        table = tm['table']
        bucket_name = tm['bucket_name']
        key = tm['key']

        try:
            partition_column = tm['partition_column']
            partition_pattern = tm['partition_pattern']
            partition_date = ds_date.strftime(partition_pattern)
        except KeyError:
            partition_column = None
            partition_date = None

        if key.endswith("/"):
            key = key[:-1]

        if partition_column is not None and partition_date is not None:
            key = f"{key}/{partition_column}={partition_date}"

        result = (database, table, partition_column, partition_date, bucket_name, key)
        print(result)

        try:
            result = remove_objects_from_bucket(s3_hook, bucket_name, prefix=key,
                                                task_success=task_success, task_id=task_id)
        except Exception as ex:
            print(f"Trying to remove {bucket_name} {key}\n{ex}")

        results.append(result)

    return results


# def athena_drop_partition(database, table, partition_column, partition_value):
#     logging.info(f"athena_drop_partition(database={database}, table={table}, "
#                  f"partition_column{partition_column}, partition_value={partition_value})")
#     query = (
#         f"ALTER TABLE {database}.{table} DROP IF EXISTS "
#         f"PARTITION ({partition_column} = '{partition_value}'); "
#     )
#
#     logging.info(f"drop query => {query}")
#
#     athena_execute_query(database=database, query=query, method_name="athena_drop_partition",
#                          sync=True, return_result=False)


# def athena_clean_table_records_by_partition(athena_database_name, table, partition_column, partition_value):
#
#     logging.info(f"clean_records_by_partition database={athena_database_name} "
#                  f"partition_column={partition_column} partition_value={partition_value} ")
#
#     return_dict = {}
#
#     query = (
#         f"select count(*) as qtd from {athena_database_name}.{table} as t "
#         f"where cast(t.{partition_column} as varchar) = '{partition_value}'"
#     )
#
#     result = athena_execute_query(athena_database_name, query,
#                                   "clean_records_by_partition_count",
#                                   sync=True, return_result=True)
#
#     value = 0
#     for d in result['ResultSet']['Rows']:
#         _value = d['Data'][0]['VarCharValue']
#         if _value == 'qtd':
#             continue
#         else:
#             value = int(_value)
#
#     if value > 0:
#         logging.info(f"clean_records_by_partition result #rows={value}")
#         athena_drop_partition(athena_database_name, table, partition_column, partition_value)
#
#     return_dict[table] = value
#
#     return return_dict


# def athena_list_partitions(database, table):
#     # sql = f"SHOW PARTITIONS {database}.{table};"
#     sql = f"""SELECT partition_value
#                 FROM information_schema.__internal_partitions__
#                 WHERE table_schema = '{database}'
#                 AND table_name = '{table}'
#                 ORDER BY partition_value"""
#     rs = athena_execute_query(database, query=sql, method_name="athena_list_partitions", sync=True, return_result=True)
#     print(rs)
#     return rs


# def athena_repair_partitions(database, table):
#     sql = "MSCK REPAIR TABLE scci_business.dim_cliente;"
#     rs = athena_execute_query(database, query=sql, method_name="athena_list_partitions", sync=True, return_result=False)
#     print(rs)
#     return rs


