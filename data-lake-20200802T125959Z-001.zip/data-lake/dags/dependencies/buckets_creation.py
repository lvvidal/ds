


list = ["bancobari-prognum-backup-083908103207", "bancobari-prognum-athena-logs-083908103207",
        "bancobari-prognum-business-083908103207", "bancobari-prognum-processed-083908103207",
        "bancobari-prognum-raw-083908103207", "prognum-backup-083908103207"]

