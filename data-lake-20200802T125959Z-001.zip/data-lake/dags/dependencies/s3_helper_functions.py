# Name:  s3_helper_functions.py
# Purpose:
# Created at: 2019-11-22
# Authors: Anderson Igarashi    <anderson.igarashi@baripromotora.com.br>
#          Luiz Vidal           <luiz.vidal@baritecnologia.com.br>

from __future__ import print_function
from hurry.filesize import size

import logging
import os
import glob
import boto3
import socket


def download_file(s3_hook, bucket, key, destination, task_success=None, task_id=None):

    logging.info(f"download_file(bucket={bucket}, key={key}, destination={destination})")
    logging.info(f"host_name={socket.gethostname()} host_ip={socket.gethostbyname(socket.gethostname())}")

    s3 = s3_hook.get_resource_type('s3')
    b = s3.Bucket(bucket)

    if not os.path.exists(destination):
        print(f"destination folder {destination} doesn't exists. Creating it...")
        os.makedirs(destination)

    for obj in b.objects.filter(Prefix=key):
        path, filename = os.path.split(obj.key)
        final_destination = os.path.join(destination, filename)
        logging.info(f"Downloading from s3 => bucket={bucket}/{obj.key} and sending to destination= {final_destination}")
        # boto3 s3 download_file will throw exception if folder not exists
        try:
            os.makedirs(destination) 
        except FileExistsError:
            pass
        s3.meta.client.download_file(bucket, obj.key, final_destination)

    if task_success is not None:
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['task_function'] = 'S3 Download'
        var_dict['bucket'] = bucket
        var_dict['filesize'] = size(os.path.getsize(destination))
        var_dict['dbtype'] = 'Athena'
        var_dict['rowquantity'] = len([name for name in os.listdir(destination)])

def upload_files(s3_hook, bucket, source_file_pattern, destination, task_success=None, task_id=None):
    logging.info(f"upload_files(bucket={bucket}, source_file_pattern={source_file_pattern}, destination={destination})")

    s3 = s3_hook.get_resource_type('s3')

    files = [f for f in glob.glob(source_file_pattern, recursive=False)]
    for file_path in files:
        file_name = os.path.basename(file_path)
        table = file_name.split('.')[0]
        destination_path = f"{destination}/{table}/{file_name}"
        logging.info(f"uploading to s3 => file_path={file_path} bucket={bucket} destination_path={destination_path}")
        s3.meta.client.upload_file(file_path, bucket, destination_path)

    b = s3.Bucket(bucket)

    if task_success is not None:
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['task_function'] = 'Upload'
        var_dict['bucket'] = bucket
        var_dict['rowquantity'] = len(list(b.objects.all()))


def remove_objects_from_bucket(s3_hook, bucket, prefix, task_success, task_id):

    logging.info(f"deleting objects from (bucket={bucket} prefix={prefix})")

    s3 = s3_hook.get_resource_type('s3')
    b = s3.Bucket(bucket)

    deleted_objects = []

    if type(prefix) == str:
        prefixes = [prefix]
    else:
        prefixes = prefix

    for pref in prefixes:
        print(f"deleting bucket={bucket} prefix={pref}")
        deleted_objects.extend(b.objects.filter(Prefix=pref).delete())

    print(f'remove_objects_from_bucket objects deleted => {str(deleted_objects)}')

    if task_success is not None:
        if task_id in task_success.var_dict_global:
            var_dict = task_success.var_dict_global[task_id]
        else:
            task_success.var_dict_global[task_id] = {}
            var_dict = task_success.var_dict_global[task_id]

        var_dict['task_function'] = 'Remove s3 Objects'
        var_dict['bucket'] = bucket
        var_dict['rowquantity'] = len(deleted_objects)

    return deleted_objects


# def list_files(s3_hook, bucket, prefix, task_success, task_id):
#     pass

# source_bucket_name=f'bancobari-prognum-raw-{ACCOUNT_ID}',
#         source_bucket_key=f'scci/{db}/{{{{ execution_date.strftime("%Y/%m/%d") }}}}/',
#         dest_bucket_name=bucket,
#         dest_bucket_key=f'scci/{db}/current/',


# def copy_bucket_content(s3_hook, source_bucket_name, source_bucket_key, dest_bucket_name, dest_bucket_key):
#     s3 = s3_hook.get_resource_type('s3')
#
#     new_bucket_name = "targetBucketName"
#     bucket_to_copy = "sourceBucketName"
#
#     for key in s3.list_objects(Bucket=bucket_to_copy)['Contents']:
#         files = key['Key']
#         copy_source = {'Bucket': "bucket_to_copy", 'Key': files}
#         s3.meta.client.copy(copy_source, new_bucket_name, files)
#         print(files)