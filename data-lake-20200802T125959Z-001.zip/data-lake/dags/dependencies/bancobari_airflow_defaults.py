import os
from pathlib import Path

from airflow.models import Variable

SANDBOX = "sandbox"
DEV = "dev"
STAGE = "stage"
PROD = "prod"

SANDBOX_ID = "724358820973"
DEV_ID = "213912952026"
STAGE_ID = "083908103207"
PROD_ID = "2555688133533"

DEFAULT_ENV = os.getenv("DEFAULT_ENV", Variable.get("default_env", DEV))

# Connections ID's
REDSHIFT_CONN_ID = 'redshift'
AWS_CONN_ID = 'aws_bari'

# Airflow Variables
AIRFLOW_HOME = Path(os.environ.get("AIRFLOW_HOME", "~/airflow"))

EMAIL_LIST: [
    'anderson.igarashi@baripromotora.com.br',
    'marcos.gritti@baritecnologia.com.br',
    'luiz.vidal@baritecnologia.com.br'
]

def is_dev():
    return DEFAULT_ENV == DEV

def is_prod():
    return DEFAULT_ENV == PROD


def is_sandbox():
    return DEFAULT_ENV == SANDBOX


def is_stage():
    return DEFAULT_ENV == STAGE


def get_account_id():
    if is_prod():
        return PROD_ID
    elif is_stage():
        return STAGE_ID
    elif is_dev():
        return DEV_ID
    elif is_sandbox():
        return SANDBOX_ID
    else:
        raise Exception("DEFAULT_ENV={env} not set or unknown".format(env=DEFAULT_ENV))
