from airflow.models.baseoperator import BaseOperator
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.s3_key_sensor import S3KeySensor
from airflow.utils.decorators import apply_defaults
from datetime import datetime, date
from hurry.filesize import size
import boto3

import logging

class BariS3KeySensor(PythonOperator):

    @apply_defaults
    def __init__(self, s3_hook, pg_hook,
                 *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.s3_hook = s3_hook
        self.pg_hook = pg_hook
        self.var_dict = {}

    def execute(self, context):
        super().execute(context)
        au_dict = {
            'dag_id': context['task_instance'].dag_id,
            'task_id': context['task_instance'].task_id,
            'job_id': context['task_instance'].job_id,
            'task_type': context['task'].task_type,
            'execution_date': context['task_instance'].execution_date.strftime('%Y-%m-%d'),
            'start_date': context['task_instance'].start_date.strftime('%Y-%m-%d %H:%M:%S.%f'),
            'end_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        }

        au_dict['task_function'] = 'Sensor'
        au_dict['bucket'] = context['task'].bucket_name
        au_dict['filesize'] = self.get_file_size_s3(
            self.s3_hook,
            context['task'].bucket_name,
            self.renderiza(context, context['task'].bucket_key)
        )
        self.audit_event(self.pg_hook, au_dict)


    def get_file_size_s3(self, s3_hook, bucket, key):
        logging.info(f"download_file(bucket={bucket}, key={key})")

        s3 = s3_hook.get_resource_type('s3')
        obj = s3.Object(bucket, key)

        # size in bytes
        file_size_s3 = size(obj.content_length)

        return file_size_s3


    def extract_value(self, obj):
        if isinstance(obj, str):
            return f"'{obj}'"
        if isinstance(obj, (date, datetime)):
            return self.extract_value(obj.strftime("%Y-%m-%d %H:%M:%S.%f"))
        return str(obj)


    def renderiza(self, context, templated_str):
        jinja_context = context['task_instance'].get_template_context()
        return self.render_template('', templated_str, jinja_context)

    
    def audit_event(self, pg_hook, a: dict):
        conn = pg_hook.get_conn()

        cursor = conn.cursor()

        sql_statement = f'INSERT INTO public.audit_dag ('
        sql_statement += f'{",".join(a.keys())}) VALUES('
        values = [self.extract_value(v) for v in a.values()]
        sql_statement += f'{",".join(values)});'

        print(sql_statement)
        cursor.execute(sql_statement)

        cursor.close()

        conn.commit()

        conn.close()

        logging.info("Audit data recorded successfully")